import psycopg2
from dotenv import load_dotenv
import os

load_dotenv()

conn = psycopg2.connect(
    host=os.getenv('PGVECTOR_HOST', 'localhost'),
    port=os.getenv('PGVECTOR_PORT', '5432'),
    database=os.getenv('PGVECTOR_DB', 'vectordb'),
    user=os.getenv('PGVECTOR_USER', 'postgres'),
    password=os.getenv('PGVECTOR_PASSWORD')
)

cur = conn.cursor()
cur.execute('SELECT employee_id, email, name, role, enabled, created_at FROM rag_users ORDER BY created_at DESC')
users = cur.fetchall()

print('\n' + '='*80)
print('USERS IN DATABASE:')
print('='*80)
for u in users:
    print(f'EmployeeID: {u[0]:10} | Email: {u[1]:30} | Name: {u[2]:20} | Role: {u[3]:10} | Enabled: {u[4]}')
print('='*80)
print(f'Total users: {len(users)}')
print('='*80 + '\n')

conn.close()
