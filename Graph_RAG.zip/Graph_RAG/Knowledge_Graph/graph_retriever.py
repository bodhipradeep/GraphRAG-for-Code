"""
Graph-aware retriever for query time.
Extracts entities from query → traverses Neo4j → builds context string for LLM.
Includes full hierarchy context: Feature → Directory (layer) → File → Class → Method
"""

import json
import re
import logging
from typing import List, Dict, Set, Optional
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from Utils.model_loader import llm

logger = logging.getLogger(__name__)


# ==================== ENTITY EXTRACTION ====================

ENTITY_EXTRACT_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You extract code entity names from bug reports for a Java/Angular codebase with 57 microservices.

Extract ALL identifiable code entities:
- class_names: CamelCase class/service/component names. "UserService" → ["UserService", "UserServiceImpl"]
- method_names: method names. "delete pool" → ["deletePool", "delete"]
- error_types: Exception types. "NPE" → "NullPointerException"
- keywords: domain terms for search. "pool configuration" → ["pool", "configuration"]

Return ONLY valid JSON:
{{"class_names": [], "method_names": [], "error_types": [], "keywords": []}}"""),
    ("human", "Bug Query: {query}")
])

entity_chain = ENTITY_EXTRACT_PROMPT | llm | StrOutputParser()


def extract_entities(query: str) -> Dict:
    """Extract code entities from a bug query using LLM + regex fallback."""
    default = {"class_names": [], "method_names": [], "error_types": [], "keywords": []}
    try:
        raw = entity_chain.invoke({"query": query})
        text = raw.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
            if text.endswith("```"):
                text = text[:-3]
            text = text.strip()
        if text.startswith("json"):
            text = text[4:].strip()

        entities = json.loads(text)
        for key in default:
            if key not in entities:
                entities[key] = default[key]
        logger.info(f"Extracted entities: {json.dumps(entities, default=str)}")
        return entities
    except Exception as e:
        logger.warning(f"LLM entity extraction failed ({e}), using regex fallback")
        return _regex_fallback(query)


def _regex_fallback(query: str) -> Dict:
    entities = {"class_names": [], "method_names": [], "error_types": [], "keywords": []}

    for word in re.findall(r'\b([A-Z][a-zA-Z0-9]{2,})\b', query):
        if word.endswith("Exception") or word.endswith("Error"):
            entities["error_types"].append(word)
        else:
            entities["class_names"].append(word)

    entities["method_names"] = re.findall(r'\b([a-z][a-zA-Z0-9]*[A-Z][a-zA-Z0-9]*)\b', query)

    lower = query.lower()
    if "npe" in lower or "null pointer" in lower:
        entities["error_types"].append("NullPointerException")

    return entities


# ==================== GRAPH CONTEXT BUILDER ====================

def _format_location(cls_or_method: Dict) -> str:
    """Format the hierarchy location: feature/layer/directory/file."""
    parts = []
    if cls_or_method.get("feature"):
        parts.append(f"feature={cls_or_method['feature']}")
    if cls_or_method.get("layer_type"):
        parts.append(f"layer={cls_or_method['layer_type']}")
    elif cls_or_method.get("directory"):
        parts.append(f"dir={cls_or_method['directory']}")
    if cls_or_method.get("file_path"):
        parts.append(cls_or_method["file_path"])
    return " | ".join(parts) if parts else "unknown location"


def build_graph_context(graph_store, entities: Dict) -> str:
    """Query Neo4j and build a human-readable context string for the LLM.
    Includes full hierarchy: Feature → Directory (layer) → File → Class."""

    sections = []
    all_class_names = set()

    # 1. Find matching classes with hierarchy position
    matched_classes = graph_store.find_classes_by_name(entities.get("class_names", []))
    if matched_classes:
        section = "MATCHED CLASSES (with architectural position):\n"
        for cls in matched_classes:
            name = cls.get("name", "?")
            all_class_names.add(name)
            location = _format_location(cls)
            section += f"  - {name} [{location}]\n"
        sections.append(section)

    # 2. Find matching methods with layer context
    matched_methods = graph_store.find_methods_by_name(entities.get("method_names", []))
    if matched_methods:
        section = "MATCHED METHODS:\n"
        for m in matched_methods:
            cls = m.get("class_name", "?")
            all_class_names.add(cls)
            layer = f" (layer={m['layer_type']})" if m.get("layer_type") else ""
            section += f"  - {cls}.{m.get('method_name', '?')}(){layer} in {m.get('file_path', '?')}\n"
        sections.append(section)

    # 3. Detailed context for each matched class
    for cls_name in list(all_class_names)[:5]:
        ctx = graph_store.get_class_context(cls_name)
        if not ctx.get("qualified_name"):
            continue

        section = f"\nCLASS CONTEXT: {cls_name}\n"

        # Hierarchy position — this is the KEY context for the LLM
        if ctx.get("feature"):
            section += f"  Feature/Microservice: {ctx['feature']}\n"
        if ctx.get("layer_type"):
            section += f"  Architecture Layer: {ctx['layer_type']}\n"
        if ctx.get("directory"):
            section += f"  Directory: {ctx['directory']}\n"
        if ctx.get("file_path"):
            section += f"  File: {ctx['file_path']}\n"
        if ctx.get("package"):
            section += f"  Package: {ctx['package']}\n"

        # Class relationships
        if ctx.get("extends"):
            section += f"  Extends: {ctx['extends']}\n"
        if ctx.get("implements"):
            section += f"  Implements: {', '.join(ctx['implements'])}\n"
        if ctx.get("imports"):
            section += f"  Imports: {', '.join(ctx['imports'][:15])}\n"
        if ctx.get("methods"):
            method_names = [m["name"] for m in ctx["methods"][:20]]
            section += f"  Methods: {', '.join(method_names)}\n"

        # Sibling classes in the same directory (same architecture layer)
        if ctx.get("sibling_classes"):
            siblings = [f"{s['name']} ({s['file']})" for s in ctx["sibling_classes"][:8]]
            layer_label = ctx.get("layer_type", "directory")
            section += f"  Siblings in same {layer_label} layer: {', '.join(siblings)}\n"

        # Call graph with layer annotations
        if ctx.get("calls_out"):
            section += "  Calls (outgoing):\n"
            for c in ctx["calls_out"][:15]:
                target_cls = c.get("to_class", "?")
                target = f"{target_cls}.{c['to_method']}()"
                layer_info = f" [{c['to_layer']}]" if c.get("to_layer") else ""
                section += f"    {cls_name}.{c['from']}() → {target}{layer_info}\n"

        if ctx.get("called_by"):
            section += "  Called by (incoming):\n"
            for c in ctx["called_by"][:15]:
                caller_cls = c.get("from_class", "?")
                caller = f"{caller_cls}.{c['from_method']}()"
                layer_info = f" [{c['from_layer']}]" if c.get("from_layer") else ""
                section += f"    {caller}{layer_info} → {cls_name}.{c['to_method']}()\n"

        sections.append(section)

    # 4. Call chains with layer flow (shows architectural flow: controller → service → repository)
    for method_name in (entities.get("method_names", []) or [])[:3]:
        for cls_name in list(all_class_names)[:3]:
            chains = graph_store.get_call_chain(cls_name, method_name, direction="both", depth=2)
            if chains:
                section = f"\nCALL CHAIN for {cls_name}.{method_name}():\n"
                for ch in chains[:10]:
                    arrow = "→" if ch["direction"] == "outgoing" else "←"
                    from_layer = f" [{ch['from_layer']}]" if ch.get("from_layer") else ""
                    to_layer = f" [{ch['to_layer']}]" if ch.get("to_layer") else ""
                    section += f"  {ch['from']}(){from_layer} {arrow} {ch['to']}(){to_layer}\n"
                sections.append(section)
                break

    if not sections:
        return ""

    return "CODE KNOWLEDGE GRAPH CONTEXT:\n" + "\n".join(sections)


def get_guided_file_paths(graph_store, entities: Dict) -> Set[str]:
    """Get file paths that should be prioritized in vector search based on graph relationships."""
    class_names = entities.get("class_names", [])
    if not class_names:
        return set()
    return graph_store.get_related_file_paths(class_names, depth=2)
