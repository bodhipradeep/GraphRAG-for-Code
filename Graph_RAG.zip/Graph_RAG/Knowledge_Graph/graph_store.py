"""
Neo4j graph store for code knowledge graph.
Hierarchical: Feature → Directory → File → Class → Method
Plus cross-cutting: CALLS, IMPORTS, EXTENDS, IMPLEMENTS, HANDLES
"""

import logging
from typing import List, Dict, Optional, Set
from neo4j import GraphDatabase
from Config.settings import CONFIG

logger = logging.getLogger(__name__)


class CodeGraphStore:

    def __init__(self):
        self.driver = GraphDatabase.driver(
            CONFIG["neo4j_uri"],
            auth=(CONFIG["neo4j_user"], CONFIG["neo4j_password"])
        )
        self.database = CONFIG["neo4j_database"]
        self._ensure_indexes()

    def close(self):
        self.driver.close()

    def _run(self, query: str, parameters: dict = None):
        with self.driver.session(database=self.database) as session:
            return session.run(query, parameters or {}).data()

    def _run_single(self, query: str, parameters: dict = None):
        with self.driver.session(database=self.database) as session:
            result = session.run(query, parameters or {}).single()
            return dict(result) if result else None

    def _ensure_indexes(self):
        indexes = [
            "CREATE INDEX IF NOT EXISTS FOR (ft:Feature) ON (ft.name)",
            "CREATE INDEX IF NOT EXISTS FOR (d:Directory) ON (d.path)",
            "CREATE INDEX IF NOT EXISTS FOR (f:File) ON (f.relative_path)",
            "CREATE INDEX IF NOT EXISTS FOR (c:Class) ON (c.name)",
            "CREATE INDEX IF NOT EXISTS FOR (c:Class) ON (c.qualified_name)",
            "CREATE INDEX IF NOT EXISTS FOR (m:Method) ON (m.name)",
            "CREATE INDEX IF NOT EXISTS FOR (m:Method) ON (m.qualified_name)",
            "CREATE INDEX IF NOT EXISTS FOR (i:Interface) ON (i.name)",
            "CREATE INDEX IF NOT EXISTS FOR (e:APIEndpoint) ON (e.path)",
        ]
        for idx in indexes:
            try:
                self._run(idx)
            except Exception as e:
                logger.debug(f"Index creation note: {e}")
        logger.info("Neo4j indexes ensured")

    # ==================== WRITE — HIERARCHY ====================

    def clear_all(self):
        self._run("MATCH (n) DETACH DELETE n")
        logger.info("Cleared all nodes and relationships from Neo4j")

    def clear_by_file(self, relative_path: str):
        """Remove a file and its classes/methods (keeps directory structure)."""
        self._run("""
            MATCH (f:File {relative_path: $path})
            OPTIONAL MATCH (f)-[:DECLARES_CLASS]->(c)
            OPTIONAL MATCH (c)-[:HAS_METHOD]->(m)
            DETACH DELETE m, c, f
        """, {"path": relative_path})

    def merge_feature(self, name: str, feature_type: str = "microservice"):
        """Create or update a Feature node (microservice or frontend-module)."""
        self._run("""
            MERGE (ft:Feature {name: $name})
            SET ft.type = $type
        """, {"name": name, "type": feature_type})

    def merge_directory(self, name: str, path: str, layer_type: str = None,
                        parent_path: str = None, feature_name: str = None):
        """Create or update a Directory node.
        layer_type: controller, service, repository, model, component, module, etc."""
        self._run("""
            MERGE (d:Directory {path: $path})
            SET d.name = $name, d.layer_type = $layer_type
        """, {"path": path, "name": name, "layer_type": layer_type})

        if feature_name:
            self._run("""
                MATCH (ft:Feature {name: $feat})
                MATCH (d:Directory {path: $path})
                MERGE (ft)-[:HAS_DIR]->(d)
            """, {"feat": feature_name, "path": path})

        if parent_path:
            self._run("""
                MATCH (parent:Directory {path: $parent})
                MATCH (child:Directory {path: $child})
                MERGE (parent)-[:HAS_SUBDIR]->(child)
            """, {"parent": parent_path, "child": path})

    def merge_file(self, name: str, relative_path: str, language: str,
                   directory_path: str = None):
        """Create or update a File node, linked to its parent Directory."""
        self._run("""
            MERGE (f:File {relative_path: $rpath})
            SET f.name = $name, f.language = $language
        """, {"rpath": relative_path, "name": name, "language": language})

        if directory_path:
            self._run("""
                MATCH (d:Directory {path: $dpath})
                MATCH (f:File {relative_path: $fpath})
                MERGE (d)-[:HAS_FILE]->(f)
            """, {"dpath": directory_path, "fpath": relative_path})

    def merge_class(self, name: str, qualified_name: str, package: str,
                    language: str, file_relative_path: str,
                    extends: str = None, implements: List[str] = None):
        self._run("""
            MERGE (c:Class {qualified_name: $qn})
            SET c.name = $name, c.package = $package, c.language = $language
        """, {"qn": qualified_name, "name": name, "package": package, "language": language})

        self._run("""
            MATCH (f:File {relative_path: $path})
            MATCH (c:Class {qualified_name: $qn})
            MERGE (f)-[:DECLARES_CLASS]->(c)
        """, {"path": file_relative_path, "qn": qualified_name})

        if extends:
            self._run("""
                MATCH (c:Class {qualified_name: $qn})
                MERGE (parent:Class {name: $parent})
                MERGE (c)-[:EXTENDS]->(parent)
            """, {"qn": qualified_name, "parent": extends})

        for iface in (implements or []):
            self._run("""
                MATCH (c:Class {qualified_name: $qn})
                MERGE (i:Interface {name: $iface})
                MERGE (c)-[:IMPLEMENTS]->(i)
            """, {"qn": qualified_name, "iface": iface})

    def merge_method(self, name: str, class_qualified_name: str, signature: str,
                     file_name: str, relative_path: str,
                     start_line: int = None, end_line: int = None,
                     language: str = "java"):
        qualified_name = f"{class_qualified_name}.{name}"
        self._run("""
            MERGE (m:Method {qualified_name: $qn})
            SET m.name = $name, m.class_name = $class_qn,
                m.signature = $sig, m.file_name = $fname,
                m.relative_path = $rpath, m.start_line = $sl,
                m.end_line = $el, m.language = $lang
        """, {
            "qn": qualified_name, "name": name, "class_qn": class_qualified_name,
            "sig": signature, "fname": file_name, "rpath": relative_path,
            "sl": start_line, "el": end_line, "lang": language
        })

        self._run("""
            MATCH (c:Class {qualified_name: $cqn})
            MATCH (m:Method {qualified_name: $mqn})
            MERGE (c)-[:HAS_METHOD]->(m)
        """, {"cqn": class_qualified_name, "mqn": qualified_name})

    def add_import(self, from_class_qn: str, to_class_name: str):
        self._run("""
            MATCH (c:Class {qualified_name: $from_qn})
            MERGE (t:Class {name: $to_name})
            MERGE (c)-[:IMPORTS]->(t)
        """, {"from_qn": from_class_qn, "to_name": to_class_name})

    def add_call(self, from_method_qn: str, to_method_name: str, to_class_name: str = None):
        if to_class_name:
            to_qn = f"{to_class_name}.{to_method_name}"
            self._run("""
                MATCH (m:Method {qualified_name: $from_qn})
                MERGE (t:Method {qualified_name: $to_qn})
                ON CREATE SET t.name = $to_name, t.class_name = $to_class
                MERGE (m)-[:CALLS]->(t)
            """, {"from_qn": from_method_qn, "to_qn": to_qn,
                  "to_name": to_method_name, "to_class": to_class_name})
        else:
            self._run("""
                MATCH (m:Method {qualified_name: $from_qn})
                MERGE (t:Method {name: $to_name})
                MERGE (m)-[:CALLS]->(t)
            """, {"from_qn": from_method_qn, "to_name": to_method_name})

    def add_api_endpoint(self, path: str, http_method: str, handler_method_qn: str):
        self._run("""
            MERGE (e:APIEndpoint {path: $path, http_method: $method})
            WITH e
            MATCH (m:Method {qualified_name: $mqn})
            MERGE (m)-[:HANDLES]->(e)
        """, {"path": path, "method": http_method, "mqn": handler_method_qn})

    # ==================== READ — HIERARCHY TRAVERSAL ====================

    def get_feature_tree(self, feature_name: str) -> Dict:
        """Get the full directory tree under a feature.
        Returns: {name, dirs: [{name, layer_type, files: [...], subdirs: [...]}]}"""
        rows = self._run("""
            MATCH (ft:Feature {name: $name})-[:HAS_DIR]->(d:Directory)
            OPTIONAL MATCH (d)-[:HAS_SUBDIR*0..3]->(sub:Directory)
            OPTIONAL MATCH (sub)-[:HAS_FILE]->(f:File)
            RETURN d.name AS dir_name, d.path AS dir_path, d.layer_type AS layer,
                   sub.name AS sub_name, sub.path AS sub_path, sub.layer_type AS sub_layer,
                   f.name AS file_name, f.relative_path AS file_path
            ORDER BY dir_path, sub_path
        """, {"name": feature_name})
        return {"feature": feature_name, "tree": rows}

    def get_directory_contents(self, dir_path: str) -> Dict:
        """Get everything inside a directory: subdirs, files, classes, methods."""
        result = {"path": dir_path, "subdirs": [], "files": []}

        rows = self._run("""
            MATCH (d:Directory {path: $path})-[:HAS_SUBDIR]->(sub)
            RETURN sub.name AS name, sub.path AS path, sub.layer_type AS layer
        """, {"path": dir_path})
        result["subdirs"] = rows

        rows = self._run("""
            MATCH (d:Directory {path: $path})-[:HAS_FILE]->(f)
            OPTIONAL MATCH (f)-[:DECLARES_CLASS]->(c)
            OPTIONAL MATCH (c)-[:HAS_METHOD]->(m)
            RETURN f.name AS file, f.relative_path AS path,
                   collect(DISTINCT c.name) AS classes,
                   collect(DISTINCT m.name) AS methods
        """, {"path": dir_path})
        result["files"] = rows

        return result

    def find_classes_by_name(self, names: List[str]) -> List[Dict]:
        """Find classes with full hierarchy context (Feature → Dir → File → Class)."""
        if not names:
            return []
        results = []
        for name in names:
            rows = self._run("""
                MATCH (c:Class)
                WHERE toLower(c.name) CONTAINS toLower($name)
                OPTIONAL MATCH (f:File)-[:DECLARES_CLASS]->(c)
                OPTIONAL MATCH (d:Directory)-[:HAS_FILE]->(f)
                OPTIONAL MATCH (ft:Feature)-[:HAS_DIR|HAS_SUBDIR*1..4]->(d)
                RETURN c.name AS name, c.qualified_name AS qualified_name,
                       c.package AS package, c.language AS language,
                       f.relative_path AS file_path,
                       d.name AS directory, d.layer_type AS layer_type,
                       ft.name AS feature
                LIMIT 5
            """, {"name": name})
            results.extend(rows)
        return results

    def find_methods_by_name(self, names: List[str]) -> List[Dict]:
        if not names:
            return []
        results = []
        for name in names:
            rows = self._run("""
                MATCH (m:Method)
                WHERE toLower(m.name) CONTAINS toLower($name)
                OPTIONAL MATCH (c:Class)-[:HAS_METHOD]->(m)
                OPTIONAL MATCH (f:File)-[:DECLARES_CLASS]->(c)
                OPTIONAL MATCH (d:Directory)-[:HAS_FILE]->(f)
                RETURN m.name AS method_name, m.qualified_name AS qualified_name,
                       m.signature AS signature, c.name AS class_name,
                       f.relative_path AS file_path, d.layer_type AS layer_type
                LIMIT 5
            """, {"name": name})
            results.extend(rows)
        return results

    def get_class_context(self, class_name: str, depth: int = 2) -> Dict:
        """Get full context: hierarchy position + imports + call chain.
        This is the KEY query — gives the LLM complete architectural understanding."""

        context = {
            "class_name": class_name,
            "qualified_name": None,
            "package": None,
            "feature": None,
            "directory": None,
            "layer_type": None,
            "file_path": None,
            "extends": None,
            "implements": [],
            "imports": [],
            "methods": [],
            "calls_out": [],
            "called_by": [],
            "sibling_classes": [],
        }

        # Basic info with full hierarchy
        row = self._run_single("""
            MATCH (c:Class) WHERE toLower(c.name) = toLower($name)
            OPTIONAL MATCH (f:File)-[:DECLARES_CLASS]->(c)
            OPTIONAL MATCH (d:Directory)-[:HAS_FILE]->(f)
            OPTIONAL MATCH (ft:Feature)-[:HAS_DIR|HAS_SUBDIR*1..4]->(d)
            OPTIONAL MATCH (c)-[:EXTENDS]->(parent)
            RETURN c.name AS name, c.qualified_name AS qn, c.package AS pkg,
                   f.relative_path AS file_path,
                   d.name AS directory, d.layer_type AS layer_type,
                   ft.name AS feature,
                   parent.name AS extends
        """, {"name": class_name})

        if not row:
            return context

        context.update({
            "qualified_name": row.get("qn"),
            "package": row.get("pkg"),
            "feature": row.get("feature"),
            "directory": row.get("directory"),
            "layer_type": row.get("layer_type"),
            "file_path": row.get("file_path"),
            "extends": row.get("extends"),
        })

        qn = row.get("qn") or class_name

        # Implements
        rows = self._run("""
            MATCH (c:Class {qualified_name: $qn})-[:IMPLEMENTS]->(i)
            RETURN i.name AS interface
        """, {"qn": qn})
        context["implements"] = [r["interface"] for r in rows]

        # Imports
        rows = self._run("""
            MATCH (c:Class {qualified_name: $qn})-[:IMPORTS]->(t)
            RETURN t.name AS imported_class
        """, {"qn": qn})
        context["imports"] = [r["imported_class"] for r in rows]

        # Methods
        rows = self._run("""
            MATCH (c:Class {qualified_name: $qn})-[:HAS_METHOD]->(m)
            RETURN m.name AS name, m.signature AS signature
        """, {"qn": qn})
        context["methods"] = [{"name": r["name"], "signature": r.get("signature")} for r in rows]

        # Sibling classes in the same directory (other files in same layer)
        if row.get("directory"):
            rows = self._run("""
                MATCH (d:Directory {name: $dir})-[:HAS_FILE]->(f)-[:DECLARES_CLASS]->(sibling)
                WHERE sibling.qualified_name <> $qn
                RETURN DISTINCT sibling.name AS name, f.name AS file_name
                LIMIT 10
            """, {"dir": row["directory"], "qn": qn})
            context["sibling_classes"] = [
                {"name": r["name"], "file": r["file_name"]} for r in rows
            ]

        # Outgoing calls
        rows = self._run("""
            MATCH (c:Class {qualified_name: $qn})-[:HAS_METHOD]->(m)-[:CALLS]->(target)
            OPTIONAL MATCH (tc:Class)-[:HAS_METHOD]->(target)
            OPTIONAL MATCH (td:Directory)-[:HAS_FILE]->()-[:DECLARES_CLASS]->(tc)
            RETURN DISTINCT m.name AS from_method, target.name AS to_method,
                   tc.name AS to_class, td.layer_type AS to_layer
            LIMIT 30
        """, {"qn": qn})
        context["calls_out"] = [
            {"from": r["from_method"], "to_class": r.get("to_class"),
             "to_method": r["to_method"], "to_layer": r.get("to_layer")}
            for r in rows
        ]

        # Incoming calls
        rows = self._run("""
            MATCH (caller)-[:CALLS]->(m)<-[:HAS_METHOD]-(c:Class {qualified_name: $qn})
            OPTIONAL MATCH (cc:Class)-[:HAS_METHOD]->(caller)
            OPTIONAL MATCH (cd:Directory)-[:HAS_FILE]->()-[:DECLARES_CLASS]->(cc)
            RETURN DISTINCT caller.name AS from_method, cc.name AS from_class,
                   m.name AS to_method, cd.layer_type AS from_layer
            LIMIT 30
        """, {"qn": qn})
        context["called_by"] = [
            {"from_class": r.get("from_class"), "from_method": r["from_method"],
             "to_method": r["to_method"], "from_layer": r.get("from_layer")}
            for r in rows
        ]

        return context

    def get_call_chain(self, class_name: str, method_name: str,
                       direction: str = "both", depth: int = 2) -> List[Dict]:
        """Traverse the call graph with layer context."""
        chains = []

        if direction in ("out", "both"):
            rows = self._run("""
                MATCH path = (start:Method)-[:CALLS*1..""" + str(depth) + """]->(target:Method)
                WHERE toLower(start.name) = toLower($method)
                  AND (start.class_name CONTAINS $class OR $class = '')
                UNWIND relationships(path) AS r
                WITH startNode(r) AS fn, endNode(r) AS tn
                OPTIONAL MATCH (fc:Class)-[:HAS_METHOD]->(fn)
                OPTIONAL MATCH (tc:Class)-[:HAS_METHOD]->(tn)
                OPTIONAL MATCH (fd:Directory)-[:HAS_FILE]->()-[:DECLARES_CLASS]->(fc)
                OPTIONAL MATCH (td:Directory)-[:HAS_FILE]->()-[:DECLARES_CLASS]->(tc)
                RETURN DISTINCT fc.name AS from_class, fn.name AS from_method,
                       fd.layer_type AS from_layer,
                       tc.name AS to_class, tn.name AS to_method,
                       td.layer_type AS to_layer
                LIMIT 50
            """, {"method": method_name, "class": class_name})
            for r in rows:
                chains.append({
                    "direction": "outgoing",
                    "from": f"{r.get('from_class', '?')}.{r['from_method']}",
                    "from_layer": r.get("from_layer"),
                    "to": f"{r.get('to_class', '?')}.{r['to_method']}",
                    "to_layer": r.get("to_layer")
                })

        if direction in ("in", "both"):
            rows = self._run("""
                MATCH path = (caller:Method)-[:CALLS*1..""" + str(depth) + """]->(target:Method)
                WHERE toLower(target.name) = toLower($method)
                  AND (target.class_name CONTAINS $class OR $class = '')
                UNWIND relationships(path) AS r
                WITH startNode(r) AS fn, endNode(r) AS tn
                OPTIONAL MATCH (fc:Class)-[:HAS_METHOD]->(fn)
                OPTIONAL MATCH (tc:Class)-[:HAS_METHOD]->(tn)
                OPTIONAL MATCH (fd:Directory)-[:HAS_FILE]->()-[:DECLARES_CLASS]->(fc)
                OPTIONAL MATCH (td:Directory)-[:HAS_FILE]->()-[:DECLARES_CLASS]->(tc)
                RETURN DISTINCT fc.name AS from_class, fn.name AS from_method,
                       fd.layer_type AS from_layer,
                       tc.name AS to_class, tn.name AS to_method,
                       td.layer_type AS to_layer
                LIMIT 50
            """, {"method": method_name, "class": class_name})
            for r in rows:
                chains.append({
                    "direction": "incoming",
                    "from": f"{r.get('from_class', '?')}.{r['from_method']}",
                    "from_layer": r.get("from_layer"),
                    "to": f"{r.get('to_class', '?')}.{r['to_method']}",
                    "to_layer": r.get("to_layer")
                })

        return chains

    def get_related_file_paths(self, class_names: List[str], depth: int = 2) -> Set[str]:
        """Get file paths related to given classes — for guided vector search.
        Includes: own file, imported classes, callers, callees, siblings in same dir."""
        paths = set()
        for name in class_names:
            rows = self._run("""
                MATCH (c:Class) WHERE toLower(c.name) = toLower($name)
                OPTIONAL MATCH (f:File)-[:DECLARES_CLASS]->(c)

                // Imports
                OPTIONAL MATCH (c)-[:IMPORTS]->(ic)<-[:DECLARES_CLASS]-(if2:File)

                // Outgoing calls
                OPTIONAL MATCH (c)-[:HAS_METHOD]->()-[:CALLS]->()<-[:HAS_METHOD]-(oc)<-[:DECLARES_CLASS]-(of:File)

                // Incoming calls
                OPTIONAL MATCH (cc)-[:HAS_METHOD]->()-[:CALLS]->()<-[:HAS_METHOD]-(c)
                OPTIONAL MATCH (cf:File)-[:DECLARES_CLASS]->(cc)

                // Sibling files in same directory
                OPTIONAL MATCH (d:Directory)-[:HAS_FILE]->(f)
                OPTIONAL MATCH (d)-[:HAS_FILE]->(sf:File)

                WITH collect(DISTINCT f.relative_path) +
                     collect(DISTINCT if2.relative_path) +
                     collect(DISTINCT of.relative_path) +
                     collect(DISTINCT cf.relative_path) +
                     collect(DISTINCT sf.relative_path) AS all_paths
                UNWIND all_paths AS p
                RETURN DISTINCT p
            """, {"name": name})
            for r in rows:
                if r.get("p"):
                    paths.add(r["p"])
        return paths

    def get_stats(self) -> Dict:
        stats = {}
        for label in ["Feature", "Directory", "File", "Class", "Interface", "Method", "APIEndpoint"]:
            row = self._run_single(f"MATCH (n:{label}) RETURN count(n) AS c")
            stats[label.lower() + "s"] = row["c"] if row else 0

        row = self._run_single("MATCH ()-[r]->() RETURN count(r) AS c")
        stats["total_relationships"] = row["c"] if row else 0

        rows = self._run("MATCH ()-[r]->() RETURN type(r) AS t, count(r) AS c ORDER BY c DESC")
        stats["relationships"] = {r["t"]: r["c"] for r in rows}

        return stats
