
from typing import List, Dict, Set
import threading
import logging
from langchain_community.vectorstores import PGVector
from langchain_core.documents import Document
from Utils.model_loader import embed_model
from Config.settings import CONFIG
import psycopg2

logger = logging.getLogger(__name__)


class CodeVectorStore:
    
    _lock = threading.Lock()
    
    def __init__(self):
        self.embeddings = embed_model
        self.connection_string = (
            f"postgresql://{CONFIG['pgvector_user']}:{CONFIG['pgvector_password']}"
            f"@{CONFIG['pgvector_host']}:{CONFIG['pgvector_port']}/{CONFIG['pgvector_db']}"
        )
        self.collection_name = CONFIG.get("pgvector_collection_name", "code_chunks")
        self.table_name = CONFIG.get("pgvector_table_name", "langchain_pg_embedding")
        self.vectorstore = None
    
    def load_or_create(self) -> "CodeVectorStore":
        self.vectorstore = PGVector(
            connection_string=self.connection_string,
            embedding_function=self.embeddings,
            collection_name=self.collection_name
        )
        logger.info(
            f"Connected to PGVector at {CONFIG['pgvector_host']}:{CONFIG['pgvector_port']} "
            f"(collection: {self.collection_name}, table: {self.table_name})"
        )
        return self
    
    def _delete_by_relative_paths(self, paths: Set[str]) -> int:
        """Delete all documents with matching relative_path using direct SQL."""
        if not paths:
            return 0
        
        # Normalize to forward slashes for consistent matching
        paths = {p.replace("\\", "/") for p in paths}
        
        try:
            conn = psycopg2.connect(self.connection_string)
            cursor = conn.cursor()
            
            # Delete documents where metadata->>'relative_path' matches any of the paths
            deleted_count = 0
            deleted_details = []
            for path in paths:
                cursor.execute(
                    f"""
                    DELETE FROM {self.table_name}
                    WHERE cmetadata->>'relative_path' = %s
                    """,
                    (path,)
                )
                count = cursor.rowcount
                if count > 0:
                    deleted_details.append(f"  - {path}: {count} chunk(s)")
                deleted_count += count
            
            conn.commit()
            cursor.close()
            conn.close()
            
            if deleted_details:
                logger.info(f"Deleted {deleted_count} old chunks from {len(deleted_details)} file(s):\n" + "\n".join(deleted_details))
            else:
                logger.info(f"No old chunks to delete for {len(paths)} new file(s)")
            return deleted_count
        except Exception as e:
            logger.error(f"Error deleting old chunks: {e}")
            return 0
    
    def add_documents(self, docs: List[Document], replace_files: bool = True) -> "CodeVectorStore":
        if not docs:
            logger.warning("No documents to add")
            return self
        
        with self._lock:
            # Group documents by relative_path
            from collections import defaultdict
            path_chunks = defaultdict(list)
            for doc in docs:
                relative_path = doc.metadata.get("relative_path", "unknown")
                path_chunks[relative_path].append(doc)
            
            # Generate deterministic IDs using content hash to avoid collisions across batches
            import hashlib
            ids = []
            for doc in docs:
                relative_path = doc.metadata.get("relative_path", "unknown")
                content_hash = hashlib.md5(doc.page_content.encode()).hexdigest()[:12]
                doc_id = f"{relative_path}::{content_hash}"
                ids.append(doc_id)
                doc.metadata["doc_id"] = doc_id
            
            # Delete old chunks for files being re-indexed
            if replace_files:
                new_paths = set(path_chunks.keys())
                if new_paths:
                    self._delete_by_relative_paths(new_paths)
            
            # Add new documents with IDs
            self.vectorstore.add_documents(docs, ids=ids)
            logger.info(f"Added {len(docs)} chunks to index")
        return self
    
    def save(self) -> "CodeVectorStore":
        return self
    
    def search(self, query: str, k: int = 5, language: str = None) -> List[Document]:
        if not self.vectorstore:
            return []
        if language:
            return self.vectorstore.similarity_search(query, k=k, filter={"language": language})
        return self.vectorstore.similarity_search(query, k=k)

    def search_by_paths(self, query: str, relative_paths: List[str], k: int = 10) -> List[Document]:
        """Search for chunks only within specific file paths (graph-guided retrieval).
        Uses SQL to filter by relative_path, then ranks by vector similarity."""
        if not self.vectorstore or not relative_paths:
            return []
        try:
            from langchain_core.documents import Document as LCDocument
            conn = psycopg2.connect(self.connection_string)
            cursor = conn.cursor()

            embedding = self.embeddings.embed_query(query)
            embedding_str = "[" + ",".join(str(x) for x in embedding) + "]"

            placeholders = ",".join(["%s"] * len(relative_paths))
            cursor.execute(f"""
                SELECT document, cmetadata,
                       1 - (embedding <=> %s::vector) AS similarity
                FROM {self.table_name}
                WHERE cmetadata->>'relative_path' IN ({placeholders})
                ORDER BY embedding <=> %s::vector
                LIMIT %s
            """, (embedding_str, *relative_paths, embedding_str, k))

            docs = []
            for row in cursor.fetchall():
                content, metadata, similarity = row
                import json
                meta = json.loads(metadata) if isinstance(metadata, str) else metadata
                meta["similarity"] = similarity
                docs.append(LCDocument(page_content=content, metadata=meta))

            cursor.close()
            conn.close()
            return docs
        except Exception as e:
            logger.error(f"Graph-guided search failed: {e}")
            return self.search(query, k=k)
    
    def get_stats(self) -> Dict:
        if not self.vectorstore:
            return {"total": 0, "java": 0, "angular": 0, "unique_files": 0}
        
        try:
            # Use direct SQL query to avoid k limit
            conn = psycopg2.connect(self.connection_string)
            cursor = conn.cursor()
            
            # Get total count
            cursor.execute(f"SELECT COUNT(*) FROM {self.table_name}")
            total = cursor.fetchone()[0]
            
            # Get java count
            cursor.execute(
                f"SELECT COUNT(*) FROM {self.table_name} WHERE cmetadata->>'language' = 'java'"
            )
            java_count = cursor.fetchone()[0]
            
            # Get angular count
            cursor.execute(
                f"SELECT COUNT(*) FROM {self.table_name} WHERE cmetadata->>'language' = 'angular'"
            )
            angular_count = cursor.fetchone()[0]
            
            # Get unique file count
            cursor.execute(
                f"SELECT COUNT(DISTINCT cmetadata->>'relative_path') FROM {self.table_name}"
            )
            unique_files = cursor.fetchone()[0]
            
            cursor.close()
            conn.close()
            
            return {
                "total": total,
                "java": java_count,
                "angular": angular_count,
                "unique_files": unique_files
            }
        except Exception as e:
            logger.error(f"Failed to get stats: {e}")
            return {"total": 0, "java": 0, "angular": 0, "unique_files": 0}
    
    def has_chunks_for_repo(self, repo_dir: str) -> bool:
        """Check if any chunks exist from files in the given repo directory."""
        from pathlib import Path
        root = Path(repo_dir)
        if not root.exists():
            return False

        # Gather a sample of supported file relative paths from the repo
        sample_paths = []
        for ext, glob in [("java", "*.java"), ("ts", "*.ts")]:
            for f in root.rglob(glob):
                if ext == "ts" and ".spec." in f.name:
                    continue
                sample_paths.append(str(f.relative_to(root)).replace("\\", "/"))
                if len(sample_paths) >= 5:
                    break
            if len(sample_paths) >= 5:
                break

        if not sample_paths:
            return False

        try:
            conn = psycopg2.connect(self.connection_string)
            cursor = conn.cursor()
            placeholders = ",".join(["%s"] * len(sample_paths))
            cursor.execute(
                f"SELECT COUNT(*) FROM {self.table_name} "
                f"WHERE cmetadata->>'relative_path' IN ({placeholders})",
                tuple(sample_paths),
            )
            count = cursor.fetchone()[0]
            cursor.close()
            conn.close()
            return count > 0
        except Exception as e:
            logger.error(f"Error checking repo chunks: {e}")
            return False

    def has_chunks_for_label(self, label: str) -> bool:
        """Check if any chunks exist for a given repo label (backend/frontend).

        Uses language metadata: backend → java, frontend → angular.
        """
        try:
            conn = psycopg2.connect(self.connection_string)
            cursor = conn.cursor()

            if label == "backend":
                cursor.execute(
                    f"SELECT 1 FROM {self.table_name} "
                    f"WHERE cmetadata->>'language' = %s LIMIT 1",
                    ("java",),
                )
            elif label == "frontend":
                cursor.execute(
                    f"SELECT 1 FROM {self.table_name} "
                    f"WHERE cmetadata->>'language' = %s LIMIT 1",
                    ("angular",),
                )
            else:
                cursor.execute(f"SELECT 1 FROM {self.table_name} LIMIT 1")

            row = cursor.fetchone()
            cursor.close()
            conn.close()
            return row is not None
        except Exception as e:
            logger.error(f"Error checking chunks for label '{label}': {e}")
            return False

    def delete_all(self) -> bool:
        """Delete all documents from the vector store."""
        try:
            conn = psycopg2.connect(self.connection_string)
            cursor = conn.cursor()
            
            # Delete all documents from the table
            cursor.execute(f"DELETE FROM {self.table_name}")
            deleted_count = cursor.rowcount
            
            conn.commit()
            cursor.close()
            conn.close()
            
            logger.info(f"Deleted all {deleted_count} documents from vector store")
            return True
        except Exception as e:
            logger.error(f"Error deleting all documents: {e}")
            return False
        
        