import os
import uuid
import sys
import threading
import logging
from io import StringIO
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from fastapi import FastAPI, HTTPException, Header, Depends, Security, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from langgraph.types import Command
from prometheus_fastapi_instrumentator import Instrumentator
from Config.settings import CONFIG
from Chunker.ast_chunker import chunk_documents
from Utils.chunk_saver import save_chunks_to_json, delete_chunks_by_paths
from Vector_Store.store import CodeVectorStore
from Retriever.retriever import CodeRetriever
from Tools.search_tools import create_search_tools
from Graph.workflow import create_workflow
from Memory.agent_memory import AgentMemory
from Knowledge_Graph.graph_store import CodeGraphStore
from Knowledge_Graph.graph_builder import build_graph_from_chunks
from API.auth_api import router as auth_router
from API.pipeline_logs_api import router as pipeline_logs_router
from API.config_api import router as config_router

import redis
import json


def save_pipeline_log(
    pipeline_type: str,
    user_email: str, 
    model: str,
    status: str,
    input_text: str,
    output_text: str,
    jira_key: Optional[str] = None,
    refiner_model: Optional[str] = None,
    query_refined: bool = False,
    verifier_score: Optional[int] = None,
    human_approved: Optional[bool] = None,
    iterations: Optional[int] = None,
    snippets: list = [],
    feedback: Optional[str] = None,
    reasoning: Optional[str] = None
):
    """Save pipeline execution log to database"""
    try:
        import psycopg2
        from psycopg2.extras import RealDictCursor
        
        conn = psycopg2.connect(
            host=os.getenv("PGVECTOR_HOST", "localhost"),
            port=int(os.getenv("PGVECTOR_PORT", 5432)),
            database=os.getenv("PGVECTOR_DB", "rag"),
            user=os.getenv("PGVECTOR_USER", "postgres"),
            password=os.getenv("PGVECTOR_PASSWORD", "admin")
        )
        cur = conn.cursor(cursor_factory=RealDictCursor)
        
        cur.execute("""
            INSERT INTO pipeline_logs 
            (type, jira_key, user_email, model, refiner_model, query_refined, status, verifier_score, 
             human_approved, iterations, input_text, output_text, snippets, feedback, reasoning)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (
            pipeline_type, jira_key, user_email, model, refiner_model, query_refined, status,
            verifier_score, human_approved, iterations, input_text, output_text,
            json.dumps(snippets), feedback, reasoning
        ))
        result = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()
        if result:
            logger.info(f"Pipeline log created with ID: {result['id']}")
            return result['id']
        return None
    except Exception as e:
        logger.error(f"Failed to save pipeline log: {str(e)}")
        return None


logger = logging.getLogger(__name__)

try:
    redis_client = redis.Redis(
        host=CONFIG["redis_host"],
        port=CONFIG["redis_port"],
        decode_responses=True,
        socket_connect_timeout=1,
        socket_timeout=1
    )
    redis_client.ping()
    logger.info(f"Connected to Redis at {CONFIG['redis_host']}:{CONFIG['redis_port']}")
except Exception as e:
    logger.warning(f"Redis connection failed: {e}. Falling back to in-memory sessions.")
    redis_client = None

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

async def verify_api_key(api_key: str = Security(api_key_header)):
    if not CONFIG["api_keys"]:
        return "dev-mode"
    if not api_key or api_key not in CONFIG["api_keys"]:
        raise HTTPException(status_code=403, detail="Invalid API Key")
    return api_key

vector_store = CodeVectorStore().load_or_create()
retriever = CodeRetriever(vector_store)
memory = AgentMemory()
graph_store = CodeGraphStore()
tools = create_search_tools(retriever)
graph, checkpointer = create_workflow(vector_store, memory, graph_store)

workflow_logs: Dict[str, List[str]] = {}
workflow_logs_lock = threading.Lock()
session_lock = threading.Lock()

app = FastAPI(
    title="RAG Bug Fixing API",
    version="2.0",
    description="AI-powered code analysis with Human-in-the-Loop"
)

Instrumentator().instrument(app).expose(app)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include authentication router
app.include_router(auth_router)
app.include_router(pipeline_logs_router)
app.include_router(config_router)

# Initialize database tables on startup
try:
    from API.auth_api import init_users_table
    from API.pipeline_logs_api import init_pipeline_logs_table
    from API.config_api import init_config_table
    
    init_users_table()
    init_pipeline_logs_table()
    init_config_table()
    logger.info("Database tables initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize database tables: {e}")


class QueryRequest(BaseModel):
    query: str
    user_id: Optional[str] = None
    jira_key: Optional[str] = None
    error: Optional[str] = None  # Deprecated - use error_message
    error_message: Optional[str] = None
    log_content: Optional[str] = None
    file_hint: Optional[str] = None


class QueryResponse(BaseModel):
    thread_id: str
    query: str
    answer: Optional[str] = None
    status: str
    query_transforms: int = 0


class ResumeRequest(BaseModel):
    thread_id: str
    human: str
    feedback: Optional[str] = None
    user_id: Optional[str] = None
    jira_key: Optional[str] = None


class IndexRequest(BaseModel):
    path: str


class SessionData:
    def __init__(self, request: QueryRequest, user_id: Optional[str] = None):
        self.request = request
        self.user_id = user_id or "anonymous"
        self.created_at = datetime.now()


query_sessions: Dict[str, SessionData] = {}


def save_session_to_redis(thread_id: str, session_data: SessionData):
    """Save session to Redis cache."""
    if redis_client:
        try:
            data = {
                "query": session_data.request.query,
                "user_id": session_data.user_id,
                "error": session_data.request.error,
                "file_hint": session_data.request.file_hint,
                "created_at": session_data.created_at.isoformat()
            }
            redis_client.setex(
                f"session:{thread_id}",
                CONFIG.get("redis_ttl", 7200),
                json.dumps(data)
            )
        except Exception as e:
            logger.error(f"Redis save failed: {e}")


def get_session_from_redis(thread_id: str) -> Optional[SessionData]:
    """Retrieve session from Redis cache."""
    if redis_client:
        try:
            data = redis_client.get(f"session:{thread_id}")
            if data:
                parsed = json.loads(str(data) if data else "{}")
                request = QueryRequest(
                    query=parsed["query"],
                    user_id=parsed.get("user_id"),
                    error=parsed.get("error"),
                    file_hint=parsed.get("file_hint")
                )
                session = SessionData(request, parsed.get("user_id"))
                session.created_at = datetime.fromisoformat(parsed["created_at"])
                return session
        except Exception as e:
            logger.error(f"Redis get failed: {e}")
    
    # Fallback to in-memory
    return query_sessions.get(thread_id)


def cleanup_expired_sessions():
    """Remove sessions older than TTL."""
    with session_lock:
        ttl_hours = CONFIG.get("session_ttl_hours", 2)
        cutoff = datetime.now() - timedelta(hours=ttl_hours)
        expired = [k for k, v in query_sessions.items() if v.created_at < cutoff]
        for k in expired:
            del query_sessions[k]
            if k in workflow_logs:
                del workflow_logs[k]


@app.get("/health")
def health_check():
    """Health check endpoint."""
    cleanup_expired_sessions()
    
    redis_status = "connected"
    redis_info = {}
    if redis_client:
        try:
            redis_client.ping()
            info_memory = redis_client.info('memory')
            info_clients = redis_client.info('clients')
            redis_info = {
                "used_memory_human": info_memory.get("used_memory_human", "N/A") if isinstance(info_memory, dict) else "N/A",
                "connected_clients": info_clients.get('connected_clients', 0) if isinstance(info_clients, dict) else 0
            }
        except Exception as e:
            redis_status = f"error: {str(e)}"
    else:
        redis_status = "disabled"
    
    return {
        "status": "healthy",
        "index_stats": vector_store.get_stats(),
        "model": CONFIG["llm_model"],
        "redis": {
            "status": redis_status,
            **redis_info
        },
        "checkpointer": "SqliteSaver",
        "active_sessions": len(query_sessions)
    }


@app.delete("/admin/clear-db", tags=["admin"])
def clear_vector_db(api_key: str = Depends(verify_api_key)):
    """Clear all data from vector store"""
    try:
        success = vector_store.delete_all()
        if not success:
             raise HTTPException(status_code=500, detail="Failed to clear vector store")
        return {"message": "All data cleared successfully"}
    except Exception as e:
        logger.error(f"Error clearing DB: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/admin/clear-memory", tags=["admin"])
def clear_agent_memory(api_key: str = Depends(verify_api_key)):
    """Clear agent learning memory"""
    try:
        memory.clear()
        return {"message": "Agent memory cleared successfully"}
    except Exception as e:
        logger.error(f"Error clearing memory: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


def _get_last_sync_commit(label: str) -> Optional[str]:
    """Read last synced commit SHA from system_config table."""
    try:
        import psycopg2
        conn = psycopg2.connect(
            host=os.getenv("PGVECTOR_HOST", "localhost"),
            port=int(os.getenv("PGVECTOR_PORT", 5432)),
            database=os.getenv("PGVECTOR_DB", "rag"),
            user=os.getenv("PGVECTOR_USER", "postgres"),
            password=os.getenv("PGVECTOR_PASSWORD", "admin")
        )
        cur = conn.cursor()
        cur.execute(
            "SELECT config_value FROM system_config WHERE config_key = %s",
            (f"last_sync_commit_{label}",)
        )
        row = cur.fetchone()
        cur.close()
        conn.close()
        return row[0] if row else None
    except Exception as e:
        logger.warning(f"Could not read last sync commit for {label}: {e}")
        return None


def _save_last_sync_commit(label: str, commit_sha: str) -> None:
    """Save last synced commit SHA to system_config table."""
    try:
        import psycopg2
        conn = psycopg2.connect(
            host=os.getenv("PGVECTOR_HOST", "localhost"),
            port=int(os.getenv("PGVECTOR_PORT", 5432)),
            database=os.getenv("PGVECTOR_DB", "rag"),
            user=os.getenv("PGVECTOR_USER", "postgres"),
            password=os.getenv("PGVECTOR_PASSWORD", "admin")
        )
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO system_config (config_key, config_value, updated_at)
               VALUES (%s, %s, NOW())
               ON CONFLICT (config_key)
               DO UPDATE SET config_value = EXCLUDED.config_value, updated_at = NOW()""",
            (f"last_sync_commit_{label}", commit_sha)
        )
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        logger.error(f"Could not save last sync commit for {label}: {e}")


def _load_chunks_from_pgvector(vs):
    """Load all chunks from PGVector for graph rebuild."""
    import psycopg2
    from langchain_core.documents import Document as LCDoc
    conn = psycopg2.connect(vs.connection_string)
    cur = conn.cursor()
    cur.execute(f"SELECT document, cmetadata FROM {vs.table_name}")
    rows = cur.fetchall()
    cur.close()
    conn.close()

    chunks = []
    source_texts = {}
    for content, metadata in rows:
        meta = json.loads(metadata) if isinstance(metadata, str) else metadata
        chunks.append(LCDoc(page_content=content, metadata=meta))
        rpath = meta.get("relative_path", "")
        if rpath and meta.get("chunk_type") in ("class", "full_file"):
            source_texts[rpath] = content
    return chunks, source_texts


def _gitlab_sync_stream(label: str, project_key: str, branch_key: str, git_dir_key: str = ""):
    """Generator that streams SSE events for GitLab sync + ingestion pipeline.

    Uses GitLab REST API — files are fetched directly into memory,
    no local clone required.

    Behaviour:
      - no_changes  → skip processing entirely.
      - incremental → only chunk/embed added+modified files; delete removed.
      - full        → fetch all files, replace everything.
    """

    def generate():
        global vector_store, retriever, tools, graph, checkpointer, graph_store
        try:
            from Gitlab.gitlab_api import (
                get_latest_commit,
                fetch_all_files_as_documents,
                fetch_changed_files_as_documents,
            )

            gitlab_url = (CONFIG.get("gitlab_url") or "").rstrip("/")
            token = CONFIG.get("gitlab_token") or ""
            project = CONFIG.get(project_key, "")
            branch = CONFIG.get(branch_key, "") or "main"
            git_dir = CONFIG.get(git_dir_key, "") if git_dir_key else ""

            if not gitlab_url or not token or not project:
                yield f"data: {json.dumps({'phase': 'error', 'message': 'GitLab URL, token, or project not configured'})}\n\n"
                return

            # Phase 1 — Check latest commit
            yield f"data: {json.dumps({'phase': 'syncing', 'message': f'Fetching {label} from GitLab API...'})}\n\n"

            latest_commit = get_latest_commit(gitlab_url, token, project, branch)
            if not latest_commit:
                yield f"data: {json.dumps({'phase': 'error', 'message': 'Could not fetch latest commit from GitLab'})}\n\n"
                return

            previous_commit = _get_last_sync_commit(label)
            repo_has_chunks = vector_store.has_chunks_for_label(label)

            # Determine sync type
            if not previous_commit or not repo_has_chunks:
                sync_type = "full"
            elif previous_commit == latest_commit:
                sync_type = "no_changes"
            else:
                sync_type = "incremental"

            yield f"data: {json.dumps({'phase': 'synced', 'message': f'GitLab API fetch complete ({sync_type})', 'sync_type': sync_type})}\n\n"

            # — No changes
            if sync_type == "no_changes":
                stats = vector_store.get_stats()

                # Check if graph needs rebuilding (e.g. graph code added after initial sync)
                try:
                    g_stats = graph_store.get_stats()
                    graph_files = g_stats.get("files", 0)
                    vector_files = stats.get("unique_files", 0)
                    if vector_files > 0 and graph_files < vector_files * 0.5:
                        yield f"data: {json.dumps({'phase': 'graph_build', 'message': f'Graph underpopulated ({graph_files} vs {vector_files} files). Rebuilding...'})}\n\n"
                        chunks, src_texts = _load_chunks_from_pgvector(vector_store)
                        if chunks:
                            graph_store.clear_all()
                            g_result = build_graph_from_chunks(chunks, graph_store, src_texts)
                            g_msg = f"Graph rebuilt: {g_result['files']} files, {g_result['classes']} classes, {g_result['methods']} methods"
                            yield f"data: {json.dumps({'phase': 'graph_built', 'message': g_msg, 'graph_stats': g_result})}\n\n"
                        yield f"data: {json.dumps({'phase': 'done', 'message': 'Code up-to-date, graph rebuilt', 'stats': stats})}\n\n"
                        return
                except Exception as ge:
                    logger.warning(f"Graph rebuild check failed: {ge}")

                yield f"data: {json.dumps({'phase': 'done', 'message': 'Repository already up-to-date, nothing to process', 'chunks': 0, 'files': 0, 'stats': stats})}\n\n"
                return

            # — Incremental sync
            if sync_type == "incremental":
                yield f"data: {json.dumps({'phase': 'loading', 'message': f'Fetching changed files since last sync...'})}\n\n"
                documents, paths_to_upsert, paths_to_delete = fetch_changed_files_as_documents(
                    gitlab_url, token, project, branch, previous_commit, latest_commit, git_dir
                )

                # If compare timed out (too many changes), fall back to full sync
                if documents is None:
                    yield f"data: {json.dumps({'phase': 'synced', 'message': 'Too many changes for incremental sync, switching to full sync...'})}\n\n"
                    sync_type = "full"
                else:
                    total_changed = len(paths_to_upsert) + len(paths_to_delete)
                    yield f"data: {json.dumps({'phase': 'synced', 'message': f'Found {total_changed} changed file(s)', 'files_added': len(paths_to_upsert), 'files_deleted': len(paths_to_delete)})}\n\n"

                    # Delete removed files from vector store + JSON
                    if paths_to_delete:
                        yield f"data: {json.dumps({'phase': 'deleting', 'message': f'Removing {len(paths_to_delete)} deleted file(s) from index...'})}\n\n"
                        vector_store._delete_by_relative_paths(paths_to_delete)
                        delete_chunks_by_paths(paths_to_delete)

                    if not documents:
                        _save_last_sync_commit(label, latest_commit)
                        stats = vector_store.get_stats()
                        yield f"data: {json.dumps({'phase': 'done', 'message': 'No supported files to add/update', 'chunks': 0, 'files': 0, 'stats': stats})}\n\n"
                        return

                    yield f"data: {json.dumps({'phase': 'loaded', 'message': f'Fetched {len(documents)} file(s) to upsert', 'files': len(documents)})}\n\n"

                    # Chunk the documents
                    yield f"data: {json.dumps({'phase': 'chunking', 'message': f'Chunking {len(documents)} file(s)...'})}\n\n"
                    chunked_docs = chunk_documents(documents)
                    if not chunked_docs:
                        _save_last_sync_commit(label, latest_commit)
                        stats = vector_store.get_stats()
                        yield f"data: {json.dumps({'phase': 'done', 'message': 'Chunking produced no results', 'chunks': 0, 'files': len(documents), 'stats': stats})}\n\n"
                        return
                    total_chunks = len(chunked_docs)
                    yield f"data: {json.dumps({'phase': 'chunked', 'message': f'Created {total_chunks} chunks', 'total_chunks': total_chunks})}\n\n"

                    # Save to JSON
                    save_chunks_to_json(chunked_docs)

                    # Delete old embeddings for upserted paths, then embed in batches
                    vector_store._delete_by_relative_paths(paths_to_upsert)

                    BATCH_SIZE = 100
                    for i in range(0, total_chunks, BATCH_SIZE):
                        batch = chunked_docs[i:i + BATCH_SIZE]
                        done = min(i + BATCH_SIZE, total_chunks)
                        yield f"data: {json.dumps({'phase': 'embedding', 'message': f'Embedding {done}/{total_chunks}', 'embedded': done, 'total_chunks': total_chunks})}\n\n"
                        vector_store.add_documents(batch, replace_files=False)

                    vector_store.save()

                    # Update knowledge graph for changed files
                    yield f"data: {json.dumps({'phase': 'graph_update', 'message': 'Updating knowledge graph...'})}\n\n"
                    try:
                        for dp in paths_to_delete:
                            graph_store.clear_by_file(dp)
                        for up in paths_to_upsert:
                            graph_store.clear_by_file(up)
                        source_texts = {doc.metadata.get("relative_path", ""): doc.page_content for doc in documents if doc.metadata.get("relative_path")}
                        g_stats = build_graph_from_chunks(chunked_docs, graph_store, source_texts)
                        g_msg = f"Graph updated: {g_stats['files']} files, {g_stats['classes']} classes, {g_stats['methods']} methods"
                        yield f"data: {json.dumps({'phase': 'graph_updated', 'message': g_msg, 'graph_stats': g_stats})}\n\n"
                    except Exception as ge:
                        logger.error(f"Graph incremental update failed (non-blocking): {ge}")
                        yield f"data: {json.dumps({'phase': 'graph_warning', 'message': f'Graph update failed (non-blocking): {str(ge)}'})}\n\n"

            # — Full sync
            if sync_type == "full":
                yield f"data: {json.dumps({'phase': 'loading', 'message': f'Fetching all {label} files from GitLab API...'})}\n\n"
                documents = fetch_all_files_as_documents(
                    gitlab_url, token, project, branch, git_dir
                )

                if not documents:
                    yield f"data: {json.dumps({'phase': 'done', 'message': 'No supported files found', 'chunks': 0, 'files': 0})}\n\n"
                    return
                yield f"data: {json.dumps({'phase': 'loaded', 'message': f'Fetched {len(documents)} files via API', 'files': len(documents)})}\n\n"

                yield f"data: {json.dumps({'phase': 'chunking', 'message': f'Chunking {len(documents)} files...'})}\n\n"
                chunked_docs = chunk_documents(documents)
                if not chunked_docs:
                    yield f"data: {json.dumps({'phase': 'done', 'message': 'Chunking produced no results', 'chunks': 0, 'files': len(documents)})}\n\n"
                    return
                total_chunks = len(chunked_docs)
                yield f"data: {json.dumps({'phase': 'chunked', 'message': f'Created {total_chunks} chunks', 'total_chunks': total_chunks})}\n\n"

                save_chunks_to_json(chunked_docs)

                # Delete old chunks for ALL paths upfront, then embed in batches
                all_paths = set(doc.metadata.get("relative_path", "unknown") for doc in chunked_docs)
                vector_store._delete_by_relative_paths(all_paths)

                BATCH_SIZE = 100
                for i in range(0, total_chunks, BATCH_SIZE):
                    batch = chunked_docs[i:i + BATCH_SIZE]
                    done = min(i + BATCH_SIZE, total_chunks)
                    yield f"data: {json.dumps({'phase': 'embedding', 'message': f'Embedding {done}/{total_chunks}', 'embedded': done, 'total_chunks': total_chunks})}\n\n"
                    vector_store.add_documents(batch, replace_files=False)

                vector_store.save()

                # Rebuild knowledge graph for synced files (clear only these files, not the other codebase)
                yield f"data: {json.dumps({'phase': 'graph_build', 'message': 'Building knowledge graph in Neo4j...'})}\n\n"
                try:
                    for p in all_paths:
                        graph_store.clear_by_file(p)
                    source_texts = {doc.metadata.get("relative_path", ""): doc.page_content for doc in documents if doc.metadata.get("relative_path")}
                    g_stats = build_graph_from_chunks(chunked_docs, graph_store, source_texts)
                    g_msg = f"Graph built: {g_stats['files']} files, {g_stats['classes']} classes, {g_stats['methods']} methods, {g_stats['calls']} calls"
                    yield f"data: {json.dumps({'phase': 'graph_built', 'message': g_msg, 'graph_stats': g_stats})}\n\n"
                except Exception as ge:
                    logger.error(f"Graph full build failed (non-blocking): {ge}")
                    yield f"data: {json.dumps({'phase': 'graph_warning', 'message': f'Graph build failed (non-blocking): {str(ge)}'})}\n\n"

            # Save last synced commit to DB
            _save_last_sync_commit(label, latest_commit)

            # Refresh RAG components
            yield f"data: {json.dumps({'phase': 'refreshing', 'message': 'Refreshing RAG pipeline...'})}\n\n"
            retriever = CodeRetriever(vector_store)
            tools = create_search_tools(retriever)
            graph, checkpointer = create_workflow(vector_store, memory, graph_store)

            stats = vector_store.get_stats()
            yield f"data: {json.dumps({'phase': 'done', 'message': 'Pipeline refreshed', 'stats': stats})}\n\n"

        except Exception as e:
            logger.error(f"{label} GitLab sync error: {str(e)}")
            yield f"data: {json.dumps({'phase': 'error', 'message': str(e)})}\n\n"

    return generate


@app.post("/admin/gitlab-sync/backend", tags=["admin"])
def sync_backend_gitlab(api_key: str = Depends(verify_api_key)):
    """Sync the backend codebase from GitLab and ingest into RAG pipeline (SSE stream)"""
    gen = _gitlab_sync_stream("backend", "backend_project", "backend_branch")
    return StreamingResponse(gen(), media_type="text/event-stream")


@app.post("/admin/gitlab-sync/frontend", tags=["admin"])
def sync_frontend_gitlab(api_key: str = Depends(verify_api_key)):
    """Sync the frontend codebase from GitLab and ingest into RAG pipeline (SSE stream)"""
    gen = _gitlab_sync_stream("frontend", "frontend_project", "frontend_branch", "frontend_git_dir")
    return StreamingResponse(gen(), media_type="text/event-stream")


@app.post("/query")
def query_code(request: QueryRequest, api_key: str = Depends(verify_api_key)):
    old_stdout = sys.stdout
    try:
        # Use user_id as thread_id for session persistence per user
        # If no user_id provided, generate random 5-character ID
        if request.user_id:
            thread_id = request.user_id
        else:
            import random
            import string
            thread_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
        
        config = {"configurable": {"thread_id": thread_id}}
        
        with session_lock:
            session_data = SessionData(request, request.user_id)
            query_sessions[thread_id] = session_data
            save_session_to_redis(thread_id, session_data)

        # Build full_query before using it
        full_query = request.query
        if request.error:
            full_query += f" | Error: {request.error}"
        if request.file_hint:
            full_query += f" | File: {request.file_hint}"

        sys.stdout = log_capture = StringIO()
        with workflow_logs_lock:
            workflow_logs[thread_id] = []
        
        try:
            initial_state = {
                "original_query": full_query,
                "question": full_query,
                "user_id": request.user_id or "anonymous",
                "documents": [],
                "generation": "",
                "query_transform_count": 0,
                "generation_attempts": 0,
                "human": None,
                "feedback": None,
                "feedback_count": 0,
                "feedback_history": [],
                "memory_hit": False,
                "cached_response": None,
                "graph_context": "",
                "guided_file_paths": [],
                "final_report": None
            }

            result = graph.invoke(initial_state, config=config)  # type: ignore
            
        finally:
            sys.stdout = old_stdout
            captured_output = log_capture.getvalue()
            with workflow_logs_lock:
                workflow_logs[thread_id] = captured_output.split('\n') if captured_output else []
        
        output = result.get("final_report") or result.get("generation", "")
        is_cache_hit = result.get("memory_hit", False)
        status = "cache_hit" if is_cache_hit else ("completed" if result.get("final_report") else "needs_review")
        query_transform_count = result.get("query_transform_count", 0)
        
        # Get captured logs
        captured_logs = '\n'.join(workflow_logs.get(thread_id, []))
        
        save_pipeline_log(
            pipeline_type="query",
            jira_key=request.jira_key,
            user_email=request.user_id or "anonymous",
            model=CONFIG.get("llm_model", "llama3.1:8b"),
            refiner_model=CONFIG.get("refiner_model", "llama3.1:8b"),
            query_refined=(query_transform_count > 0),
            status=status,
            input_text=full_query[:5000],
            output_text=output[:10000],
            iterations=query_transform_count,
            snippets=[],
            reasoning=captured_logs
        )
        
        return {
            "thread_id": thread_id,
            "query": request.query,
            "answer": output,
            "query_transforms": result.get("query_transform_count", 0),
            "status": status,
            "logs": workflow_logs.get(thread_id, []) if not workflow_logs_lock.locked() else []
        }
        
    except Exception as exc:
        sys.stdout = old_stdout
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/resume")
def resume_analysis(request: ResumeRequest, api_key: str = Depends(verify_api_key)):
    """Resume workflow using Command(resume=...) pattern."""
    try:
        # Try Redis first, fallback to in-memory
        session_data = get_session_from_redis(request.thread_id)
        if not session_data:
            raise HTTPException(status_code=404, detail="Session not found")
        
        config = {"configurable": {"thread_id": request.thread_id}}
        
        current_state = graph.get_state(config)  # type: ignore
        if not current_state or not current_state.next:
            raise HTTPException(
                status_code=400, 
                detail="No active workflow to resume. This query has already completed."
            )
        
        updated_state = {}
        
        if request.human == "feedback" and request.feedback:
            if current_state and current_state.values:
                updated_state["feedback"] = request.feedback
                current_feedback_count = current_state.values.get("feedback_count", 0)
                updated_state["feedback_count"] = current_feedback_count + 1
                existing_history = list(current_state.values.get("feedback_history", []) or [])
                existing_history.append(request.feedback)
                updated_state["feedback_history"] = existing_history
        
        old_stdout = sys.stdout
        sys.stdout = log_capture = StringIO()
        
        try:
            result = graph.invoke(Command(resume=request.human, update=updated_state), config=config)  # type: ignore
        finally:
            sys.stdout = old_stdout
            captured_output = log_capture.getvalue()
            with workflow_logs_lock:
                if request.thread_id not in workflow_logs:
                    workflow_logs[request.thread_id] = []
                workflow_logs[request.thread_id].extend(captured_output.split('\n') if captured_output else [])
        
        answer = result.get("final_report") or result.get("generation", "")
        feedback_count = result.get("feedback_count", 0)
        
        # Get captured logs
        captured_logs = '\n'.join(workflow_logs.get(request.thread_id, []))
        
        save_pipeline_log(
            pipeline_type="resume",
            jira_key=request.jira_key,
            user_email=session_data.user_id,
            model=CONFIG.get("llm_model", "llama3.1:8b"),
            refiner_model=CONFIG.get("refiner_model", "llama3.1:8b"),
            query_refined=False,
            status="completed" if request.human == "approved" else "reanalyzed",
            input_text=session_data.request.query[:5000],
            output_text=answer[:10000],
            human_approved=(request.human == "approved"),
            iterations=feedback_count,
            feedback=request.feedback,
            snippets=[],
            reasoning=captured_logs
        )
        
        return {
            "thread_id": request.thread_id,
            "answer": answer,
            "status": "completed" if request.human == "approved" else "reanalyzed",
            "attempt": feedback_count if request.human == "feedback" else 0,
            "logs": workflow_logs.get(request.thread_id, [])
        }
        
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Resume error: {str(exc)}")


@app.post("/index")
def index_files(request: IndexRequest, api_key: str = Depends(verify_api_key)):
    """Index files from a directory or single file path."""
    global vector_store, retriever, tools, graph, checkpointer, graph_store
    
    try:
        path = request.path.strip()
        
        if not path or len(path) > 500:
            raise HTTPException(status_code=400, detail="Invalid path length")
        
        if not os.path.exists(path):
            raise HTTPException(status_code=400, detail=f"Path does not exist: {path}")
        
        # Load files
        documents = load_code_files(path)
        
        if not documents:
            raise HTTPException(status_code=400, detail="No supported files found (Java/TypeScript)")
        
        # Chunk documents
        chunked_docs = chunk_documents(documents)
        
        if not chunked_docs:
            raise HTTPException(status_code=400, detail="Failed to chunk documents")
        
        # Save chunks to JSON
        save_chunks_to_json(chunked_docs)

        # Add to vector store
        vector_store.add_documents(chunked_docs)
        vector_store.save()

        # Build knowledge graph
        graph_stats = None
        try:
            source_texts = {doc.metadata.get("relative_path", ""): doc.page_content for doc in documents if doc.metadata.get("relative_path")}
            graph_stats = build_graph_from_chunks(chunked_docs, graph_store, source_texts)
        except Exception as ge:
            logger.error(f"Graph build failed (non-blocking): {ge}")

        # Refresh components
        retriever = CodeRetriever(vector_store)
        tools = create_search_tools(retriever)
        graph, checkpointer = create_workflow(vector_store, memory, graph_store)

        stats = vector_store.get_stats()

        return {
            "message": f"Successfully indexed {len(chunked_docs)} chunks from {len(documents)} file(s)",
            "stats": stats,
            "graph_stats": graph_stats
        }
        
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/state/{thread_id}")
def get_state(thread_id: str):
    """Get the current state of an analysis thread."""
    try:
        config = {"configurable": {"thread_id": thread_id}}
        state = graph.get_state(config)  # type: ignore
        
        return {
            "thread_id": thread_id,
            "original_query": state.values.get("original_query", ""),
            "current_question": state.values.get("question", ""),
            "query_transforms": state.values.get("query_transform_count", 0),
            "feedback_count": state.values.get("feedback_count", 0),
            "final_report": state.values.get("final_report", ""),
            "human": state.values.get("human"),
            "is_approved": state.values.get("is_approved"),
            "next_nodes": list(state.next) if state.next else []
        }
        
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.delete("/index")
def clear_index(api_key: str = Depends(verify_api_key)):
    """Clear the entire vector store index."""
    global vector_store, retriever, tools, graph, checkpointer, graph_store
    
    try:
        # Reinitialize with empty store
        vector_store = CodeVectorStore().load_or_create()
        retriever = CodeRetriever(vector_store)
        tools = create_search_tools(retriever)
        graph, checkpointer = create_workflow(vector_store, memory, graph_store)
        
        return {"message": "Index cleared successfully", "stats": vector_store.get_stats()}
        
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/classes")
def list_classes():
    """List all indexed class names."""
    try:
        if not vector_store.vectorstore:
            return {"classes": [], "count": 0}
        
        import psycopg2
        conn = psycopg2.connect(vector_store.connection_string)
        cursor = conn.cursor()
        
        cursor.execute(
            f"""
            SELECT DISTINCT cmetadata->>'class_name' 
            FROM {vector_store.table_name}
            WHERE cmetadata->>'class_name' IS NOT NULL
            ORDER BY cmetadata->>'class_name'
            """
        )
        class_names = [row[0] for row in cursor.fetchall()]
        
        cursor.close()
        conn.close()
        
        return {
            "classes": class_names,
            "count": len(class_names)
        }
        
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.delete("/clear")
async def clear_vector_store(api_key: str = Depends(verify_api_key)):
    """Delete all documents from the vector store."""
    try:
        success = vector_store.delete_all()
        
        if success:
            stats = vector_store.get_stats()
            return {
                "message": "Vector store cleared successfully",
                "success": True,
                "stats": stats
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to clear vector store")
            
    except Exception as exc:
        logger.error(f"Error clearing vector store: {exc}")
        raise HTTPException(status_code=500, detail=str(exc))


# ==================== JIRA PROXY ====================

import httpx
import base64
from dotenv import load_dotenv


class JiraRequest(BaseModel):
    action: str
    projectKey: Optional[str] = None
    issueKey: Optional[str] = None
    jql: Optional[str] = None


def get_jira_config():
    """Get JIRA configuration from database with fallback to environment."""
    try:
        import psycopg2
        from psycopg2.extras import RealDictCursor
        
        conn = psycopg2.connect(
            host=os.getenv("PGVECTOR_HOST", "localhost"),
            port=int(os.getenv("PGVECTOR_PORT", 5432)),
            database=os.getenv("PGVECTOR_DB", "rag"),
            user=os.getenv("PGVECTOR_USER", "postgres"),
            password=os.getenv("PGVECTOR_PASSWORD", "admin")
        )
        cur = conn.cursor(cursor_factory=RealDictCursor)
        
        cur.execute("""
            SELECT config_key, config_value 
            FROM system_config 
            WHERE config_key IN ('jira_base_url', 'jira_email', 'jira_api_token')
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        
        config = {row["config_key"]: row["config_value"] for row in rows}
        
        return {
            "base_url": config.get("jira_base_url") or os.getenv("JIRA_BASE_URL", ""),
            "email": config.get("jira_email") or os.getenv("JIRA_EMAIL", ""),
            "api_token": config.get("jira_api_token") or os.getenv("JIRA_API_TOKEN", ""),
        }
    except Exception as e:
        logger.warning(f"Failed to load JIRA config from database, falling back to env: {e}")
        load_dotenv(override=True)
        return {
            "base_url": os.getenv("JIRA_BASE_URL", ""),
            "email": os.getenv("JIRA_EMAIL", ""),
            "api_token": os.getenv("JIRA_API_TOKEN", ""),
        }


def get_jira_auth_header(email: str, api_token: str) -> str:
    return f"Basic {base64.b64encode(f'{email}:{api_token}'.encode()).decode()}"


@app.post("/refine-query")
async def refine_query(request: QueryRequest, api_key: str = Depends(verify_api_key)):
    """Refine JIRA bug description into focused query. Auto-extracts errors from logs if provided."""
    from langchain_ollama import ChatOllama
    from Prompt_lib.query_refiner import QUERY_REFINER_PROMPT, ERROR_EXTRACTOR_PROMPT
    import re
    
    try:
        # Initialize Llama3.1:8b for fast query refinement
        refiner_llm = ChatOllama(
            model=CONFIG["refiner_model"],
            base_url=CONFIG["ollama_base_url"],
            temperature=0.3
        )
        
        # Step 1: Extract error from logs if logs provided and no manual error
        extracted_error = None
        if request.log_content and not request.error_message:
            try:
                error_prompt = ERROR_EXTRACTOR_PROMPT.format(log_content=request.log_content)
                error_response = refiner_llm.invoke(error_prompt)
                extracted_error = str(error_response.content).strip() if hasattr(error_response, 'content') else ""
                if extracted_error.lower() == "(none)":
                    extracted_error = None
                logger.info(f"Auto-extracted error from logs: {extracted_error}")
            except Exception as e:
                logger.warning(f"Failed to extract error from logs: {e}")
                extracted_error = None
        
        # Step 2: Prepare inputs for query refinement
        jira_desc = request.query or "(empty)"
        error_msg = request.error_message or extracted_error or "(none)"
        
        # Step 3: Refine the query
        prompt = QUERY_REFINER_PROMPT.format(
            jira_description=jira_desc,
            error_message=error_msg
        )
        
        # Get refined query from LLM
        response = refiner_llm.invoke(prompt)
        refined_query = str(response.content).strip() if hasattr(response, 'content') else ""
        
        # Remove common prefixes that LLM might add
        prefixes_to_remove = [
            "here is the refined query:",
            "here is a refined query:",
            "refined query:",
            "here's the refined query:",
            "here's a refined query:",
        ]
        
        refined_query_lower = refined_query.lower()
        for prefix in prefixes_to_remove:
            if refined_query_lower.startswith(prefix):
                refined_query = refined_query[len(prefix):].strip()
                break
        
        # Remove quotes if the entire response is wrapped in quotes
        if (refined_query.startswith('"') and refined_query.endswith('"')) or \
           (refined_query.startswith("'") and refined_query.endswith("'")):
            refined_query = refined_query[1:-1].strip()
        
        logger.info(f"Original query length: {len(request.query)}, Refined query length: {len(refined_query)}")
        
        return {
            "original_query": request.query,
            "refined_query": refined_query,
            "extracted_error": extracted_error,  # Return extracted error for UI to auto-fill
            "status": "success"
        }
        
    except Exception as e:
        logger.error(f"Query refinement error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to refine query: {str(e)}")


@app.api_route("/jira-proxy", methods=["POST", "OPTIONS"])
async def jira_proxy(request: JiraRequest):
    """Proxy requests to JIRA API to avoid CORS issues."""
    config = get_jira_config()
    if not config["base_url"] or not config["email"] or not config["api_token"]:
        raise HTTPException(status_code=500, detail="JIRA configuration not set in backend .env")
    
    base_url = config["base_url"].rstrip('/')
    auth_header = get_jira_auth_header(config["email"], config["api_token"])
    headers = {
        "Authorization": auth_header,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            if request.action == "test":
                response = await client.get(f"{base_url}/rest/api/3/myself", headers=headers)
                response.raise_for_status()
                data = response.json()
                return {"displayName": data.get("displayName"), "emailAddress": data.get("emailAddress")}
            
            elif request.action == "getProjects":
                response = await client.get(f"{base_url}/rest/api/3/project", headers=headers)
                response.raise_for_status()
                return response.json()
            
            elif request.action == "getIssues":
                # JIRA requires bounded queries - use project filter or search recent updated issues
                if request.projectKey:
                    jql = f'project = "{request.projectKey}" ORDER BY updated DESC'
                else:
                    # Get all issues updated in last 30 days as a bounded query
                    jql = 'updated >= -30d ORDER BY updated DESC'
                body = {
                    "jql": jql,
                    "maxResults": 100,
                    "fields": ["summary", "status", "priority", "assignee", "issuetype", "description", "created", "updated"]
                }
                response = await client.post(f"{base_url}/rest/api/3/search/jql", headers=headers, json=body)
                response.raise_for_status()
                data = response.json()
                return {"issues": data.get("issues", []), "total": data.get("total", 0)}
            
            elif request.action == "getIssue" and request.issueKey:
                response = await client.get(f"{base_url}/rest/api/3/issue/{request.issueKey}", headers=headers)
                response.raise_for_status()
                return response.json()
            
            else:
                raise HTTPException(status_code=400, detail=f"Unknown action: {request.action}")
                
    except httpx.HTTPStatusError as e:
        logger.error(f"JIRA API error: {e.response.status_code} - {e.response.text}")
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
    except Exception as e:
        logger.error(f"JIRA proxy error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== ADMIN MEMORY ENDPOINTS ====================


class MemoryTTLRequest(BaseModel):
    ttl_years: Optional[float] = None
    ttl_days: Optional[int] = None
    delete_before: Optional[str] = None


@app.post("/admin/memory-ttl", tags=["admin"])
def set_memory_ttl(request: MemoryTTLRequest, api_key: str = Depends(verify_api_key)):
    """Set memory TTL (time-to-live) for auto-expiry.
    Options: ttl_years, ttl_days, delete_before (YYYY-MM-DD)"""
    try:
        result = {}

        if request.delete_before:
            deleted = memory.delete_before_date(request.delete_before)
            result["deleted_before"] = {
                "cutoff_date": request.delete_before,
                "records_deleted": deleted
            }

        if request.ttl_years is not None:
            days = int(request.ttl_years * 365)
            updated = memory.set_ttl_days(days)
            result["ttl_updated"] = {
                "ttl_years": request.ttl_years,
                "ttl_days": days,
                "records_updated": updated
            }
        elif request.ttl_days is not None:
            updated = memory.set_ttl_days(request.ttl_days)
            result["ttl_updated"] = {
                "ttl_days": request.ttl_days,
                "records_updated": updated
            }

        if not result:
            raise HTTPException(
                status_code=400,
                detail="Provide ttl_years, ttl_days, or delete_before"
            )

        return {"message": "Memory TTL updated", **result}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error setting memory TTL: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/admin/memory-cleanup", tags=["admin"])
def cleanup_memory(api_key: str = Depends(verify_api_key)):
    """Run TTL cleanup - delete all expired memory records"""
    try:
        deleted = memory.cleanup_expired()
        return {"message": f"Cleaned up {deleted} expired records", "deleted": deleted}
    except Exception as e:
        logger.error(f"Error cleaning memory: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/admin/memory-stats", tags=["admin"])
def get_memory_stats(api_key: str = Depends(verify_api_key)):
    """Get agent memory statistics"""
    try:
        stats = memory.get_stats()
        return stats
    except Exception as e:
        logger.error(f"Error getting memory stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/admin/graph-stats", tags=["admin"])
def get_graph_stats(api_key: str = Depends(verify_api_key)):
    """Get knowledge graph statistics from Neo4j"""
    try:
        stats = graph_store.get_stats()
        return stats
    except Exception as e:
        logger.error(f"Error getting graph stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/admin/graph-rebuild", tags=["admin"])
def rebuild_graph(api_key: str = Depends(verify_api_key)):
    """Rebuild the knowledge graph from current vector store chunks"""
    try:
        chunks, source_texts = _load_chunks_from_pgvector(vector_store)
        if not chunks:
            return {"message": "No chunks in vector store to build graph from", "stats": {}}

        graph_store.clear_all()
        stats = build_graph_from_chunks(chunks, graph_store, source_texts)
        return {"message": "Graph rebuilt", "stats": stats}
    except Exception as e:
        logger.error(f"Error rebuilding graph: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== RUN SERVER ====================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
