import os
import logging
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)


logger = logging.getLogger(__name__)

def get_config_from_db(key: str, default: str = ""):
    """Get configuration from database with fallback to environment variable."""
    try:
        import psycopg2
        from psycopg2.extras import RealDictCursor
        
        conn = psycopg2.connect(
            host=os.getenv("PGVECTOR_HOST", "localhost"),
            port=int(os.getenv("PGVECTOR_PORT", 5432)),
            database=os.getenv("PGVECTOR_DB", "rag"),
            user=os.getenv("PGVECTOR_USER", "postgres"),
            password=os.getenv("PGVECTOR_PASSWORD", "admin")
        )
        cur = conn.cursor(cursor_factory=RealDictCursor)
        
        cur.execute("SELECT config_value FROM system_config WHERE config_key = %s", (key,))
        row = cur.fetchone()
        cur.close()
        conn.close()
        
        if row and row["config_value"]:
            return row["config_value"]
    except Exception as e:
        logger.debug(f"Failed to load {key} from database: {e}")
    
    return os.getenv(key.upper(), default)

CONFIG = {
    # LLM settings (Ollama - On-Prem)
    "llm_model": get_config_from_db("llm_model", "llama3.1:8b"),
    "refiner_model": get_config_from_db("refiner_model", "llama3.1:8b"),
    "embed_model": get_config_from_db("embed_model", "nomic-embed-text"),
    "temperature": float(get_config_from_db("temperature", "0")),
    "ollama_base_url": get_config_from_db("ollama_base_url", "http://localhost:11434"),
    
    # RAG settings
    "max_iterations": int(os.getenv("MAX_ITERATIONS", "10")),
    "retrieval_top_k": int(os.getenv("RETRIEVAL_TOP_K", "10")),
    
    # Paths
    "index_path": os.getenv("INDEX_PATH", "Vector_Store/code_index"),
    
    # RAG settings
    "max_query_transforms": int(os.getenv("MAX_QUERY_TRANSFORMS", "3")),
    "max_feedback_attempts": int(os.getenv("MAX_FEEDBACK_ATTEMPTS", "3")),
    
    # Session settings
    "session_ttl_hours": int(os.getenv("SESSION_TTL_HOURS", "2")),
    
    # Connection pool settings
    "pgvector_pool_size": int(os.getenv("PGVECTOR_POOL_SIZE", "20")),
    "pgvector_max_overflow": int(os.getenv("PGVECTOR_MAX_OVERFLOW", "10")),
    
    # API settings
    "api_keys": os.getenv("API_KEYS", "").split(",") if os.getenv("API_KEYS") else [],
    
    # PGVector settings
    "pgvector_host": os.getenv("PGVECTOR_HOST", "localhost"),
    "pgvector_port": int(os.getenv("PGVECTOR_PORT", "5432")),
    "pgvector_db": os.getenv("PGVECTOR_DB", "vectordb"),
    "pgvector_user": os.getenv("PGVECTOR_USER", "postgres"),
    "pgvector_password": os.getenv("PGVECTOR_PASSWORD", "postgres"),
    "pgvector_collection_name": os.getenv("PGVECTOR_COLLECTION_NAME", "code_chunks"),
    "pgvector_table_name": os.getenv("PGVECTOR_TABLE_NAME", "langchain_pg_embedding"),

    # Agent Memory settings
    "memory_similarity_threshold": float(os.getenv("MEMORY_SIMILARITY_THRESHOLD", "0.90")),
    "memory_ttl_days": int(os.getenv("MEMORY_TTL_DAYS", "1095")),

    # SQLite Checkpoint (On-Prem)
    "checkpoint_db": os.getenv("CHECKPOINT_DB", "checkpoints.db"),
    
    # Redis settings (On-Prem)
    "redis_host": os.getenv("REDIS_HOST", "localhost"),
    "redis_port": int(os.getenv("REDIS_PORT", "6379")),
    "redis_ttl": int(os.getenv("REDIS_TTL", "7200")),

    # Neo4j settings
    "neo4j_uri": os.getenv("NEO4J_URI", "bolt://localhost:7687"),
    "neo4j_user": os.getenv("NEO4J_USER", "neo4j"),
    "neo4j_password": os.getenv("NEO4J_PASSWORD", "12345678"),
    "neo4j_database": os.getenv("NEO4J_DATABASE", "neo4j"),

    # Graph retrieval settings
    "graph_search_depth": int(os.getenv("GRAPH_SEARCH_DEPTH", "2")),
    "graph_search_top_k": int(os.getenv("GRAPH_SEARCH_TOP_K", "10")),

    # GitLab settings
    "gitlab_url": get_config_from_db("gitlab_url", os.getenv("GITLAB_URL", "https://git.smartbox.in")),
    "gitlab_token": get_config_from_db("gitlab_token", os.getenv("GITLAB_TOKEN", "")),
    "gitlab_username": get_config_from_db("gitlab_username", os.getenv("GITLAB_USERNAME", "oauth2")),
    "backend_project": get_config_from_db("backend_project", os.getenv("BACKEND_PROJECT", "")),
    "backend_branch": get_config_from_db("backend_branch", os.getenv("BACKEND_BRANCH", "main")),
    "frontend_project": get_config_from_db("frontend_project", os.getenv("FRONTEND_PROJECT", "")),
    "frontend_branch": get_config_from_db("frontend_branch", os.getenv("FRONTEND_BRANCH", "main")),
    "frontend_git_dir": get_config_from_db("frontend_git_dir", os.getenv("FRONTEND_GIT_DIR", "src")),
}


class Settings:
    """Application settings."""
    
    def __init__(self):
        self.llm_model = CONFIG["llm_model"]
        self.embed_model = CONFIG["embed_model"]
        self.temperature = CONFIG["temperature"]
        self.max_iterations = CONFIG["max_iterations"]
        self.retrieval_top_k = CONFIG["retrieval_top_k"]
        self.index_path = CONFIG["index_path"]
        self.max_query_transforms = CONFIG["max_query_transforms"]
        self.max_feedback_attempts = CONFIG["max_feedback_attempts"]
        
        # Server config
        self.host = os.getenv("HOST", "0.0.0.0")
        self.port = int(os.getenv("PORT", "8000"))


settings = Settings()
