from .ingestion import ingest_code

__all__ = ["ingest_code"]
