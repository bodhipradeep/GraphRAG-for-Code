from File_loader.loader import load_code_files
from Chunker.ast_chunker import chunk_documents
from Vector_Store.store import CodeVectorStore


def ingest_code(path: str):

    # Load files
    documents = load_code_files(path)
    if not documents:
        print("No files found")
        return None

    # Chunk using AST
    chunks = chunk_documents(documents)

    # Add to vector store (replace by path to avoid duplicates)
    store = CodeVectorStore()
    store.load_or_create()
    store.add_documents(chunks, replace_files=True)
    store.save()

    print(f"Index stats: {store.get_stats()}")
    return store
