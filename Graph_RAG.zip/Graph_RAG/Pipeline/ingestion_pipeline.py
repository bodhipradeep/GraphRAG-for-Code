from pathlib import Path
from typing import List, Set
from langchain_core.documents import Document
from Vector_Store.store import CodeVectorStore
from File_loader.loader import load_code_files, load_changed_files
from Chunker.ast_chunker import chunk_documents
from Utils.chunk_saver import save_chunks_to_json, delete_chunks_by_paths
from Knowledge_Graph.graph_store import CodeGraphStore
from Knowledge_Graph.graph_builder import build_graph_from_chunks
from Config.settings import CONFIG


def ingest_code(path: str, index_path: str = None, replace_files: bool = True) -> CodeVectorStore:
    """
    Full ingestion pipeline: Load → Chunk → Index (Vector + Graph).
    Used for first-time sync or force-full-sync.
    """
    print(f"\n{'='*70}")
    print(f"INGESTION PIPELINE (Vector + Graph)")
    print(f"{'='*70}")
    print(f"Source: {path}")

    # Step 1: Load files
    print(f"\n Step 1: Loading files...")
    documents = load_code_files(path)

    if not documents:
        print("No files found")
        return None

    # Build source_texts map for graph builder (full file contents)
    source_texts = {}
    for doc in documents:
        rpath = doc.metadata.get("relative_path", "")
        if rpath:
            source_texts[rpath] = doc.page_content

    # Step 2: Chunk using AST
    print(f"\n Step 2: Chunking with AST...")
    chunks = chunk_documents(documents)

    # Step 2.5: Save chunks to JSON
    print(f"\n Step 2.5: Saving chunks to JSON...")
    save_chunks_to_json(chunks)

    # Step 3: Index into vector store
    print(f"\n Step 3: Indexing into vector store...")
    store = CodeVectorStore()
    store.load_or_create()
    store.add_documents(chunks, replace_files=replace_files)
    store.save()

    # Step 4: Build knowledge graph in Neo4j
    print(f"\n Step 4: Building knowledge graph in Neo4j...")
    try:
        graph_store = CodeGraphStore()
        graph_store.clear_all()
        graph_stats = build_graph_from_chunks(chunks, graph_store, source_texts)
        print(f"   Graph: {graph_stats['files']} files, {graph_stats['classes']} classes, "
              f"{graph_stats['methods']} methods, {graph_stats['calls']} calls")
        graph_store.close()
    except Exception as e:
        print(f"   ⚠️ Graph build failed (non-blocking): {e}")

    stats = store.get_stats()
    print(f"\n{'='*70}")
    print(f"INGESTION COMPLETE")
    print(f"{'='*70}")
    print(f"Total chunks: {stats['total']}")
    print(f"Java chunks: {stats['java']}")
    print(f"Angular chunks: {stats['angular']}")
    print(f"Unique files: {stats['unique_files']}")
    print(f"{'='*70}\n")

    return store


def ingest_incremental(
    repo_dir: str,
    changed_files: list[dict],
    vector_store: CodeVectorStore,
) -> dict:
    """
    Incremental ingestion: only process added/modified/deleted files.
    Updates both vector store and knowledge graph.
    """
    documents, paths_to_upsert, paths_to_delete = load_changed_files(
        repo_dir, changed_files
    )

    summary = {
        "files_upserted": len(paths_to_upsert),
        "files_deleted": len(paths_to_delete),
        "chunks_added": 0,
        "chunks_deleted": 0,
    }

    # Handle deleted files — remove from vector store + JSON + graph
    if paths_to_delete:
        vector_store._delete_by_relative_paths(paths_to_delete)
        delete_chunks_by_paths(paths_to_delete)
        summary["chunks_deleted"] += len(paths_to_delete)

        try:
            graph_store = CodeGraphStore()
            for path in paths_to_delete:
                graph_store.clear_by_file(path)
            graph_store.close()
        except Exception as e:
            print(f"   ⚠️ Graph cleanup for deleted files failed: {e}")

    # Handle added / modified files
    if documents:
        # Build source_texts for graph builder
        source_texts = {}
        for doc in documents:
            rpath = doc.metadata.get("relative_path", "")
            if rpath:
                source_texts[rpath] = doc.page_content

        chunks = chunk_documents(documents)
        if chunks:
            # Vector store update
            vector_store._delete_by_relative_paths(paths_to_upsert)
            vector_store.add_documents(chunks, replace_files=False)
            vector_store.save()
            save_chunks_to_json(chunks)
            summary["chunks_added"] = len(chunks)

            # Graph update — clear changed files then rebuild
            try:
                graph_store = CodeGraphStore()
                for path in paths_to_upsert:
                    graph_store.clear_by_file(path)
                graph_stats = build_graph_from_chunks(chunks, graph_store, source_texts)
                summary["graph_updated"] = graph_stats
                graph_store.close()
            except Exception as e:
                print(f"   ⚠️ Graph update for changed files failed: {e}")

    return summary


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        code_path = sys.argv[1]
        ingest_code(code_path)
    else:
        print("Usage: python ingestion_pipeline.py <path_to_code>")
        print("\nExample:")
        print("  python ingestion_pipeline.py ../files/java")
