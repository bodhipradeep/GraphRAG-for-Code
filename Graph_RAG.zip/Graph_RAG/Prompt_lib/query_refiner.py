"""
Query Refinement for RAG Pipeline
Extracts focused technical queries from JIRA descriptions and error messages
Note: Log files are auto-processed to extract errors and file names
"""

ERROR_EXTRACTOR_PROMPT = """Extract the most critical error or exception from the log content below.

Include the file name and line number if present in the error.
Return ONLY the error in a single line. If multiple errors exist, return the most severe one.
If no error found, return: (none)

Log Content:
{log_content}

Extracted Error:"""


QUERY_REFINER_PROMPT = """You are an expert at creating focused technical search queries from bug information.

Your task: Analyze the bug description and error message to create a precise natural language query for semantic code search.

CRITICAL INSTRUCTIONS:
1. IGNORE "Steps to reproduce" details - they are navigation steps, not code issues
2. Focus on WHAT is broken (functionality, validation, error) not HOW to reach it
3. Extract only the PRIMARY module/component (e.g., "User Management" not "Settings > User Management > Users")
4. Include file names, class names, method names ONLY if explicitly mentioned
5. Include line numbers if mentioned
6. Prioritize specific errors/exceptions over vague descriptions

OUTPUT REQUIREMENTS - READ CAREFULLY:
1. Return ONLY the refined query - NOTHING ELSE
2. NO explanations, NO notes, NO "(Note: ...)", NO preambles
3. NO structured format (NO "component:X, error_type:Y")
4. NO navigation paths (skip: "click Settings > User Management > Users")
5. Include: primary component, functionality, error type, exception names
6. Keep 1-3 sentences maximum
7. Use technical keywords that appear in code
8. DO NOT add any text after the query
9. DO NOT explain your reasoning
10. STOP immediately after the query

═══════════════════════════════════════════════════════════════
FEW-SHOT EXAMPLES (DO NOT COPY THESE - LEARN THE PATTERN):
═══════════════════════════════════════════════════════════════

[Example 1: Bug with Navigation Steps]
Bug Description: "Steps: Click Settings > User Management > Users > Add User. Enter invalid email. Expected: Show error. Actual: No error shown"
Error Message: (none)
→ User Management email validation missing error message for invalid email address

[Example 2: Bug with Procedural Details]
Bug Description: "Go to Reports module, click Generate, select PDF format. Application crashes."
Error Message: (none)
→ Reports module PDF generation crashes application

[Example 3: Error without File Name]
Bug Description: "Login fails when user enters credentials"
Error Message: "NullPointerException at UserService.getProfile() method"
→ UserService getProfile method NullPointerException during login authentication

[Example 4: Vague Description with Error]
Bug Description: "User reported issue"
Error Message: "Connection timeout occurred"
→ Connection timeout error

[Example 5: Specific Module Issue]
Bug Description: "Save button not working in User Management when adding new user"
Error Message: (none)
→ User Management save button not responding when adding new user

[Example 6: Error WITH File Name]
Bug Description: "Application crashes when generating reports"
Error Message: "ArrayIndexOutOfBoundsException at ReportGenerator.generatePDF(ReportGenerator.java:142)"
→ ReportGenerator.java generatePDF method ArrayIndexOutOfBoundsException index out of bounds line 142

[Example 7: Stack Trace WITH File]
Bug Description: "Authentication fails"
Error Message: "TypeError: Cannot read property 'token' at AuthService.validateToken(auth.service.ts:78)"
→ auth.service.ts AuthService validateToken method TypeError undefined token property line 78

═══════════════════════════════════════════════════════════════
YOUR ACTUAL TASK - PROCESS THE INPUT BELOW (NOT THE EXAMPLES ABOVE):
═══════════════════════════════════════════════════════════════

Bug Description: {jira_description}
Error Message: {error_message}

Refined Query:"""
