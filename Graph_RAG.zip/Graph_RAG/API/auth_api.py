import os
import uuid
import bcrypt
from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Header, Request
from pydantic import BaseModel, EmailStr
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

load_dotenv()

router = APIRouter(prefix="/auth", tags=["authentication"])

# Database connection
def get_db_connection():
    return psycopg2.connect(
        host=os.getenv("PGVECTOR_HOST", "localhost"),
        port=os.getenv("PGVECTOR_PORT", "5432"),
        database=os.getenv("PGVECTOR_DB", "vectordb"),
        user=os.getenv("PGVECTOR_USER", "postgres"),
        password=os.getenv("PGVECTOR_PASSWORD"),
    )

# Initialize database schema
def init_users_table():
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS rag_users (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    employee_id VARCHAR(50) UNIQUE NOT NULL,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    name VARCHAR(255) NOT NULL,
                    role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'developer')),
                    enabled BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE INDEX IF NOT EXISTS idx_rag_users_email ON rag_users(email);
                CREATE INDEX IF NOT EXISTS idx_rag_users_employee_id ON rag_users(employee_id);
            """)
            
            cur.execute("SELECT id FROM rag_users WHERE role = 'admin' LIMIT 1")
            if not cur.fetchone():
                admin_password_hash = bcrypt.hashpw(
                    "123456789".encode('utf-8'), 
                    bcrypt.gensalt()
                ).decode('utf-8')
                
                cur.execute("""
                    INSERT INTO rag_users (employee_id, email, password_hash, name, role, enabled)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, ('F6984', 'pradeep.kumar@fci-ccm.com', admin_password_hash, 'Pradeep Kumar', 'admin', True))
            
            conn.commit()
    except Exception as e:
        conn.rollback()
        raise
    finally:
        conn.close()

# Pydantic models
class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class LoginResponse(BaseModel):
    id: str
    employee_id: str
    email: str
    name: str
    role: str
    enabled: bool

class CreateUserRequest(BaseModel):
    employee_id: str
    email: EmailStr
    password: str
    name: str
    role: str = "developer"

class SignupRequest(BaseModel):
    employee_id: str
    first_name: str
    last_name: str
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    employee_id: str
    email: str
    name: str
    role: str
    enabled: bool
    created_at: str

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

# Dependency to verify admin role
async def verify_admin(authorization: Optional[str] = Header(None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header missing")
    return True

@router.post("/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT id, employee_id, email, password_hash, name, role, enabled
                FROM rag_users
                WHERE email = %s
            """, (request.email,))
            
            user = cur.fetchone()
            
            if not user:
                raise HTTPException(status_code=401, detail="Invalid email or password")
            
            if not user['enabled']:
                raise HTTPException(status_code=403, detail="Account disabled. Contact administrator.")
            
            if not bcrypt.checkpw(request.password.encode('utf-8'), user['password_hash'].encode('utf-8')):
                raise HTTPException(status_code=401, detail="Invalid email or password")
            
            return LoginResponse(
                id=str(user['id']),
                employee_id=user['employee_id'],
                email=user['email'],
                name=user['name'],
                role=user['role'],
                enabled=user['enabled']
            )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        conn.close()

@router.post("/signup", response_model=UserResponse)
async def signup(request: SignupRequest):
    conn = get_db_connection()
    try:
        if not request.employee_id or len(request.employee_id) < 3:
            raise HTTPException(status_code=400, detail="Invalid employee ID")
        
        if not request.first_name or not request.last_name:
            raise HTTPException(status_code=400, detail="First name and last name required")
        
        if len(request.password) < 8:
            raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
        
        role = "admin" if "@fci-ccm.com" in request.email and request.employee_id.startswith("ADM") else "developer"
        
        full_name = f"{request.first_name} {request.last_name}"
        
        password_hash = bcrypt.hashpw(
            request.password.encode('utf-8'), 
            bcrypt.gensalt()
        ).decode('utf-8')
        
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT email, employee_id FROM rag_users 
                WHERE email = %s OR employee_id = %s
            """, (request.email, request.employee_id))
            
            existing = cur.fetchone()
            if existing:
                if existing['email'] == request.email:
                    raise HTTPException(status_code=400, detail="Email already registered")
                if existing['employee_id'] == request.employee_id:
                    raise HTTPException(status_code=400, detail="Employee ID already exists")
            
            cur.execute("""
                INSERT INTO rag_users (employee_id, email, password_hash, name, role, enabled)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING id, employee_id, email, name, role, enabled, created_at
            """, (request.employee_id, request.email, password_hash, full_name, role, True))
            
            user = cur.fetchone()
            conn.commit()
            if not user:
                raise HTTPException(status_code=500, detail="Failed to create account: No user returned from DB.")
            return UserResponse(
                id=str(user['id']),
                employee_id=user['employee_id'],
                email=user['email'],
                name=user['name'],
                role=user['role'],
                enabled=user['enabled'],
                created_at=user['created_at'].isoformat()
            )
    
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create account: {str(e)}")
    finally:
        conn.close()

@router.post("/create-user", response_model=UserResponse)
async def create_user(request: CreateUserRequest, _: bool = Depends(verify_admin)):
    conn = get_db_connection()
    try:
        if request.role not in ['admin', 'developer']:
            raise HTTPException(status_code=400, detail="Role must be 'admin' or 'developer'")
        
        if not request.employee_id or len(request.employee_id) < 3:
            raise HTTPException(status_code=400, detail="Invalid employee ID")
        
        password_hash = bcrypt.hashpw(
            request.password.encode('utf-8'), 
            bcrypt.gensalt()
        ).decode('utf-8')
        
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT email, employee_id FROM rag_users 
                WHERE email = %s OR employee_id = %s
            """, (request.email, request.employee_id))
            
            existing = cur.fetchone()
            if existing:
                if existing['email'] == request.email:
                    raise HTTPException(status_code=400, detail="Email already exists")
                if existing['employee_id'] == request.employee_id:
                    raise HTTPException(status_code=400, detail="Employee ID already exists")
            
            cur.execute("""
                INSERT INTO rag_users (employee_id, email, password_hash, name, role, enabled)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING id, employee_id, email, name, role, enabled, created_at
            """, (request.employee_id, request.email, password_hash, request.name, request.role, True))
            
            user = cur.fetchone()
            conn.commit()
            if not user:
                raise HTTPException(status_code=500, detail="Failed to create user: No user returned from DB.")
            return UserResponse(
                id=str(user['id']),
                employee_id=user['employee_id'],
                email=user['email'],
                name=user['name'],
                role=user['role'],
                enabled=user['enabled'],
                created_at=user['created_at'].isoformat()
            )
    
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create user: {str(e)}")
    finally:
        conn.close()

@router.get("/users", response_model=list[UserResponse])
async def list_users(_: bool = Depends(verify_admin)):
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT id, employee_id, email, name, role, enabled, created_at
                FROM rag_users
                ORDER BY created_at DESC
            """)
            
            users = cur.fetchall()
            
            return [
                UserResponse(
                    id=str(user['id']),
                    employee_id=user['employee_id'],
                    email=user['email'],
                    name=user['name'],
                    role=user['role'],
                    enabled=user['enabled'],
                    created_at=user['created_at'].isoformat()
                )
                for user in users
            ]
    
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to fetch users")
    finally:
        conn.close()

@router.delete("/delete-user/{user_id}")
async def delete_user(user_id: str, _: bool = Depends(verify_admin)):
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT id, employee_id, name, role FROM rag_users WHERE id = %s
            """, (user_id,))
            
            user = cur.fetchone()
            
            if not user:
                raise HTTPException(status_code=404, detail="User not found")
            
            if user['role'] == 'admin':
                raise HTTPException(status_code=403, detail="Cannot delete admin users")
            
            cur.execute("DELETE FROM rag_users WHERE id = %s", (user_id,))
            conn.commit()
            
            return {
                "success": True,
                "message": f"User {user['employee_id']} - {user['name']} deleted successfully"
            }
    
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete user")
    finally:
        conn.close()

@router.put("/toggle-user/{user_id}", response_model=UserResponse)
async def toggle_user_status(user_id: str, enabled: bool, _: bool = Depends(verify_admin)):
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                UPDATE rag_users 
                SET enabled = %s, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s AND role != 'admin'
                RETURNING id, employee_id, email, name, role, enabled, created_at
            """, (enabled, user_id))
            
            user = cur.fetchone()
            if not user:
                raise HTTPException(status_code=404, detail="User not found or is admin")
            
            conn.commit()
            
            return UserResponse(
                id=str(user['id']),
                employee_id=user['employee_id'],
                email=user['email'],
                name=user['name'],
                role=user['role'],
                enabled=user['enabled'],
                created_at=user['created_at'].isoformat()
            )
    
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail="Failed to update user status")
    finally:
        conn.close()

@router.post("/change-password")
async def change_password(request: Request, body: ChangePasswordRequest):
    user_email = None
    # Extract user email from session or JWT (for demo, get from header)
    user_email = request.headers.get("x-user-email")
    if not user_email:
        raise HTTPException(status_code=401, detail="Unauthorized")
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT password_hash FROM rag_users WHERE email = %s", (user_email,))
            user = cur.fetchone()
            if not user:
                raise HTTPException(status_code=404, detail="User not found")
            if not bcrypt.checkpw(body.old_password.encode('utf-8'), user['password_hash'].encode('utf-8')):
                raise HTTPException(status_code=400, detail="Old password is incorrect")
            new_hash = bcrypt.hashpw(body.new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
            cur.execute("UPDATE rag_users SET password_hash = %s, updated_at = CURRENT_TIMESTAMP WHERE email = %s", (new_hash, user_email))
            conn.commit()
            return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to change password: {str(e)}")
    finally:
        conn.close()

try:
    init_users_table()
except Exception:
    pass
