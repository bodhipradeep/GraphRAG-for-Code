from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import psycopg2
from psycopg2.extras import RealDictCursor
import os

router = APIRouter(prefix="/config", tags=["configuration"])

PGVECTOR_DB = {
    "host": os.getenv("PGVECTOR_HOST", "localhost"),
    "port": int(os.getenv("PGVECTOR_PORT", 5432)),
    "database": os.getenv("PGVECTOR_DB", "rag"),
    "user": os.getenv("PGVECTOR_USER", "postgres"),
    "password": os.getenv("PGVECTOR_PASSWORD", "admin")
}

def get_db_connection():
    return psycopg2.connect(**PGVECTOR_DB)

def init_config_table():
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS system_config (
                id SERIAL PRIMARY KEY,
                config_key VARCHAR(100) UNIQUE NOT NULL,
                config_value TEXT,
                encrypted BOOLEAN DEFAULT FALSE,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by VARCHAR(255)
            )
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_system_config_key ON system_config(config_key)
        """)
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cur.close()
        conn.close()

class ConfigItem(BaseModel):
    config_key: str
    config_value: str

class JiraConfig(BaseModel):
    base_url: str
    email: str
    api_token: str
    project_keys: Optional[str] = ""

class LLMConfig(BaseModel):
    llm_model: str
    embed_model: str
    refiner_model: str
    ollama_base_url: str
    temperature: float

class GitLabConfig(BaseModel):
    gitlab_url: str
    gitlab_token: str
    gitlab_username: str
    backend_project: str
    backend_branch: str
    frontend_project: str
    frontend_branch: str
    frontend_git_dir: str

@router.get("/jira")
async def get_jira_config():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("""
            SELECT config_key, config_value 
            FROM system_config 
            WHERE config_key IN ('jira_base_url', 'jira_email', 'jira_api_token', 'jira_project_keys')
        """)
        rows = cur.fetchall()
        config = {row["config_key"]: row["config_value"] for row in rows}
        
        return {
            "base_url": config.get("jira_base_url", ""),
            "email": config.get("jira_email", ""),
            "api_token": config.get("jira_api_token", ""),
            "project_keys": config.get("jira_project_keys", "")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.post("/jira")
async def update_jira_config(config: JiraConfig):
    conn = None
    cur = None
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        configs = [
            ("jira_base_url", config.base_url),
            ("jira_email", config.email),
            ("jira_api_token", config.api_token),
            ("jira_project_keys", config.project_keys or "")
        ]
        
        for key, value in configs:
            cur.execute("""
                INSERT INTO system_config (config_key, config_value, encrypted, updated_at)
                VALUES (%s, %s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (config_key) 
                DO UPDATE SET config_value = %s, updated_at = CURRENT_TIMESTAMP
            """, (key, value, key == "jira_api_token", value))
        
        conn.commit()
        return {"success": True, "message": "JIRA configuration updated"}
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"Error saving JIRA config: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to save JIRA configuration: {str(e)}")
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

@router.get("/llm")
async def get_llm_config():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("""
            SELECT config_key, config_value 
            FROM system_config 
            WHERE config_key IN ('llm_model', 'embed_model', 'refiner_model', 'ollama_base_url', 'temperature')
        """)
        rows = cur.fetchall()
        config = {row["config_key"]: row["config_value"] for row in rows}
        
        return {
            "llm_model": config.get("llm_model", os.getenv("LLM_MODEL", "devstral:24b")),
            "embed_model": config.get("embed_model", os.getenv("EMBED_MODEL", "qwen3-embedding:8b")),
            "refiner_model": config.get("refiner_model", os.getenv("REFINER_MODEL", "llama3.1:8b")),
            "ollama_base_url": config.get("ollama_base_url", os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")),
            "temperature": float(config.get("temperature", os.getenv("TEMPERATURE", "0")))
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.post("/llm")
async def update_llm_config(config: LLMConfig):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        configs = [
            ("llm_model", config.llm_model),
            ("embed_model", config.embed_model),
            ("refiner_model", config.refiner_model),
            ("ollama_base_url", config.ollama_base_url),
            ("temperature", str(config.temperature))
        ]
        
        for key, value in configs:
            cur.execute("""
                INSERT INTO system_config (config_key, config_value, updated_at)
                VALUES (%s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (config_key) 
                DO UPDATE SET config_value = %s, updated_at = CURRENT_TIMESTAMP
            """, (key, value, value))
        
        conn.commit()

        # Refresh in-memory CONFIG
        _refresh_config_keys(["llm_model", "embed_model", "refiner_model", "ollama_base_url", "temperature"])

        return {"success": True, "message": "LLM configuration updated"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.get("/gitlab")
async def get_gitlab_config():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        keys = [
            'gitlab_url', 'gitlab_token', 'gitlab_username',
            'backend_project', 'backend_branch',
            'frontend_project', 'frontend_branch', 'frontend_git_dir',
        ]
        placeholders = ",".join(["%s"] * len(keys))
        cur.execute(
            f"SELECT config_key, config_value FROM system_config WHERE config_key IN ({placeholders})",
            tuple(keys),
        )
        rows = cur.fetchall()
        config = {row["config_key"]: row["config_value"] for row in rows}

        return {
            "gitlab_url": config.get("gitlab_url", os.getenv("GITLAB_URL", "https://git.smartbox.in")),
            "gitlab_token": config.get("gitlab_token", os.getenv("GITLAB_TOKEN", "")),
            "gitlab_username": config.get("gitlab_username", os.getenv("GITLAB_USERNAME", "oauth2")),
            "backend_project": config.get("backend_project", os.getenv("BACKEND_PROJECT", "")),
            "backend_branch": config.get("backend_branch", os.getenv("BACKEND_BRANCH", "main")),
            "frontend_project": config.get("frontend_project", os.getenv("FRONTEND_PROJECT", "")),
            "frontend_branch": config.get("frontend_branch", os.getenv("FRONTEND_BRANCH", "main")),
            "frontend_git_dir": config.get("frontend_git_dir", os.getenv("FRONTEND_GIT_DIR", "src")),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.post("/gitlab")
async def update_gitlab_config(config: GitLabConfig):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        configs = [
            ("gitlab_url", config.gitlab_url, False),
            ("gitlab_token", config.gitlab_token, True),
            ("gitlab_username", config.gitlab_username, False),
            ("backend_project", config.backend_project, False),
            ("backend_branch", config.backend_branch, False),
            ("frontend_project", config.frontend_project, False),
            ("frontend_branch", config.frontend_branch, False),
            ("frontend_git_dir", config.frontend_git_dir, False),
        ]

        for key, value, encrypted in configs:
            cur.execute("""
                INSERT INTO system_config (config_key, config_value, encrypted, updated_at)
                VALUES (%s, %s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (config_key)
                DO UPDATE SET config_value = %s, updated_at = CURRENT_TIMESTAMP
            """, (key, value, encrypted, value))

        conn.commit()

        # Refresh in-memory CONFIG
        _refresh_config_keys([k for k, _, _ in configs])

        return {"success": True, "message": "GitLab configuration updated"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

def _refresh_config_keys(keys: list[str]):
    """Reload specific keys from the DB into the in-memory CONFIG dict."""
    try:
        from Config.settings import CONFIG, get_config_from_db
        for key in keys:
            current_default = CONFIG.get(key, "")
            CONFIG[key] = get_config_from_db(key, str(current_default))
    except Exception:
        pass

@router.get("/all")
async def get_all_config():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("SELECT config_key, config_value, encrypted FROM system_config")
        rows = cur.fetchall()
        
        config = {}
        for row in rows:
            if row["encrypted"]:
                config[row["config_key"]] = "***hidden***"
            else:
                config[row["config_key"]] = row["config_value"]
        
        return config
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

init_config_table()
