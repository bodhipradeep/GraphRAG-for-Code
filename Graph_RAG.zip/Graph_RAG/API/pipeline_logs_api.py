from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import psycopg2
from psycopg2.extras import RealDictCursor
from datetime import datetime, timedelta
import os
import json

router = APIRouter(prefix="/pipeline-logs", tags=["pipeline-logs"])

PGVECTOR_DB = {
    "host": os.getenv("PGVECTOR_HOST", "localhost"),
    "port": int(os.getenv("PGVECTOR_PORT", 5432)),
    "database": os.getenv("PGVECTOR_DB", "rag"),
    "user": os.getenv("PGVECTOR_USER", "postgres"),
    "password": os.getenv("PGVECTOR_PASSWORD", "admin")
}

def get_db_connection():
    return psycopg2.connect(**PGVECTOR_DB)

def init_pipeline_logs_table():
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS pipeline_logs (
                id SERIAL PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                type VARCHAR(50),
                jira_key VARCHAR(100),
                user_email VARCHAR(255),
                model VARCHAR(100),
                refiner_model VARCHAR(100),
                query_refined BOOLEAN DEFAULT FALSE,
                status VARCHAR(50),
                verifier_score INTEGER,
                human_approved BOOLEAN,
                iterations INTEGER,
                input_text TEXT,
                output_text TEXT,
                snippets JSONB,
                feedback TEXT,
                reasoning TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cur.execute("""
            ALTER TABLE pipeline_logs ADD COLUMN IF NOT EXISTS iterations INTEGER
        """)
        cur.execute("""
            ALTER TABLE pipeline_logs ADD COLUMN IF NOT EXISTS refiner_model VARCHAR(100)
        """)
        cur.execute("""
            ALTER TABLE pipeline_logs ADD COLUMN IF NOT EXISTS query_refined BOOLEAN DEFAULT FALSE
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_pipeline_logs_timestamp ON pipeline_logs(timestamp DESC)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_pipeline_logs_jira_key ON pipeline_logs(jira_key)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_pipeline_logs_status ON pipeline_logs(status)
        """)
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cur.close()
        conn.close()

class PipelineLogCreate(BaseModel):
    type: str
    jira_key: Optional[str] = None
    user_email: str
    model: str
    status: str
    verifier_score: Optional[int] = None
    human_approved: Optional[bool] = None
    iterations: Optional[int] = None
    input_text: str
    output_text: str
    snippets: List[str] = []
    feedback: Optional[str] = None
    reasoning: Optional[str] = None

class PipelineLogResponse(BaseModel):
    id: int
    timestamp: str
    type: str
    jira_key: Optional[str]
    user_email: str
    model: str
    status: str
    verifier_score: Optional[int]
    human_approved: Optional[bool]
    iterations: Optional[int]
    input_text: str
    output_text: str
    snippets: List[str]
    feedback: Optional[str]
    reasoning: Optional[str]

@router.post("/create")
async def create_pipeline_log(log: PipelineLogCreate):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("""
            INSERT INTO pipeline_logs 
            (type, jira_key, user_email, model, status, verifier_score, human_approved, iterations,
             input_text, output_text, snippets, feedback, reasoning)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id, timestamp
        """, (
            log.type, log.jira_key, log.user_email, log.model, log.status,
            log.verifier_score, log.human_approved, log.iterations, log.input_text, log.output_text,
            json.dumps(log.snippets), log.feedback, log.reasoning
        ))
        result = cur.fetchone()
        conn.commit()
        return {"success": True, "id": result["id"], "timestamp": result["timestamp"].isoformat()}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.get("/list")
async def get_pipeline_logs(
    status: Optional[str] = None,
    type: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = 100
):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        query = """
            SELECT 
                pl.*,
                COALESCE(ru.name, pl.user_email) as user_name
            FROM pipeline_logs pl
            LEFT JOIN rag_users ru ON pl.user_email = ru.email
            WHERE 1=1
        """
        params = []
        
        if status and status != "all":
            query += " AND pl.status = %s"
            params.append(status)
        
        if type and type != "all":
            query += " AND pl.type = %s"
            params.append(type)
        
        if search:
            query += " AND (pl.jira_key ILIKE %s OR pl.user_email ILIKE %s OR ru.name ILIKE %s)"
            params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])
        
        query += " ORDER BY pl.timestamp DESC LIMIT %s"
        params.append(limit)
        
        cur.execute(query, params)
        rows = cur.fetchall()
        
        logs = []
        for row in rows:
            logs.append({
                "id": str(row["id"]),
                "timestamp": row["timestamp"].strftime("%Y-%m-%d %H:%M:%S"),
                "type": row["type"],
                "jiraKey": row["jira_key"],
                "user": row["user_name"],  # Use user name instead of email
                "userEmail": row["user_email"],  # Keep email for reference
                "model": row["model"],
                "refinerModel": row.get("refiner_model"),
                "queryRefined": row.get("query_refined", False),
                "status": row["status"],
                "verifierScore": row["verifier_score"],
                "humanApproved": row["human_approved"],
                "input": row["input_text"],
                "output": row["output_text"],
                "logs": row["reasoning"],  # Workflow logs stored in reasoning field
                "snippets": row["snippets"] if isinstance(row["snippets"], list) else json.loads(row["snippets"] or "[]"),
                "feedback": row["feedback"],
                "reasoning": row["reasoning"]
            })
        
        return logs
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.get("/dashboard-stats")
async def get_dashboard_stats():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("""
            SELECT 
                COUNT(*) as total_runs,
                COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as active_pipelines,
                COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_pipelines,
                COUNT(CASE WHEN human_approved = true THEN 1 END) as bugs_fixed,
                AVG(CASE WHEN verifier_score IS NOT NULL THEN verifier_score ELSE NULL END) as avg_verifier_score,
                AVG(CASE WHEN iterations IS NOT NULL THEN iterations ELSE NULL END) as avg_iterations
            FROM pipeline_logs
        """)
        stats = cur.fetchone()
        
        cur.execute("""
            SELECT id, type, jira_key, status, timestamp
            FROM pipeline_logs
            ORDER BY timestamp DESC
            LIMIT 5
        """)
        recent = cur.fetchall()
        
        recent_activity = []
        for row in recent:
            now = datetime.now()
            log_time = row["timestamp"]
            diff = now - log_time
            
            if diff.total_seconds() < 60:
                time_ago = f"{int(diff.total_seconds())} sec ago"
            elif diff.total_seconds() < 3600:
                time_ago = f"{int(diff.total_seconds() / 60)} min ago"
            elif diff.total_seconds() < 86400:
                time_ago = f"{int(diff.total_seconds() / 3600)} hour ago" if int(diff.total_seconds() / 3600) == 1 else f"{int(diff.total_seconds() / 3600)} hours ago"
            else:
                time_ago = f"{int(diff.total_seconds() / 86400)} day ago" if int(diff.total_seconds() / 86400) == 1 else f"{int(diff.total_seconds() / 86400)} days ago"
            
            recent_activity.append({
                "id": row["id"],
                "type": row["type"],
                "jiraKey": row["jira_key"],
                "status": row["status"],
                "time": time_ago
            })
        
        return {
            "systemStatus": {
                "health": "healthy" if stats["failed_pipelines"] == 0 else "degraded" if stats["failed_pipelines"] < 3 else "paused",
                "activePipelines": stats["active_pipelines"] or 0,
                "failedPipelines": stats["failed_pipelines"] or 0,
                "jiraConnected": True,
                "ragConnected": True
            },
            "kpiData": {
                "totalRuns": stats["total_runs"] or 0,
                "bugsFixed": stats["bugs_fixed"] or 0,
                "avgVerifierScore": round(float(stats["avg_verifier_score"] or 0), 1),
                "avgIterations": round(float(stats["avg_iterations"] or 0), 1)
            },
            "recentActivity": recent_activity
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.delete("/cleanup")
async def cleanup_old_logs():
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        three_months_ago = datetime.now() - timedelta(days=90)
        cur.execute("""
            DELETE FROM pipeline_logs WHERE timestamp < %s
        """, (three_months_ago,))
        deleted_count = cur.rowcount
        conn.commit()
        return {"success": True, "deleted_count": deleted_count}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

@router.get("/{log_id}")
async def get_pipeline_log(log_id: int):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("SELECT * FROM pipeline_logs WHERE id = %s", (log_id,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Log not found")
        
        return {
            "id": str(row["id"]),
            "timestamp": row["timestamp"].strftime("%Y-%m-%d %H:%M:%S"),
            "type": row["type"],
            "jiraKey": row["jira_key"],
            "user": row["user_email"],
            "model": row["model"],
            "status": row["status"],
            "verifierScore": row["verifier_score"],
            "humanApproved": row["human_approved"],
            "input": row["input_text"],
            "output": row["output_text"],
            "snippets": row["snippets"] if isinstance(row["snippets"], list) else json.loads(row["snippets"] or "[]"),
            "feedback": row["feedback"],
            "reasoning": row["reasoning"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()


@router.delete("/clear-all", dependencies=[])
def clear_all_logs():
    """Delete all pipeline logs"""
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("DELETE FROM pipeline_logs")
        count = cur.rowcount
        conn.commit()
        return {"message": f"Deleted {count} logs"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()



@router.delete("/clear-all", dependencies=[])
def clear_all_logs():
    """Delete all pipeline logs"""
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("DELETE FROM pipeline_logs")
        count = cur.rowcount
        conn.commit()
        return {"message": f"Deleted {count} logs"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        conn.close()

init_pipeline_logs_table()
