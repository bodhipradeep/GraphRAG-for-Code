import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Sparkles, Bug, Clock, CheckCircle2, AlertCircle } from "lucide-react";

interface ActivityItemProps {
  type: "feature" | "bug";
  title: string;
  jiraKey?: string;
  status: "in-progress" | "completed" | "needs-review";
  timestamp: string;
}

const statusConfig = {
  "in-progress": {
    label: "In Progress",
    variant: "info" as const,
    icon: Clock,
  },
  "completed": {
    label: "Completed",
    variant: "success" as const,
    icon: CheckCircle2,
  },
  "needs-review": {
    label: "Needs Review",
    variant: "warning" as const,
    icon: AlertCircle,
  },
};

export function ActivityItem({ type, title, jiraKey, status, timestamp }: ActivityItemProps) {
  const statusInfo = statusConfig[status];
  const StatusIcon = statusInfo.icon;

  return (
    <div className="flex items-center gap-4 rounded-lg border border-border bg-card/50 p-4 transition-all duration-200 hover:bg-card">
      <div className={cn(
        "flex h-10 w-10 items-center justify-center rounded-lg",
        type === "feature" ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
      )}>
        {type === "feature" ? <Sparkles className="h-5 w-5" /> : <Bug className="h-5 w-5" />}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          {jiraKey && (
            <span className="text-xs font-mono text-muted-foreground">{jiraKey}</span>
          )}
          <p className="truncate text-sm font-medium">{title}</p>
        </div>
        <p className="text-xs text-muted-foreground">{timestamp}</p>
      </div>

      <Badge variant={statusInfo.variant} className="flex items-center gap-1">
        <StatusIcon className="h-3 w-3" />
        {statusInfo.label}
      </Badge>
    </div>
  );
}
