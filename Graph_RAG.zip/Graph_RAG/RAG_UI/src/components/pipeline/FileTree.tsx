import { useState } from "react";
import { ChevronRight, ChevronDown, File, Folder, FolderOpen } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileNode {
  name: string;
  type: "file" | "folder";
  children?: FileNode[];
}

interface FileTreeProps {
  files: FileNode[];
  onSelectFile?: (path: string) => void;
}

function FileTreeNode({
  node,
  path,
  depth,
  onSelectFile,
}: {
  node: FileNode;
  path: string;
  depth: number;
  onSelectFile?: (path: string) => void;
}) {
  const [expanded, setExpanded] = useState(depth < 2);
  const fullPath = path ? `${path}/${node.name}` : node.name;

  const getFileIcon = (filename: string) => {
    if (filename.endsWith(".java")) return "☕";
    if (filename.endsWith(".md")) return "📝";
    if (filename.endsWith(".xml")) return "📄";
    if (filename.endsWith(".yaml") || filename.endsWith(".yml")) return "⚙️";
    if (filename.endsWith(".json")) return "📋";
    return null;
  };

  if (node.type === "file") {
    const icon = getFileIcon(node.name);
    return (
      <button
        className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm hover:bg-accent/50 transition-colors"
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
        onClick={() => onSelectFile?.(fullPath)}
      >
        {icon ? (
          <span className="text-xs">{icon}</span>
        ) : (
          <File className="h-4 w-4 text-muted-foreground" />
        )}
        <span className="font-mono text-xs">{node.name}</span>
      </button>
    );
  }

  return (
    <div>
      <button
        className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm hover:bg-accent/50 transition-colors"
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
        onClick={() => setExpanded(!expanded)}
      >
        {expanded ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        )}
        {expanded ? (
          <FolderOpen className="h-4 w-4 text-primary" />
        ) : (
          <Folder className="h-4 w-4 text-primary" />
        )}
        <span className="font-medium">{node.name}</span>
      </button>
      {expanded && node.children && (
        <div>
          {node.children.map((child, index) => (
            <FileTreeNode
              key={`${fullPath}-${child.name}-${index}`}
              node={child}
              path={fullPath}
              depth={depth + 1}
              onSelectFile={onSelectFile}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function FileTree({ files, onSelectFile }: FileTreeProps) {
  return (
    <div className="rounded-lg border border-border bg-card/50 p-2">
      {files.map((file, index) => (
        <FileTreeNode
          key={`${file.name}-${index}`}
          node={file}
          path=""
          depth={0}
          onSelectFile={onSelectFile}
        />
      ))}
    </div>
  );
}
