import { cn } from "@/lib/utils";
import { Check, Loader2, Circle } from "lucide-react";

interface Step {
  id: string;
  label: string;
  description?: string;
}

interface PipelineProgressProps {
  steps: Step[];
  currentStep: number;
  className?: string;
}

export function PipelineProgress({ steps, currentStep, className }: PipelineProgressProps) {
  return (
    <div className={cn("space-y-4", className)}>
      {steps.map((step, index) => {
        const isCompleted = index < currentStep;
        const isCurrent = index === currentStep;
        const isPending = index > currentStep;

        return (
          <div key={step.id} className="flex items-start gap-4">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full border-2 transition-all duration-300",
                  isCompleted && "border-success bg-success text-success-foreground",
                  isCurrent && "border-primary bg-primary/20 text-primary",
                  isPending && "border-muted bg-muted text-muted-foreground"
                )}
              >
                {isCompleted && <Check className="h-4 w-4" />}
                {isCurrent && <Loader2 className="h-4 w-4 animate-spin" />}
                {isPending && <Circle className="h-3 w-3" />}
              </div>
              {index < steps.length - 1 && (
                <div
                  className={cn(
                    "mt-2 h-12 w-0.5 transition-colors duration-300",
                    isCompleted ? "bg-success" : "bg-muted"
                  )}
                />
              )}
            </div>

            <div className="flex-1 pt-1">
              <p
                className={cn(
                  "text-sm font-medium transition-colors",
                  isCompleted && "text-success",
                  isCurrent && "text-primary",
                  isPending && "text-muted-foreground"
                )}
              >
                {step.label}
              </p>
              {step.description && (
                <p className="mt-0.5 text-xs text-muted-foreground">{step.description}</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
