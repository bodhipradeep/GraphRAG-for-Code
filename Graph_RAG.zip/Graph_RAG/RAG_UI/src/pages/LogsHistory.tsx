import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, Sparkles, Bug, CheckCircle2, XCircle, Clock, Eye } from "lucide-react";
import { cn } from "@/lib/utils";
import { VerificationScores } from "@/components/pipeline/VerificationScores";

interface LogEntry {
  id: string;
  timestamp: string;
  type: "feature" | "bug";
  jiraKey: string | null;
  title: string;
  status: "in-progress" | "completed" | "failed" | "needs-review";
  decision: "approved" | "rejected" | null;
  scores: { label: string; value: number; maxValue: number }[];
  brdText?: string;
  feedback?: string;
}

const mockLogs: LogEntry[] = [
  {
    id: "1",
    timestamp: "2024-01-15 14:32",
    type: "feature",
    jiraKey: "FCI-123",
    title: "Implement user authentication flow",
    status: "completed",
    decision: "approved",
    scores: [
      { label: "Completeness", value: 9, maxValue: 10 },
      { label: "Test Coverage", value: 8, maxValue: 10 },
      { label: "Code Style", value: 9, maxValue: 10 },
      { label: "Security", value: 8, maxValue: 10 },
    ],
    brdText: "Implement a comprehensive user authentication flow including login, registration...",
    feedback: "Excellent implementation. Ready for production.",
  },
  {
    id: "2",
    timestamp: "2024-01-15 12:18",
    type: "bug",
    jiraKey: "FCI-124",
    title: "Fix null pointer exception in payment service",
    status: "in-progress",
    decision: null,
    scores: [],
  },
  {
    id: "3",
    timestamp: "2024-01-15 10:45",
    type: "feature",
    jiraKey: "FCI-125",
    title: "Add dark mode support to dashboard",
    status: "needs-review",
    decision: null,
    scores: [
      { label: "Completeness", value: 7, maxValue: 10 },
      { label: "Test Coverage", value: 6, maxValue: 10 },
      { label: "Code Style", value: 8, maxValue: 10 },
      { label: "Security", value: 9, maxValue: 10 },
    ],
  },
  {
    id: "4",
    timestamp: "2024-01-14 16:22",
    type: "bug",
    jiraKey: "FCI-127",
    title: "Memory leak in cache manager",
    status: "completed",
    decision: "approved",
    scores: [
      { label: "Fix Correctness", value: 10, maxValue: 10 },
      { label: "Test Coverage", value: 9, maxValue: 10 },
      { label: "No Regressions", value: 10, maxValue: 10 },
      { label: "Code Quality", value: 9, maxValue: 10 },
    ],
    feedback: "Fix verified and deployed to staging.",
  },
  {
    id: "5",
    timestamp: "2024-01-14 11:05",
    type: "feature",
    jiraKey: null,
    title: "Manual feature generation test",
    status: "failed",
    decision: null,
    scores: [],
  },
  {
    id: "6",
    timestamp: "2024-01-13 09:30",
    type: "feature",
    jiraKey: "FCI-128",
    title: "Implement OAuth2 integration",
    status: "completed",
    decision: "rejected",
    scores: [
      { label: "Completeness", value: 5, maxValue: 10 },
      { label: "Test Coverage", value: 4, maxValue: 10 },
      { label: "Code Style", value: 7, maxValue: 10 },
      { label: "Security", value: 6, maxValue: 10 },
    ],
    feedback: "Needs more comprehensive error handling. Regenerating with updated requirements.",
  },
];

const statusConfig = {
  "in-progress": { label: "In Progress", variant: "info" as const, icon: Clock },
  "completed": { label: "Completed", variant: "success" as const, icon: CheckCircle2 },
  "failed": { label: "Failed", variant: "destructive" as const, icon: XCircle },
  "needs-review": { label: "Needs Review", variant: "warning" as const, icon: Clock },
};

const LogsHistory = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);

  const filteredLogs = mockLogs.filter((log) => {
    const matchesSearch = log.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.jiraKey?.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesType = typeFilter === "all" || log.type === typeFilter;
    const matchesStatus = statusFilter === "all" || log.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Logs & History</h1>
          <p className="text-muted-foreground">
            View all AI pipeline runs and their results
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search logs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="feature">Feature</SelectItem>
                <SelectItem value="bug">Bug Fix</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="needs-review">Needs Review</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Table */}
        <div className="rounded-xl border border-border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50 hover:bg-muted/50">
                <TableHead className="w-36">Date / Time</TableHead>
                <TableHead className="w-24">Type</TableHead>
                <TableHead className="w-24">JIRA Key</TableHead>
                <TableHead>Title</TableHead>
                <TableHead className="w-32">Status</TableHead>
                <TableHead className="w-28">Decision</TableHead>
                <TableHead className="w-20 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.map((log) => {
                const statusInfo = statusConfig[log.status];
                const StatusIcon = statusInfo.icon;
                return (
                  <TableRow key={log.id} className="hover:bg-accent/50">
                    <TableCell className="font-mono text-sm text-muted-foreground">
                      {log.timestamp}
                    </TableCell>
                    <TableCell>
                      <Badge variant={log.type === "feature" ? "task" : "bug"} className="gap-1">
                        {log.type === "feature" ? <Sparkles className="h-3 w-3" /> : <Bug className="h-3 w-3" />}
                        {log.type === "feature" ? "Feature" : "Bug"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {log.jiraKey ? (
                        <span className="font-mono text-sm text-primary">{log.jiraKey}</span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className="line-clamp-1">{log.title}</span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={statusInfo.variant} className="gap-1">
                        <StatusIcon className="h-3 w-3" />
                        {statusInfo.label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {log.decision ? (
                        <Badge
                          variant={log.decision === "approved" ? "success" : "destructive"}
                          className="gap-1"
                        >
                          {log.decision === "approved" ? (
                            <CheckCircle2 className="h-3 w-3" />
                          ) : (
                            <XCircle className="h-3 w-3" />
                          )}
                          {log.decision === "approved" ? "Approved" : "Rejected"}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedLog(log)}
                        className="gap-1"
                      >
                        <Eye className="h-4 w-4" />
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* Detail Dialog */}
        <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
          <DialogContent className="max-w-2xl">
            {selectedLog && (
              <>
                <DialogHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge variant={selectedLog.type === "feature" ? "task" : "bug"}>
                      {selectedLog.type === "feature" ? "Feature" : "Bug Fix"}
                    </Badge>
                    {selectedLog.jiraKey && (
                      <span className="font-mono text-sm text-primary">{selectedLog.jiraKey}</span>
                    )}
                  </div>
                  <DialogTitle>{selectedLog.title}</DialogTitle>
                  <DialogDescription>
                    {selectedLog.timestamp}
                  </DialogDescription>
                </DialogHeader>

                <Tabs defaultValue="scores" className="mt-4">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="scores">Verification Scores</TabsTrigger>
                    <TabsTrigger value="source">Source Text</TabsTrigger>
                    <TabsTrigger value="feedback">Feedback</TabsTrigger>
                  </TabsList>

                  <TabsContent value="scores" className="mt-4">
                    {selectedLog.scores.length > 0 ? (
                      <VerificationScores scores={selectedLog.scores} />
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        No verification scores available
                      </p>
                    )}
                  </TabsContent>

                  <TabsContent value="source" className="mt-4">
                    {selectedLog.brdText ? (
                      <div className="rounded-lg bg-muted/50 p-4 text-sm">
                        {selectedLog.brdText}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        No source text available
                      </p>
                    )}
                  </TabsContent>

                  <TabsContent value="feedback" className="mt-4">
                    {selectedLog.feedback ? (
                      <div className="rounded-lg bg-muted/50 p-4 text-sm">
                        {selectedLog.feedback}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        No feedback available
                      </p>
                    )}
                  </TabsContent>
                </Tabs>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default LogsHistory;
