import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { JiraTaskTable, JiraTask } from "@/components/jira/JiraTaskTable";
import { TaskDrawer } from "@/components/jira/TaskDrawer";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Settings } from "lucide-react";
import { Link } from "react-router-dom";

const JiraTasks = () => {
  const [selectedTask, setSelectedTask] = useState<JiraTask | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleSelectTask = (task: JiraTask) => {
    setSelectedTask(task);
    setDrawerOpen(true);
  };

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Connection Status Banner */}
        <div className="flex items-center justify-between rounded-xl border border-success/30 bg-success/10 p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/20">
              <CheckCircle2 className="h-5 w-5 text-success" />
            </div>
            <div>
              <p className="font-medium text-success">Connected to JIRA</p>
              <p className="text-sm text-muted-foreground">Select a project from the board below</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/settings" className="gap-2">
                <Settings className="h-4 w-4" />
                Configure
              </Link>
            </Button>
          </div>
        </div>

        {/* Page Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">JIRA Tasks</h1>
          <p className="text-muted-foreground">
            Select a task to run through the AI pipeline. Tasks are automatically categorized for the appropriate pipeline.
          </p>
        </div>

        {/* Task Table */}
        <JiraTaskTable onSelectTask={handleSelectTask} />

        {/* Task Drawer */}
        <TaskDrawer
          task={selectedTask}
          open={drawerOpen}
          onOpenChange={setDrawerOpen}
        />
      </div>
    </Layout>
  );
};

export default JiraTasks;
