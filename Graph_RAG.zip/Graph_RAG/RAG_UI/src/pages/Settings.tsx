import { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "@/hooks/use-toast";
import { Link2, Brain, Database, CheckCircle2, XCircle, Loader2, Info, Server, RefreshCw } from "lucide-react";
import { testJiraConnection } from "@/services/jiraApi";
import { getHealth, type HealthResponse } from "@/services/ragApi";

const Settings = () => {
  // JIRA state
  const [jiraTesting, setJiraTesting] = useState(false);
  const [jiraConnected, setJiraConnected] = useState<boolean | null>(null);
  const [jiraUser, setJiraUser] = useState<string | null>(null);

  // Backend health state
  const [backendHealth, setBackendHealth] = useState<HealthResponse | null>(null);
  const [healthLoading, setHealthLoading] = useState(false);

  // RAG settings (read from env, can be overridden)
  const [ragApiUrl, setRagApiUrl] = useState(import.meta.env.VITE_RAG_API_URL || "http://localhost:8000");
  const [topK, setTopK] = useState([5]);

  // Load backend health and test Jira on mount
  useEffect(() => {
    checkBackendHealth();
    handleTestJira();
  }, []);

  const checkBackendHealth = async () => {
    setHealthLoading(true);
    try {
      const health = await getHealth();
      setBackendHealth(health);
    } catch {
      setBackendHealth(null);
    }
    setHealthLoading(false);
  };

  const handleTestJira = async () => {
    setJiraTesting(true);
    const result = await testJiraConnection();
    setJiraTesting(false);

    if (result.success) {
      setJiraConnected(true);
      setJiraUser(result.user?.displayName || result.user?.emailAddress || 'Connected');
    } else {
      setJiraConnected(false);
      setJiraUser(null);
    }
  };

  const handleSave = () => {
    // Save to localStorage for persistence
    localStorage.setItem('rag_api_url', ragApiUrl);
    localStorage.setItem('rag_top_k', topK[0].toString());
    toast({
      title: "Settings Saved",
      description: "Your configuration has been updated.",
    });
  };

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in max-w-3xl">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground">
            Configure integrations and AI model settings
          </p>
        </div>

        {/* JIRA Integration */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Link2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle>JIRA Integration</CardTitle>
                  <CardDescription>Connect to your Atlassian Cloud instance</CardDescription>
                </div>
              </div>
              <Badge variant={jiraConnected === true ? "success" : jiraConnected === false ? "destructive" : "secondary"} className="gap-1">
                {jiraConnected === true ? (
                  <>
                    <CheckCircle2 className="h-3 w-3" />
                    Connected
                  </>
                ) : jiraConnected === false ? (
                  <>
                    <XCircle className="h-3 w-3" />
                    Failed
                  </>
                ) : (
                  "Not tested"
                )}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant="default" className="bg-muted/50">
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>Configuration:</strong> Set JIRA credentials in the Admin panel (JIRA Integration tab) to save them to the backend database.
              </AlertDescription>
            </Alert>

            <div className="p-3 rounded-lg bg-muted/30 border">
              {jiraConnected === true ? (
                <>
                  <p className="text-sm">
                    <span className="text-muted-foreground">Status:</span>{" "}
                    <span className="font-medium text-success">Connected to JIRA</span>
                  </p>
                  {jiraUser && (
                    <p className="text-sm mt-1">
                      <span className="text-muted-foreground">Connected as:</span>{" "}
                      <span className="font-medium">{jiraUser}</span>
                    </p>
                  )}
                </>
              ) : jiraConnected === false ? (
                <p className="text-sm">
                  <span className="text-muted-foreground">Status:</span>{" "}
                  <span className="font-medium text-destructive">Connection failed - check admin credentials and backend logs</span>
                </p>
              ) : (
                <p className="text-sm">
                  <span className="text-muted-foreground">Status:</span>{" "}
                  <span className="font-medium">Testing connection...</span>
                </p>
              )}
            </div>

            <Button 
              onClick={handleTestJira} 
              disabled={jiraTesting} 
              className="gap-2"
            >
              {jiraTesting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Testing...
                </>
              ) : (
                "Test Connection"
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Backend Status */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Server className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle>Backend Status</CardTitle>
                  <CardDescription>RAG Pipeline backend health</CardDescription>
                </div>
              </div>
              <Badge variant={backendHealth?.status === 'ok' ? "success" : backendHealth === null ? "destructive" : "secondary"} className="gap-1">
                {backendHealth?.status === 'ok' ? (
                  <>
                    <CheckCircle2 className="h-3 w-3" />
                    Healthy
                  </>
                ) : backendHealth === null ? (
                  <>
                    <XCircle className="h-3 w-3" />
                    Offline
                  </>
                ) : (
                  "Unknown"
                )}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {backendHealth ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="p-3 rounded-lg bg-muted/30 border">
                  <p className="text-xs text-muted-foreground mb-1">Timestamp</p>
                  <p className="text-sm font-medium">{new Date(backendHealth.timestamp).toLocaleString()}</p>
                </div>
                {backendHealth.version && (
                  <div className="p-3 rounded-lg bg-muted/30 border">
                    <p className="text-xs text-muted-foreground mb-1">Version</p>
                    <p className="text-sm font-medium">{backendHealth.version}</p>
                  </div>
                )}
              </div>
            ) : (
              <Alert variant="destructive">
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  Backend is not responding. Make sure the FastAPI server is running at {ragApiUrl}
                </AlertDescription>
              </Alert>
            )}
            <Button 
              onClick={checkBackendHealth} 
              disabled={healthLoading} 
              variant="outline"
              className="gap-2"
            >
              {healthLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Checking...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" />
                  Refresh Status
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* AI Models - Ollama */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Brain className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>AI Models (Ollama)</CardTitle>
                <CardDescription>Local LLM configuration</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant="default" className="bg-muted/50">
              <Info className="h-4 w-4" />
              <AlertDescription>
                Models are configured in the backend .env file. Check backend /health endpoint for current model.
              </AlertDescription>
            </Alert>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="p-3 rounded-lg bg-muted/30 border">
                <p className="text-xs text-muted-foreground mb-1">LLM Model</p>
                <p className="text-sm font-medium font-mono">{backendHealth?.model || 'Loading...'}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/30 border">
                <p className="text-xs text-muted-foreground mb-1">Embedding Model</p>
                <p className="text-sm font-medium font-mono">From backend .env</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* RAG Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Database className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>RAG Settings</CardTitle>
                <CardDescription>PGVector configuration for semantic search</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rag-url">Backend API URL</Label>
              <Input
                id="rag-url"
                type="text"
                value={ragApiUrl}
                onChange={(e) => setRagApiUrl(e.target.value)}
                placeholder="http://localhost:8000"
              />
              <p className="text-xs text-muted-foreground">FastAPI backend URL</p>
            </div>
            <Separator />
            <Alert variant="default" className="bg-muted/50">
              <Info className="h-4 w-4" />
              <AlertDescription>
                Vector store uses <strong>PGVector</strong> (PostgreSQL) with collection "code_chunks".
                Database connection is configured in backend Config/settings.py
              </AlertDescription>
            </Alert>
            <Separator />
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Top K Snippets</Label>
                <span className="text-sm font-medium text-primary">{topK[0]}</span>
              </div>
              <Slider
                value={topK}
                onValueChange={setTopK}
                min={1}
                max={10}
                step={1}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                Number of relevant code snippets to retrieve for context
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button size="lg" onClick={handleSave}>
            Save All Settings
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default Settings;
