import { useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  AlertTriangle,
  Pause,
  BookOpen,
  Zap,
  Key,
  Wrench,
  Power,
  ShieldAlert,
} from "lucide-react";
import { toast } from "sonner";

interface SystemAction {
  id: string;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  danger: boolean;
}

const systemActions: SystemAction[] = [
  {
    id: "pause_pipelines",
    label: "Pause All Pipelines",
    description: "Immediately stop all running and queued pipeline jobs",
    icon: Pause,
    danger: true,
  },
  {
    id: "readonly_mode",
    label: "Enable Read-Only Mode",
    description: "Prevent any new pipeline runs while allowing viewing",
    icon: BookOpen,
    danger: false,
  },
  {
    id: "disable_ai",
    label: "Disable AI Calls",
    description: "Immediately stop all external AI API calls",
    icon: Zap,
    danger: true,
  },
  {
    id: "rotate_keys",
    label: "Rotate API Keys",
    description: "Generate new API keys and invalidate existing ones",
    icon: Key,
    danger: true,
  },
  {
    id: "maintenance",
    label: "Maintenance Mode",
    description: "Show maintenance page to all users except admins",
    icon: Wrench,
    danger: false,
  },
];

export default function AdminSystem() {
  const [systemState, setSystemState] = useState({
    pipelinesPaused: false,
    readOnlyMode: false,
    aiDisabled: false,
    maintenanceMode: false,
  });
  const [confirmAction, setConfirmAction] = useState<SystemAction | null>(null);

  const handleToggle = (actionId: string, value: boolean) => {
    const action = systemActions.find((a) => a.id === actionId);
    if (action?.danger && value) {
      setConfirmAction(action);
    } else {
      executeAction(actionId, value);
    }
  };

  const executeAction = (actionId: string, value: boolean) => {
    switch (actionId) {
      case "pause_pipelines":
        setSystemState((prev) => ({ ...prev, pipelinesPaused: value }));
        toast.success(value ? "All pipelines paused" : "Pipelines resumed");
        break;
      case "readonly_mode":
        setSystemState((prev) => ({ ...prev, readOnlyMode: value }));
        toast.success(value ? "Read-only mode enabled" : "Read-only mode disabled");
        break;
      case "disable_ai":
        setSystemState((prev) => ({ ...prev, aiDisabled: value }));
        toast.success(value ? "AI calls disabled" : "AI calls enabled");
        break;
      case "maintenance":
        setSystemState((prev) => ({ ...prev, maintenanceMode: value }));
        toast.success(value ? "Maintenance mode enabled" : "Maintenance mode disabled");
        break;
      case "rotate_keys":
        toast.success("API keys rotated successfully");
        break;
    }
    setConfirmAction(null);
  };

  const getStateForAction = (actionId: string): boolean => {
    switch (actionId) {
      case "pause_pipelines":
        return systemState.pipelinesPaused;
      case "readonly_mode":
        return systemState.readOnlyMode;
      case "disable_ai":
        return systemState.aiDisabled;
      case "maintenance":
        return systemState.maintenanceMode;
      default:
        return false;
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">System Controls</h1>
          <p className="text-muted-foreground">Emergency controls and system-wide settings</p>
        </div>

        {/* System Status */}
        <Card className="border-primary/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Power className="h-5 w-5" />
              System Status
            </CardTitle>
            <CardDescription>Current state of critical systems</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div
                className={`p-4 rounded-lg border ${
                  systemState.pipelinesPaused
                    ? "border-destructive/50 bg-destructive/10"
                    : "border-success/50 bg-success/10"
                }`}
              >
                <p className="text-sm font-medium">Pipelines</p>
                <p
                  className={`text-lg font-bold ${
                    systemState.pipelinesPaused ? "text-destructive" : "text-success"
                  }`}
                >
                  {systemState.pipelinesPaused ? "Paused" : "Running"}
                </p>
              </div>
              <div
                className={`p-4 rounded-lg border ${
                  systemState.readOnlyMode
                    ? "border-warning/50 bg-warning/10"
                    : "border-success/50 bg-success/10"
                }`}
              >
                <p className="text-sm font-medium">Mode</p>
                <p
                  className={`text-lg font-bold ${
                    systemState.readOnlyMode ? "text-warning" : "text-success"
                  }`}
                >
                  {systemState.readOnlyMode ? "Read-Only" : "Normal"}
                </p>
              </div>
              <div
                className={`p-4 rounded-lg border ${
                  systemState.aiDisabled
                    ? "border-destructive/50 bg-destructive/10"
                    : "border-success/50 bg-success/10"
                }`}
              >
                <p className="text-sm font-medium">AI Calls</p>
                <p
                  className={`text-lg font-bold ${
                    systemState.aiDisabled ? "text-destructive" : "text-success"
                  }`}
                >
                  {systemState.aiDisabled ? "Disabled" : "Active"}
                </p>
              </div>
              <div
                className={`p-4 rounded-lg border ${
                  systemState.maintenanceMode
                    ? "border-warning/50 bg-warning/10"
                    : "border-success/50 bg-success/10"
                }`}
              >
                <p className="text-sm font-medium">Maintenance</p>
                <p
                  className={`text-lg font-bold ${
                    systemState.maintenanceMode ? "text-warning" : "text-success"
                  }`}
                >
                  {systemState.maintenanceMode ? "Active" : "Off"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-destructive/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <ShieldAlert className="h-5 w-5" />
              Danger Zone
            </CardTitle>
            <CardDescription>
              Critical system controls - use with caution
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {systemActions.map((action) => {
              const Icon = action.icon;
              const isActive = getStateForAction(action.id);
              return (
                <div
                  key={action.id}
                  className={`flex items-center justify-between p-4 rounded-lg border ${
                    action.danger
                      ? "border-destructive/30 bg-destructive/5"
                      : "border-warning/30 bg-warning/5"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon
                      className={`h-5 w-5 ${
                        action.danger ? "text-destructive" : "text-warning"
                      }`}
                    />
                    <div>
                      <Label className="text-base">{action.label}</Label>
                      <p className="text-xs text-muted-foreground">{action.description}</p>
                    </div>
                  </div>
                  {action.id === "rotate_keys" ? (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => setConfirmAction(action)}
                    >
                      Rotate Now
                    </Button>
                  ) : (
                    <Switch
                      checked={isActive}
                      onCheckedChange={(value) => handleToggle(action.id, value)}
                    />
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Emergency Shutdown */}
        <Card className="border-destructive">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-lg bg-destructive/20 flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-destructive" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Emergency Shutdown</h3>
                  <p className="text-sm text-muted-foreground">
                    Immediately stop all systems and enter full lockdown mode
                  </p>
                </div>
              </div>
              <Button
                variant="destructive"
                size="lg"
                onClick={() =>
                  setConfirmAction({
                    id: "emergency_shutdown",
                    label: "Emergency Shutdown",
                    description: "Stop all systems immediately",
                    icon: AlertTriangle,
                    danger: true,
                  })
                }
              >
                Emergency Shutdown
              </Button>
            </div>
          </CardContent>
        </Card>

        <AlertDialog open={!!confirmAction} onOpenChange={() => setConfirmAction(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                Confirm {confirmAction?.label}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {confirmAction?.description}. This action may have significant impact on system
                operations. Are you sure you want to proceed?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={() => {
                  if (confirmAction?.id === "emergency_shutdown") {
                    setSystemState({
                      pipelinesPaused: true,
                      readOnlyMode: true,
                      aiDisabled: true,
                      maintenanceMode: true,
                    });
                    toast.success("Emergency shutdown executed");
                    setConfirmAction(null);
                  } else if (confirmAction) {
                    executeAction(confirmAction.id, true);
                  }
                }}
              >
                Confirm
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}
