import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  FileText,
  Coffee,
  FileCode,
  Trash2,
  AlertTriangle,
  RefreshCw,
  Database,
  Brain,
  GitBranch,
  Clock,
  Users,
  CheckCircle,
  Loader2,
  CalendarDays,
  Timer,
  Network,
  FolderTree,
  Boxes,
  Share2,
  FileBox,
  Workflow
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import { getMemoryStats, setMemoryTTL, cleanupMemory, clearMemory, MemoryStats, getGraphStats, rebuildGraph, GraphStats } from "@/services/ragApi";

const API_URL = import.meta.env.VITE_RAG_API_URL || "http://localhost:8000";

export default function AdminGeneral() {
  const [stats, setStats] = useState({
    total: 0,
    java: 0,
    angular: 0,
    unique_files: 0
  });

  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [clearingLogs, setClearingLogs] = useState(false);
  const [clearingMemory, setClearingMemory] = useState(false);

  const [syncingBackend, setSyncingBackend] = useState(false);
  const [syncingFrontend, setSyncingFrontend] = useState(false);
  const [backendResult, setBackendResult] = useState<any>(null);
  const [frontendResult, setFrontendResult] = useState<any>(null);
  const [backendProgress, setBackendProgress] = useState<any>(null);
  const [frontendProgress, setFrontendProgress] = useState<any>(null);

  // Memory state
  const [memoryStats, setMemoryStats] = useState<MemoryStats | null>(null);
  const [isLoadingMemory, setIsLoadingMemory] = useState(false);
  const [ttlYears, setTtlYears] = useState("");
  const [ttlDays, setTtlDays] = useState("");
  const [deleteBefore, setDeleteBefore] = useState("");
  const [isSavingTTL, setIsSavingTTL] = useState(false);
  const [isCleaningUp, setIsCleaningUp] = useState(false);

  // Knowledge Graph state
  const [graphStats, setGraphStats] = useState<GraphStats | null>(null);
  const [isLoadingGraph, setIsLoadingGraph] = useState(false);
  const [isRebuildingGraph, setIsRebuildingGraph] = useState(false);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/health`);
      if (response.ok) {
        const data = await response.json();
        if (data.index_stats) {
          setStats(data.index_stats);
        }
      } else {
        toast.error("Failed to fetch statistics");
      }
    } catch (error) {
      console.error(error);
      toast.error("Error connecting to server");
    } finally {
      setLoading(false);
    }
  };

  const fetchMemoryStats = async () => {
    setIsLoadingMemory(true);
    try {
      const data = await getMemoryStats();
      setMemoryStats(data);
      if (data.ttl_days) {
        const years = data.ttl_days / 365;
        if (years >= 1 && data.ttl_days % 365 === 0) {
          setTtlYears(String(years));
          setTtlDays("");
        } else {
          setTtlDays(String(data.ttl_days));
          setTtlYears("");
        }
      }
    } catch (error) {
      console.error("Failed to fetch memory stats:", error);
    } finally {
      setIsLoadingMemory(false);
    }
  };

  const handleSetTTL = async () => {
    setIsSavingTTL(true);
    try {
      const payload: any = {};
      if (ttlYears) payload.ttl_years = parseFloat(ttlYears);
      else if (ttlDays) payload.ttl_days = parseInt(ttlDays);
      if (deleteBefore) payload.delete_before = deleteBefore;

      if (!payload.ttl_years && !payload.ttl_days && !payload.delete_before) {
        toast.error("Enter TTL (years or days) or a cutoff date");
        setIsSavingTTL(false);
        return;
      }

      const result = await setMemoryTTL(payload);
      toast.success(result.message || "TTL updated");
      setDeleteBefore("");
      fetchMemoryStats();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to set TTL");
    } finally {
      setIsSavingTTL(false);
    }
  };

  const handleCleanupMemory = async () => {
    setIsCleaningUp(true);
    try {
      const result = await cleanupMemory();
      toast.success(result.message);
      fetchMemoryStats();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Cleanup failed");
    } finally {
      setIsCleaningUp(false);
    }
  };

  const fetchGraphStats = async () => {
    setIsLoadingGraph(true);
    try {
      const data = await getGraphStats();
      setGraphStats(data);
    } catch (error) {
      console.error("Failed to fetch graph stats:", error);
    } finally {
      setIsLoadingGraph(false);
    }
  };

  const handleRebuildGraph = async () => {
    setIsRebuildingGraph(true);
    try {
      const result = await rebuildGraph();
      toast.success(result.message);
      fetchGraphStats();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Graph rebuild failed");
    } finally {
      setIsRebuildingGraph(false);
    }
  };

  useEffect(() => {
    fetchStats();
    fetchMemoryStats();
    fetchGraphStats();
  }, []);

  const handleClearData = async () => {
    setDeleting(true);
    try {
      const response = await fetch(`${API_URL}/admin/clear-db`, {
        method: "DELETE",
      });

      if (response.ok) {
        toast.success("Vector store cleared successfully");
        fetchStats();
      } else {
        const errorText = await response.text();
        toast.error(`Failed to clear data: ${errorText}`);
      }
    } catch (error) {
      console.error(error);
      toast.error("Error clearing data");
    } finally {
      setDeleting(false);
    }
  };

  const handleClearLogs = async () => {
    setClearingLogs(true);
    try {
      const response = await fetch(`${API_URL}/pipeline-logs/clear-all`, {
        method: "DELETE",
      });

      if (response.ok) {
        toast.success("All logs deleted successfully");
      } else {
        const errorText = await response.text();
        toast.error(`Failed to delete logs: ${errorText}`);
      }
    } catch (error) {
      console.error(error);
      toast.error("Error deleting logs");
    } finally {
      setClearingLogs(false);
    }
  };

  const handleClearMemory = async () => {
    setClearingMemory(true);
    try {
      await clearMemory();
      toast.success("Agent memory cleared successfully");
      fetchMemoryStats();
    } catch (error) {
      console.error(error);
      toast.error("Error clearing memory");
    } finally {
      setClearingMemory(false);
    }
  };

  const handleGitlabSync = async (type: "backend" | "frontend") => {
    const setSyncing = type === "backend" ? setSyncingBackend : setSyncingFrontend;
    const setResult = type === "backend" ? setBackendResult : setFrontendResult;
    const setProgress = type === "backend" ? setBackendProgress : setFrontendProgress;
    const label = type === "backend" ? "Backend" : "Frontend";

    setSyncing(true);
    setResult(null);
    setProgress({ phase: "starting", message: "Starting..." });

    try {
      const response = await fetch(`${API_URL}/admin/gitlab-sync/${type}`, {
        method: "POST",
      });

      if (!response.ok) {
        const errorData = await response.json();
        toast.error(`Sync failed: ${errorData.detail || "Unknown error"}`);
        setProgress(null);
        setSyncing(false);
        return;
      }

      const reader = response.body?.getReader();
      if (!reader) {
        toast.error("Streaming not supported");
        setProgress(null);
        setSyncing(false);
        return;
      }

      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const event = JSON.parse(line.slice(6));
            setProgress(event);

            if (event.phase === "synced") {
              setResult((prev: any) => ({ ...prev, ...event }));
            }

            if (event.phase === "graph_build" || event.phase === "graph_update") {
              setProgress(event);
            }

            if (event.phase === "graph_built" || event.phase === "graph_updated") {
              toast.success(`${label} — ${event.message}`);
              fetchGraphStats();
            }

            if (event.phase === "graph_warning") {
              toast.warning(`${label} — ${event.message}`);
            }

            if (event.phase === "done") {
              if (event.chunks > 0) {
                toast.success(`${label} — ${event.message}`);
              } else {
                toast.info(`${label} — ${event.message}`);
              }
              if (event.stats) setStats(event.stats);
              else fetchStats();
              fetchGraphStats();
              setResult((prev: any) => ({ ...prev, ingestion: event }));
            }

            if (event.phase === "error") {
              toast.error(`${label} — ${event.message}`);
            }
          } catch {}
        }
      }
    } catch (error) {
      console.error(error);
      toast.error(`Error syncing ${type} from GitLab`);
    } finally {
      setProgress(null);
      setSyncing(false);
    }
  };

  return (
    <AdminLayout>
      <div className="p-8 space-y-8 max-w-7xl mx-auto">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">General Settings</h2>
          <p className="text-muted-foreground mt-2">
            Manage global application settings, index code, and view system statistics.
          </p>
        </div>

        {/* GitLab Sync Section */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Backend Codebase */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Coffee className="h-5 w-5" />
                Backend Codebase
              </CardTitle>
              <CardDescription>
                Sync the backend Java repository from GitLab.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={() => handleGitlabSync("backend")} disabled={syncingBackend} className="w-full">
                {syncingBackend ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    {backendProgress?.message || "Starting..."}
                  </>
                ) : (
                  <>
                    <GitBranch className="mr-2 h-4 w-4" />
                    GitLab Sync
                  </>
                )}
              </Button>
              {backendProgress?.phase === "embedding" && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Embedding chunks</span>
                    <span>{backendProgress.embedded}/{backendProgress.total_chunks}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full bg-primary transition-all duration-300"
                      style={{ width: `${Math.round((backendProgress.embedded / backendProgress.total_chunks) * 100)}%` }}
                    />
                  </div>
                </div>
              )}
              {backendResult && (
                <div className="space-y-2">
                  {backendResult.ingestion && (
                    <p className="text-xs font-medium text-primary">
                      <Database className="inline h-3 w-3 mr-1" />
                      {backendResult.ingestion.message}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground font-medium">
                    Git: <span className="capitalize">{backendResult.sync_type}</span> &middot; {backendResult.total_files_changed} file(s) changed
                  </p>
                  {backendResult.changed_files?.length > 0 && (
                    <div className="max-h-40 overflow-y-auto rounded-md border bg-muted/50 p-2 space-y-0.5">
                      {backendResult.changed_files.slice(0, 30).map((f: any, i: number) => (
                        <div key={i} className="flex items-center gap-2 text-xs font-mono">
                          <span className={
                            f.status === "added" ? "text-green-600 dark:text-green-400" :
                            f.status === "deleted" ? "text-red-600 dark:text-red-400" :
                            "text-yellow-600 dark:text-yellow-400"
                          }>
                            {f.status === "added" ? "+" : f.status === "deleted" ? "−" : "~"}
                          </span>
                          <span className="truncate">{f.path}</span>
                        </div>
                      ))}
                      {backendResult.changed_files.length > 30 && (
                        <p className="text-xs text-muted-foreground pt-1">...and {backendResult.changed_files.length - 30} more</p>
                      )}
                    </div>
                  )}
                  <p className="text-[11px] text-muted-foreground">
                    <span className="text-green-600 dark:text-green-400">+{backendResult.files_added} added</span>
                    {" · "}
                    <span className="text-yellow-600 dark:text-yellow-400">~{backendResult.files_modified} modified</span>
                    {" · "}
                    <span className="text-red-600 dark:text-red-400">−{backendResult.files_deleted} deleted</span>
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Frontend Codebase */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileCode className="h-5 w-5" />
                Frontend Codebase
              </CardTitle>
              <CardDescription>
                Sync the frontend Angular repository from GitLab.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={() => handleGitlabSync("frontend")} disabled={syncingFrontend} className="w-full">
                {syncingFrontend ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    {frontendProgress?.message || "Starting..."}
                  </>
                ) : (
                  <>
                    <GitBranch className="mr-2 h-4 w-4" />
                    GitLab Sync
                  </>
                )}
              </Button>
              {frontendProgress?.phase === "embedding" && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Embedding chunks</span>
                    <span>{frontendProgress.embedded}/{frontendProgress.total_chunks}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full bg-primary transition-all duration-300"
                      style={{ width: `${Math.round((frontendProgress.embedded / frontendProgress.total_chunks) * 100)}%` }}
                    />
                  </div>
                </div>
              )}
              {frontendResult && (
                <div className="space-y-2">
                  {frontendResult.ingestion && (
                    <p className="text-xs font-medium text-primary">
                      <Database className="inline h-3 w-3 mr-1" />
                      {frontendResult.ingestion.message}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground font-medium">
                    Git: <span className="capitalize">{frontendResult.sync_type}</span> &middot; {frontendResult.total_files_changed} file(s) changed
                  </p>
                  {frontendResult.changed_files?.length > 0 && (
                    <div className="max-h-40 overflow-y-auto rounded-md border bg-muted/50 p-2 space-y-0.5">
                      {frontendResult.changed_files.slice(0, 30).map((f: any, i: number) => (
                        <div key={i} className="flex items-center gap-2 text-xs font-mono">
                          <span className={
                            f.status === "added" ? "text-green-600 dark:text-green-400" :
                            f.status === "deleted" ? "text-red-600 dark:text-red-400" :
                            "text-yellow-600 dark:text-yellow-400"
                          }>
                            {f.status === "added" ? "+" : f.status === "deleted" ? "−" : "~"}
                          </span>
                          <span className="truncate">{f.path}</span>
                        </div>
                      ))}
                      {frontendResult.changed_files.length > 30 && (
                        <p className="text-xs text-muted-foreground pt-1">...and {frontendResult.changed_files.length - 30} more</p>
                      )}
                    </div>
                  )}
                  <p className="text-[11px] text-muted-foreground">
                    <span className="text-green-600 dark:text-green-400">+{frontendResult.files_added} added</span>
                    {" · "}
                    <span className="text-yellow-600 dark:text-yellow-400">~{frontendResult.files_modified} modified</span>
                    {" · "}
                    <span className="text-red-600 dark:text-red-400">−{frontendResult.files_deleted} deleted</span>
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Chunks
              </CardTitle>
              <Database className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">
                 across {stats.unique_files} files
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Java Chunks
              </CardTitle>
              <Coffee className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.java}</div>
              <p className="text-xs text-muted-foreground">
                Backend code chunks
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Angular Chunks
              </CardTitle>
              <FileCode className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.angular}</div>
              <p className="text-xs text-muted-foreground">
                Frontend code chunks
              </p>
            </CardContent>
          </Card>

           <Card className="flex flex-col justify-center items-center bg-secondary/20 border-secondary">
             <CardContent className="pt-6">
                <Button variant="outline" size="sm" onClick={fetchStats} disabled={loading}>
                    <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                    Refresh Stats
                </Button>
             </CardContent>
           </Card>
        </div>

        <Separator />

        {/* Knowledge Graph */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Network className="h-5 w-5" /> Knowledge Graph (Neo4j)
          </h3>
          <p className="text-sm text-muted-foreground">
            Code relationship graph: Feature → Directory → File → Class → Method, plus CALLS, IMPORTS, EXTENDS, IMPLEMENTS.
          </p>

          <div className="grid gap-6 md:grid-cols-2">
            {/* Graph Stats */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">Graph Statistics</CardTitle>
                  <Button variant="outline" size="sm" onClick={fetchGraphStats} disabled={isLoadingGraph}>
                    <RefreshCw className={`h-3 w-3 mr-1 ${isLoadingGraph ? "animate-spin" : ""}`} />
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingGraph ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : graphStats ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/20">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><Boxes className="h-3 w-3 text-blue-600" /> Features</p>
                        <p className="text-lg font-bold text-blue-700 dark:text-blue-400">{graphStats.features}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/20">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><FolderTree className="h-3 w-3 text-amber-600" /> Directories</p>
                        <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{graphStats.directorys}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><FileBox className="h-3 w-3" /> Files</p>
                        <p className="text-lg font-bold">{graphStats.files}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-950/20">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><Boxes className="h-3 w-3 text-purple-600" /> Classes</p>
                        <p className="text-lg font-bold text-purple-700 dark:text-purple-400">{graphStats.classs}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/20">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><Workflow className="h-3 w-3 text-green-600" /> Methods</p>
                        <p className="text-lg font-bold text-green-700 dark:text-green-400">{graphStats.methods}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-cyan-50 dark:bg-cyan-950/20">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><Share2 className="h-3 w-3 text-cyan-600" /> Relations</p>
                        <p className="text-lg font-bold text-cyan-700 dark:text-cyan-400">{graphStats.total_relationships}</p>
                      </div>
                    </div>

                    {graphStats.relationships && Object.keys(graphStats.relationships).length > 0 && (
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-muted-foreground">Relationships</p>
                        <div className="flex flex-wrap gap-2">
                          {Object.entries(graphStats.relationships).map(([rel, count]) => (
                            <Badge key={rel} variant="outline" className="text-[10px] font-mono">
                              {rel}: {count}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {graphStats.interfaces > 0 && (
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Interfaces</span>
                        <span className="font-medium">{graphStats.interfaces}</span>
                      </div>
                    )}
                    {graphStats.apiendpoints > 0 && (
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">API Endpoints</span>
                        <span className="font-medium">{graphStats.apiendpoints}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">No graph data available</p>
                )}
              </CardContent>
            </Card>

            {/* Graph Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Network className="h-4 w-4" />
                  Graph Management
                </CardTitle>
                <CardDescription>
                  The graph is built automatically during GitLab Sync. Use rebuild to regenerate from existing vector store data.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg border bg-muted/30 space-y-2">
                  <p className="text-xs font-medium">How it works</p>
                  <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                    <li><strong>GitLab Sync</strong> — auto-builds graph alongside embeddings</li>
                    <li><strong>Rebuild</strong> — regenerates graph from existing chunks in PGVector</li>
                    <li>Graph captures: <code className="text-[10px] bg-muted px-1 rounded">Feature → Dir → File → Class → Method</code></li>
                    <li>Plus cross-cutting: CALLS, IMPORTS, EXTENDS, IMPLEMENTS</li>
                  </ul>
                </div>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full"
                      disabled={isRebuildingGraph}
                    >
                      {isRebuildingGraph ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Rebuilding Graph...
                        </>
                      ) : (
                        <>
                          <Network className="h-4 w-4 mr-2" />
                          Rebuild Knowledge Graph
                        </>
                      )}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Rebuild Knowledge Graph?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will clear the existing Neo4j graph and rebuild it from all chunks currently in the vector store.
                        This is useful if the graph is empty or out of sync. It may take a few minutes for large codebases.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleRebuildGraph}>
                        Yes, rebuild graph
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardContent>
            </Card>
          </div>
        </div>

        <Separator />

        {/* Agent Memory Management */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Brain className="h-5 w-5" /> Agent Memory
          </h3>
          <p className="text-sm text-muted-foreground">
            PostgreSQL + pgvector semantic memory. Caches approved responses with deduplication and halfvec quantized HNSW index.
          </p>

          <div className="grid gap-6 md:grid-cols-2">
            {/* Memory Stats */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">Memory Statistics</CardTitle>
                  <Button variant="outline" size="sm" onClick={fetchMemoryStats} disabled={isLoadingMemory}>
                    <RefreshCw className={`h-3 w-3 mr-1 ${isLoadingMemory ? "animate-spin" : ""}`} />
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingMemory ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : memoryStats ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Total Records</p>
                        <p className="text-lg font-bold">{memoryStats.total_records}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><Users className="h-3 w-3" /> Users</p>
                        <p className="text-lg font-bold">{memoryStats.unique_users}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/20">
                        <p className="text-xs text-muted-foreground flex items-center gap-1"><CheckCircle className="h-3 w-3 text-green-600" /> Approved</p>
                        <p className="text-lg font-bold text-green-700 dark:text-green-400">{memoryStats.approved}</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground flex items-center gap-1"><Timer className="h-3 w-3" /> TTL</span>
                        <span className="font-medium">
                          {memoryStats.ttl_days >= 365
                            ? `${(memoryStats.ttl_days / 365).toFixed(memoryStats.ttl_days % 365 === 0 ? 0 : 1)} year(s)`
                            : `${memoryStats.ttl_days} days`}
                        </span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground flex items-center gap-1"><Database className="h-3 w-3" /> Vector Table</span>
                        <span className="font-medium">{memoryStats.vector_table_size || "N/A"}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground flex items-center gap-1"><FileText className="h-3 w-3" /> Response Table</span>
                        <span className="font-medium">{memoryStats.response_table_size || "N/A"}</span>
                      </div>
                      {memoryStats.expired_pending_cleanup > 0 && (
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Expired (pending cleanup)</span>
                          <Badge variant="secondary">{memoryStats.expired_pending_cleanup}</Badge>
                        </div>
                      )}
                      {memoryStats.oldest_record && (
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Oldest Record</span>
                          <span>{new Date(memoryStats.oldest_record).toLocaleDateString()}</span>
                        </div>
                      )}
                      {memoryStats.newest_record && (
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Newest Record</span>
                          <span>{new Date(memoryStats.newest_record).toLocaleDateString()}</span>
                        </div>
                      )}
                    </div>

                    {memoryStats.per_user.length > 0 && (
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-muted-foreground">Top Users</p>
                        <div className="space-y-1">
                          {memoryStats.per_user.slice(0, 5).map((u, i) => (
                            <div key={i} className="flex justify-between text-xs">
                              <span className="truncate max-w-[180px]">{u.user_id}</span>
                              <Badge variant="outline" className="text-[10px]">{u.count}</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">No memory data available</p>
                )}
              </CardContent>
            </Card>

            {/* TTL Management */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Memory TTL Settings
                </CardTitle>
                <CardDescription>
                  Set how long memory records are kept. Expired records are cleaned up on demand.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label htmlFor="ttl-years" className="text-xs">TTL (Years)</Label>
                    <Input
                      id="ttl-years"
                      type="number"
                      min="0.5"
                      step="0.5"
                      placeholder="e.g. 3"
                      value={ttlYears}
                      onChange={(e) => { setTtlYears(e.target.value); setTtlDays(""); }}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="ttl-days" className="text-xs">TTL (Days)</Label>
                    <Input
                      id="ttl-days"
                      type="number"
                      min="1"
                      placeholder="e.g. 365"
                      value={ttlDays}
                      onChange={(e) => { setTtlDays(e.target.value); setTtlYears(""); }}
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <Label htmlFor="delete-before" className="text-xs flex items-center gap-1">
                    <CalendarDays className="h-3 w-3" />
                    Delete records before date
                  </Label>
                  <Input
                    id="delete-before"
                    type="date"
                    value={deleteBefore}
                    onChange={(e) => setDeleteBefore(e.target.value)}
                  />
                  <p className="text-[10px] text-muted-foreground">
                    All memory records created before this date will be permanently deleted
                  </p>
                </div>

                <Button onClick={handleSetTTL} disabled={isSavingTTL} className="w-full">
                  {isSavingTTL ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Clock className="h-4 w-4 mr-2" />
                      Save TTL Settings
                    </>
                  )}
                </Button>

                <Separator />

                <Button
                  variant="outline"
                  onClick={handleCleanupMemory}
                  disabled={isCleaningUp}
                  className="w-full"
                >
                  {isCleaningUp ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Cleaning up...
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4 mr-2" />
                      Run Cleanup Now
                      {memoryStats?.expired_pending_cleanup ? (
                        <Badge variant="secondary" className="ml-2">{memoryStats.expired_pending_cleanup} expired</Badge>
                      ) : null}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
            <h3 className="text-lg font-medium text-destructive flex items-center gap-2">
                 <AlertTriangle className="h-5 w-5" /> Danger Zone
            </h3>

            <Card className="border-destructive/50 bg-destructive/5">
                <CardHeader>
                    <CardTitle className="text-destructive">Reset Vector Store</CardTitle>
                    <CardDescription>
                        Permanently remove all embeddings and tsvector data from the Postgres database.
                        This action cannot be undone. You will need to re-index your codebase.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="destructive">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Remove All Data
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure to delete all data from RAG?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This action will permanently delete all indexed code chunks, embeddings,
                                    and search vectors from the database. The RAG system will stop working until you re-index your code.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={handleClearData} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                    {deleting ? "Deleting..." : "Yes, delete everything"}
                                </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
                <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/10 dark:border-orange-900">
                    <CardHeader>
                        <CardTitle className="text-orange-700 dark:text-orange-400">Clear Pipeline Logs</CardTitle>
                        <CardDescription>
                            Remove all execution history and logs from the database.
                            This will clear the history shown in the logs view.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button variant="outline" className="border-orange-300 text-orange-700 hover:bg-orange-100 hover:text-orange-800 dark:border-orange-800 dark:text-orange-400 dark:hover:bg-orange-950/50">
                                    <FileText className="mr-2 h-4 w-4" />
                                    Clear Logs
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>Clear all logs?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        This will permanently delete all pipeline execution logs.
                                        You won't be able to review past runs or stats based on them.
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={handleClearLogs} className="bg-orange-600 hover:bg-orange-700 text-white">
                                        {clearingLogs ? "Clearing..." : "Yes, clear logs"}
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </CardContent>
                </Card>

                <Card className="border-purple-200 bg-purple-50 dark:bg-purple-950/10 dark:border-purple-900">
                    <CardHeader>
                        <CardTitle className="text-purple-700 dark:text-purple-400">Clear Agent Memory</CardTitle>
                        <CardDescription>
                            Clear all cached approved responses from agent memory.
                            New queries will run the full RAG pipeline again.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button variant="outline" className="border-purple-300 text-purple-700 hover:bg-purple-100 hover:text-purple-800 dark:border-purple-800 dark:text-purple-400 dark:hover:bg-purple-950/50">
                                    <Brain className="mr-2 h-4 w-4" />
                                    Clear Memory
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>Clear agent memory?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        This will delete all cached approved responses from PostgreSQL.
                                        The system will re-run the full RAG pipeline for every query.
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={handleClearMemory} className="bg-purple-600 hover:bg-purple-700 text-white">
                                        {clearingMemory ? "Clearing..." : "Yes, clear memory"}
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </CardContent>
                </Card>
            </div>
        </div>
      </div>
    </AdminLayout>
  );
}
