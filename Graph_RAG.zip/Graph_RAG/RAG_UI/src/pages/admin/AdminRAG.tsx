import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Database, RefreshCw, CheckCircle, AlertCircle, FileCode, Layers, FolderOpen, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { getHealth, indexFiles, clearVectorStore, getClasses, HealthResponse, ClassListResponse } from "@/services/ragApi";

export default function AdminRAG() {
  // Health/Status state
  const [healthData, setHealthData] = useState<HealthResponse | null>(null);
  const [isLoadingHealth, setIsLoadingHealth] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  
  // Indexing state
  const [indexPath, setIndexPath] = useState("");
  const [isIndexing, setIsIndexing] = useState(false);
  
  // Classes state
  const [classData, setClassData] = useState<ClassListResponse | null>(null);
  const [isLoadingClasses, setIsLoadingClasses] = useState(false);
  
  // Clear state
  const [isClearing, setIsClearing] = useState(false);

  // Fetch health on mount
  useEffect(() => {
    fetchHealth();
    fetchClasses();
  }, []);

  const fetchHealth = async () => {
    setIsLoadingHealth(true);
    setConnectionError(null);
    try {
      const data = await getHealth();
      setHealthData(data);
    } catch (error) {
      console.error("Health check failed:", error);
      setConnectionError(error instanceof Error ? error.message : "Failed to connect to backend");
    } finally {
      setIsLoadingHealth(false);
    }
  };

  const fetchClasses = async () => {
    setIsLoadingClasses(true);
    try {
      const data = await getClasses();
      setClassData(data);
    } catch (error) {
      console.error("Failed to fetch classes:", error);
    } finally {
      setIsLoadingClasses(false);
    }
  };

  const handleIndex = async () => {
    if (!indexPath.trim()) {
      toast.error("Please enter a file or directory path");
      return;
    }

    setIsIndexing(true);
    try {
      const result = await indexFiles(indexPath.trim());
      toast.success(result.message);
      // Refresh health and classes after indexing
      fetchHealth();
      fetchClasses();
      setIndexPath("");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Indexing failed");
    } finally {
      setIsIndexing(false);
    }
  };

  const handleClear = async () => {
    if (!confirm("Are you sure you want to clear all indexed documents? This cannot be undone.")) {
      return;
    }

    setIsClearing(true);
    try {
      const result = await clearVectorStore();
      toast.success(result.message);
      // Refresh health and classes after clearing
      fetchHealth();
      fetchClasses();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to clear vector store");
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">RAG & Knowledge Base</h1>
          <p className="text-muted-foreground">Manage vector store and code indexing</p>
        </div>

        {/* Connection Error Alert */}
        {connectionError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {connectionError}. Make sure the FastAPI backend is running on the configured URL.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Connection Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Backend Status
              </CardTitle>
              <CardDescription>Vector database and system health</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isLoadingHealth ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : healthData ? (
                    <>
                      <CheckCircle className="h-5 w-5 text-success" />
                      <span className="text-success font-medium">Connected</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="h-5 w-5 text-destructive" />
                      <span className="text-destructive font-medium">Disconnected</span>
                    </>
                  )}
                </div>
                <Button variant="outline" size="sm" onClick={fetchHealth} disabled={isLoadingHealth}>
                  <RefreshCw className={`h-4 w-4 mr-1 ${isLoadingHealth ? "animate-spin" : ""}`} />
                  Refresh
                </Button>
              </div>

              {healthData && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">LLM Model</p>
                    <p className="text-sm font-medium">{healthData.model}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Checkpointer</p>
                    <p className="text-sm font-medium">{healthData.checkpointer}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Total Chunks</p>
                    <p className="text-sm font-medium">{healthData.index_stats.total.toLocaleString()}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Active Sessions</p>
                    <p className="text-sm font-medium">{healthData.active_sessions}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Java Chunks</p>
                    <p className="text-sm font-medium">{healthData.index_stats.java}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Angular Chunks</p>
                    <p className="text-sm font-medium">{healthData.index_stats.angular}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50 col-span-2">
                    <p className="text-xs text-muted-foreground">Redis Status</p>
                    <div className="flex items-center gap-2">
                      <Badge variant={healthData.redis.status === "connected" ? "success" : "secondary"}>
                        {healthData.redis.status}
                      </Badge>
                      {healthData.redis.used_memory_human && (
                        <span className="text-xs text-muted-foreground">
                          Memory: {healthData.redis.used_memory_human}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Index Files */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FolderOpen className="h-5 w-5" />
                Index Code Files
              </CardTitle>
              <CardDescription>Add Java/TypeScript files to vector store</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="path">File or Directory Path</Label>
                <Input
                  id="path"
                  placeholder="e.g., C:\Projects\MyApp\src or /path/to/file.java"
                  value={indexPath}
                  onChange={(e) => setIndexPath(e.target.value)}
                  disabled={isIndexing}
                />
                <p className="text-xs text-muted-foreground">
                  Enter the absolute path to a Java/TypeScript file or directory
                </p>
              </div>
              
              <Button
                className="w-full"
                onClick={handleIndex}
                disabled={isIndexing || !indexPath.trim()}
              >
                {isIndexing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Indexing...
                  </>
                ) : (
                  <>
                    <FileCode className="h-4 w-4 mr-2" />
                    Index Files
                  </>
                )}
              </Button>

              <div className="pt-4 border-t">
                <Button
                  className="w-full"
                  variant="destructive"
                  onClick={handleClear}
                  disabled={isClearing}
                >
                  {isClearing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Clearing...
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4 mr-2" />
                      Clear All Data
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Indexed Classes */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  Indexed Classes
                </CardTitle>
                <CardDescription>
                  {classData ? `${classData.count} classes indexed` : "Loading..."}
                </CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={fetchClasses} disabled={isLoadingClasses}>
                <RefreshCw className={`h-4 w-4 mr-1 ${isLoadingClasses ? "animate-spin" : ""}`} />
                Refresh
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64">
              {isLoadingClasses ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : classData && classData.classes.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {classData.classes.map((className, index) => (
                    <Badge key={index} variant="outline" className="font-mono text-xs">
                      {className}
                    </Badge>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  No classes indexed yet. Use the Index Files section to add code.
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
