import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { useAdminAuth, UserRole } from "@/contexts/AdminAuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { UserPlus, Trash2, Shield, Eye, Play, CheckCircle, FileText, Settings, User, Link2 } from "lucide-react";
import { toast } from "sonner";

const roleColors: Record<UserRole, string> = {
  admin: "destructive",
  developer: "default",
};

const permissionMatrix = {
  admin: { runPipelines: false, approveOutput: false, viewTraces: true, accessLogs: true, ragConfiguration: true, jiraConfiguration: true },
  developer: { runPipelines: true, approveOutput: true, viewTraces: true, accessLogs: false, ragConfiguration: false, jiraConfiguration: false },
};

export default function AdminUsers() {
  const { users, addUser, removeUser, toggleUserStatus, user: currentUser, loadUsers } = useAdminAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [deleteDialogUser, setDeleteDialogUser] = useState<{ id: string; employeeId: string; name: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [newUser, setNewUser] = useState({ 
    employeeId: "", 
    email: "", 
    password: "",
    name: "", 
    role: "developer" as UserRole 
  });

  // Sort users: admins first, then developers
  const sortedUsers = [...users].sort((a, b) => {
    // Admin comes before developer
    if (a.role === "admin" && b.role === "developer") return -1;
    if (a.role === "developer" && b.role === "admin") return 1;
    // Within same role, sort by created date (newest first)
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  // Group users by role
  const adminUsers = sortedUsers.filter(u => u.role === "admin");
  const developerUsers = sortedUsers.filter(u => u.role === "developer");

  useEffect(() => {
    let mounted = true;
    const fetchUsers = async () => {
      if (!mounted) return;
      setIsLoading(true);
      try {
        await loadUsers();
      } catch (error) {
        console.error("Error loading users:", error);
      } finally {
        if (mounted) setIsLoading(false);
      }
    };
    fetchUsers();
    return () => { mounted = false; };
  }, [loadUsers]);

  const handleAddUser = async () => {
    if (!newUser.employeeId || !newUser.email || !newUser.name || !newUser.password) {
      toast.error("Please fill in all fields");
      return;
    }
    
    if (newUser.password.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    
    const employeeIdRegex = /^[A-Z0-9]{3,10}$/;
    if (!employeeIdRegex.test(newUser.employeeId)) {
      toast.error("Employee ID must be 3-10 alphanumeric characters");
      return;
    }
    
    if (users.some(u => u.employeeId === newUser.employeeId)) {
      toast.error("Employee ID already exists");
      return;
    }

    setIsSubmitting(true);
    const result = await addUser({ ...newUser, enabled: true });
    setIsSubmitting(false);
    
    if (result.success) {
      setNewUser({ employeeId: "", email: "", password: "", name: "", role: "developer" });
      setIsAddDialogOpen(false);
      toast.success("User added successfully");
      await loadUsers();
    } else {
      toast.error(result.error || "Failed to add user");
    }
  };

  const handleToggleEnabled = async (id: string, enabled: boolean) => {
    const result = await toggleUserStatus(id, !enabled);
    if (result.success) {
      toast.success(!enabled ? "User enabled" : "User disabled");
      await loadUsers();
    } else {
      toast.error(result.error || "Failed to update user status");
    }
  };

  const handleRemoveUser = async (userId: string) => {
    if (!deleteDialogUser) return;

    if (userId === currentUser?.id) {
      toast.error("Cannot remove your own account");
      setDeleteDialogUser(null);
      return;
    }

    setIsSubmitting(true);
    const result = await removeUser(userId);
    setIsSubmitting(false);
    setDeleteDialogUser(null);
    
    if (result.success) {
      toast.success("User removed successfully");
      await loadUsers();
    } else {
      toast.error(result.error || "Failed to remove user");
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">User Management</h1>
            <p className="text-muted-foreground">Manage users and their access permissions</p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="h-4 w-4 mr-2" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New User</DialogTitle>
                <DialogDescription>Create a new user account with specified role</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Employee ID</Label>
                  <Input
                    value={newUser.employeeId}
                    onChange={(e) => setNewUser({ ...newUser, employeeId: e.target.value.toUpperCase() })}
                    placeholder="F0210"
                    className="uppercase"
                    disabled={isSubmitting}
                  />
                  <p className="text-xs text-muted-foreground">Employee ID from your organization</p>
                </div>
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={newUser.name}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    placeholder="John Doe"
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    placeholder="john@fci-ccm.com"
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Password</Label>
                  <Input
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    placeholder="Enter password"
                    disabled={isSubmitting}
                  />
                  <p className="text-xs text-muted-foreground">Minimum 6 characters</p>
                </div>
                <div className="space-y-2">
                  <Label>Role</Label>
                  <Select
                    value={newUser.role}
                    onValueChange={(value) => setNewUser({ ...newUser, role: value as UserRole })}
                    disabled={isSubmitting}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Admin</SelectItem>
                      <SelectItem value="developer">Developer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} disabled={isSubmitting}>
                  Cancel
                </Button>
                <Button onClick={handleAddUser} disabled={isSubmitting}>
                  {isSubmitting ? "Adding..." : "Add User"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Active Users</CardTitle>
            <CardDescription>All registered users in the system</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee ID</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <div className="flex items-center justify-center gap-2">
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                        <span>Loading users...</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : users.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No users found. Click "Add User" to create the first user.
                    </TableCell>
                  </TableRow>
                ) : (
                  <>
                    {/* Admin Users Section */}
                    {adminUsers.length > 0 && (
                      <>
                        <TableRow className="bg-muted/50 hover:bg-muted/50">
                          <TableCell colSpan={6} className="font-semibold text-sm py-2">
                            <div className="flex items-center gap-2">
                              <Shield className="h-4 w-4 text-destructive" />
                              Admin Users ({adminUsers.length})
                            </div>
                          </TableCell>
                        </TableRow>
                        {adminUsers.map((user) => (
                          <TableRow key={user.id}>
                            <TableCell>
                              <span className="font-mono text-sm font-medium">{user.employeeId}</span>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                                  <span className="text-xs font-medium">{user.employeeId?.substring(0, 2) || "??"}</span>
                                </div>
                                <div>
                                  <p className="font-medium">{user.name}</p>
                                  <p className="text-xs text-muted-foreground">{user.email}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={roleColors[user.role] as any} className="capitalize">
                                {user.role}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Switch
                                  checked={user.enabled}
                                  onCheckedChange={(checked) => handleToggleEnabled(user.id, checked)}
                                  disabled={user.id === currentUser?.id}
                                />
                                <span className="text-sm">{user.enabled ? "Active" : "Disabled"}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {new Date(user.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setDeleteDialogUser({ id: user.id, employeeId: user.employeeId, name: user.name })}
                                disabled={user.id === currentUser?.id}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </>
                    )}

                    {/* Developer Users Section */}
                    {developerUsers.length > 0 && (
                      <>
                        <TableRow className="bg-muted/50 hover:bg-muted/50">
                          <TableCell colSpan={6} className="font-semibold text-sm py-2">
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4" />
                              Developer Users ({developerUsers.length})
                            </div>
                          </TableCell>
                        </TableRow>
                        {developerUsers.map((user) => (
                          <TableRow key={user.id}>
                            <TableCell>
                              <span className="font-mono text-sm font-medium">{user.employeeId}</span>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                                  <span className="text-xs font-medium">{user.employeeId?.substring(0, 2) || "??"}</span>
                                </div>
                                <div>
                                  <p className="font-medium">{user.name}</p>
                                  <p className="text-xs text-muted-foreground">{user.email}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={roleColors[user.role] as any} className="capitalize">
                                {user.role}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Switch
                                  checked={user.enabled}
                                  onCheckedChange={(checked) => handleToggleEnabled(user.id, checked)}
                                  disabled={user.id === currentUser?.id}
                                />
                                <span className="text-sm">{user.enabled ? "Active" : "Disabled"}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {new Date(user.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setDeleteDialogUser({ id: user.id, employeeId: user.employeeId, name: user.name })}
                                disabled={user.id === currentUser?.id}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </>
                    )}
                  </>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Permission Matrix
            </CardTitle>
            <CardDescription>Role-based access control overview</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Permission</TableHead>
                  <TableHead className="text-center">Admin</TableHead>
                  <TableHead className="text-center">Developer</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="flex items-center gap-2">
                    <Play className="h-4 w-4" /> Run Pipelines
                  </TableCell>
                  {(["admin", "developer"] as UserRole[]).map((role) => (
                    <TableCell key={role} className="text-center">
                      {permissionMatrix[role].runPipelines ? (
                        <CheckCircle className="h-4 w-4 text-success mx-auto" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
                <TableRow>
                  <TableCell className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" /> Approve Output
                  </TableCell>
                  {(["admin", "developer"] as UserRole[]).map((role) => (
                    <TableCell key={role} className="text-center">
                      {permissionMatrix[role].approveOutput ? (
                        <CheckCircle className="h-4 w-4 text-success mx-auto" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
                <TableRow>
                  <TableCell className="flex items-center gap-2">
                    <Eye className="h-4 w-4" /> View Reasoning Traces
                  </TableCell>
                  {(["admin", "developer"] as UserRole[]).map((role) => (
                    <TableCell key={role} className="text-center">
                      {permissionMatrix[role].viewTraces ? (
                        <CheckCircle className="h-4 w-4 text-success mx-auto" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
                <TableRow>
                  <TableCell className="flex items-center gap-2">
                    <FileText className="h-4 w-4" /> Access Logs
                  </TableCell>
                  {(["admin", "developer"] as UserRole[]).map((role) => (
                    <TableCell key={role} className="text-center">
                      {permissionMatrix[role].accessLogs ? (
                        <CheckCircle className="h-4 w-4 text-success mx-auto" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
                <TableRow>
                  <TableCell className="flex items-center gap-2">
                    <Settings className="h-4 w-4" /> RAG Configuration
                  </TableCell>
                  {(["admin", "developer"] as UserRole[]).map((role) => (
                    <TableCell key={role} className="text-center">
                      {permissionMatrix[role].ragConfiguration ? (
                        <CheckCircle className="h-4 w-4 text-success mx-auto" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
                <TableRow>
                  <TableCell className="flex items-center gap-2">
                    <Link2 className="h-4 w-4" /> JIRA Configuration
                  </TableCell>
                  {(["admin", "developer"] as UserRole[]).map((role) => (
                    <TableCell key={role} className="text-center">
                      {permissionMatrix[role].jiraConfiguration ? (
                        <CheckCircle className="h-4 w-4 text-success mx-auto" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!deleteDialogUser} onOpenChange={(open) => !open && setDeleteDialogUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Delete</DialogTitle>
            <DialogDescription>
              Do you want to delete <span className="font-semibold">{deleteDialogUser?.employeeId}</span> - <span className="font-semibold">{deleteDialogUser?.name}</span>?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogUser(null)} disabled={isSubmitting}>
              No
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => deleteDialogUser && handleRemoveUser(deleteDialogUser.id)}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Deleting..." : "Yes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
