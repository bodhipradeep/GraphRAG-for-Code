import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link2, CheckCircle, AlertCircle, Bug, Sparkles, RefreshCw, Pause, Play, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { testJiraConnection, fetchJiraIssues, isJiraConfigured, transformJiraIssue } from "@/services/jiraApi";

const API_URL = import.meta.env.VITE_RAG_API_URL || "http://localhost:8000";

interface JiraTask {
  key: string;
  summary: string;
  type: string;
  status: string;
  priority: string;
  assignee: string;
  description?: string;
  created?: string;
  updated?: string;
}

export default function AdminJira() {
  const [config, setConfig] = useState({
    baseUrl: "",
    projectKeys: "Varta",
    connected: false,
    autoTrigger: true,
    ingestionPaused: false,
  });

  const [jiraCredentials, setJiraCredentials] = useState({
    baseUrl: "",
    email: "",
    apiToken: ""
  });
  const [isSavingConfig, setIsSavingConfig] = useState(false);

  const [isTesting, setIsTesting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [tasks, setTasks] = useState<JiraTask[]>([]);
  const [connectionUser, setConnectionUser] = useState<string | null>(null);

  const mappingRules = [
    { type: "Bug", icon: Bug, pipeline: "Bug Fixing Pipeline", color: "warning" },
    { type: "Story", icon: Sparkles, pipeline: "Feature Generation Pipeline", color: "primary" },
    { type: "Task", icon: Sparkles, pipeline: "Feature Generation Pipeline", color: "primary" },
    { type: "Epic", icon: Sparkles, pipeline: "Feature Generation Pipeline", color: "secondary" },
  ];

  const loadJiraConfig = async () => {
    try {
      const response = await fetch(`${API_URL}/config/jira`);
      if (!response.ok) {
        throw new Error(`Failed to load JIRA config: HTTP ${response.status}`);
      }
      const data = await response.json();
      setJiraCredentials({
        baseUrl: data.base_url || "",
        email: data.email || "",
        apiToken: data.api_token || ""
      });
      if (data.project_keys) {
        setConfig(prev => ({ ...prev, projectKeys: data.project_keys }));
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.error("Failed to load JIRA config:", errorMessage);
      // Silently fail on load - user can still enter credentials
    }
  };

  const saveJiraConfig = async () => {
    setIsSavingConfig(true);
    try {
      const response = await fetch(`${API_URL}/config/jira`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          base_url: jiraCredentials.baseUrl,
          email: jiraCredentials.email,
          api_token: jiraCredentials.apiToken,
          project_keys: config.projectKeys
        })
      });
      
      const responseData = await response.json();
      
      if (!response.ok) {
        throw new Error(responseData.detail || `HTTP ${response.status}: ${response.statusText}`);
      }
      
      toast.success("JIRA configuration saved successfully (including project keys)");
      await handleTestConnection();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.error("Failed to save JIRA config:", errorMessage);
      toast.error(`Failed to save JIRA configuration: ${errorMessage}`);
    } finally {
      setIsSavingConfig(false);
    }
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    try {
      const result = await testJiraConnection();

      if (result.success && result.user) {
        setConnectionUser(result.user.displayName || result.user.emailAddress || 'Connected');
        setConfig(prev => ({ ...prev, connected: true }));
        toast.success(`Connected as ${result.user.displayName || result.user.emailAddress}`);
      } else {
        throw new Error(result.error || 'Invalid response from JIRA');
      }
    } catch (error: unknown) {
      console.error('JIRA connection test failed:', error);
      setConfig(prev => ({ ...prev, connected: false }));
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Connection failed: ${errorMessage}`);
    } finally {
      setIsTesting(false);
    }
  };

  const fetchTasks = async (projectKey?: string) => {
    setIsLoading(true);
    try {
      const key = projectKey || config.projectKeys.split(',')[0]?.trim();
      const result = await fetchJiraIssues(key);

      const transformedTasks: JiraTask[] = result.issues.map((issue) => ({
        key: issue.key,
        summary: issue.fields?.summary || 'No summary',
        type: issue.fields?.issuetype?.name || 'Task',
        status: issue.fields?.status?.name || 'Unknown',
        priority: issue.fields?.priority?.name || 'Medium',
        assignee: issue.fields?.assignee?.displayName || 'Unassigned',
        description: typeof issue.fields?.description === 'string' ? issue.fields.description : '',
        created: issue.fields?.created,
        updated: issue.fields?.updated,
      }));

      setTasks(transformedTasks);
      toast.success(`Loaded ${transformedTasks.length} tasks from JIRA`);
    } catch (error: unknown) {
      console.error('Failed to fetch JIRA tasks:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to fetch tasks: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleIngestion = () => {
    setConfig((prev) => ({ ...prev, ingestionPaused: !prev.ingestionPaused }));
    toast.success(config.ingestionPaused ? "Ingestion resumed" : "Ingestion paused");
  };

  useEffect(() => {
    loadJiraConfig().then(() => {
      handleTestConnection();
    });
  }, []);

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, string> = {
      'To Do': 'secondary',
      'In Progress': 'default',
      'Done': 'outline',
      'Closed': 'outline',
    };
    return statusMap[status] || 'secondary';
  };

  const getPriorityColor = (priority: string) => {
    const priorityMap: Record<string, string> = {
      'Critical': 'text-destructive',
      'Highest': 'text-destructive',
      'High': 'text-warning',
      'Medium': 'text-foreground',
      'Low': 'text-muted-foreground',
      'Lowest': 'text-muted-foreground',
    };
    return priorityMap[priority] || 'text-foreground';
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">JIRA Integration</h1>
          <p className="text-muted-foreground">Manage JIRA connection and view tasks</p>
        </div>

        <Tabs defaultValue="configuration" className="space-y-6">
          <TabsList>
            <TabsTrigger value="configuration">Configuration</TabsTrigger>
            <TabsTrigger value="connection">Connection</TabsTrigger>
            <TabsTrigger value="tasks">Task Panel</TabsTrigger>
            <TabsTrigger value="mapping">Task Mapping</TabsTrigger>
          </TabsList>

          <TabsContent value="configuration" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Link2 className="h-5 w-5" />
                  JIRA Configuration
                </CardTitle>
                <CardDescription>
                  Configure JIRA credentials and connection settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="baseUrl">JIRA Base URL</Label>
                  <Input
                    id="baseUrl"
                    value={jiraCredentials.baseUrl}
                    onChange={(e) => setJiraCredentials({ ...jiraCredentials, baseUrl: e.target.value })}
                    placeholder="https://your-domain.atlassian.net"
                  />
                  <p className="text-xs text-muted-foreground">Your JIRA instance URL</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">JIRA Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={jiraCredentials.email}
                    onChange={(e) => setJiraCredentials({ ...jiraCredentials, email: e.target.value })}
                    placeholder="your-email@company.com"
                  />
                  <p className="text-xs text-muted-foreground">Email associated with JIRA account</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="apiToken">API Token</Label>
                  <Input
                    id="apiToken"
                    type="password"
                    value={jiraCredentials.apiToken}
                    onChange={(e) => setJiraCredentials({ ...jiraCredentials, apiToken: e.target.value })}
                    placeholder="Your JIRA API token"
                  />
                  <p className="text-xs text-muted-foreground">
                    Generate from{" "}
                    <a 
                      href="https://id.atlassian.com/manage-profile/security/api-tokens" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      Atlassian Account Settings
                    </a>
                  </p>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    onClick={saveJiraConfig}
                    disabled={isSavingConfig || !jiraCredentials.baseUrl || !jiraCredentials.email || !jiraCredentials.apiToken}
                  >
                    {isSavingConfig ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Configuration"
                    )}
                  </Button>
                  <Button variant="outline" onClick={handleTestConnection} disabled={isTesting}>
                    <RefreshCw className={`h-4 w-4 mr-2 ${isTesting ? "animate-spin" : ""}`} />
                    Test Connection
                  </Button>
                </div>

                <div className={`p-4 rounded-lg mt-4 ${config.connected ? 'bg-success/10 border border-success/30' : 'bg-muted border border-border'}`}>
                  <div className="flex items-center gap-2 mb-2">
                    {config.connected ? (
                      <>
                        <CheckCircle className="h-5 w-5 text-success" />
                        <span className="text-success font-medium">Connected</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-5 w-5 text-muted-foreground" />
                        <span className="text-muted-foreground font-medium">Not Connected</span>
                      </>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {config.connected 
                      ? `Connected as ${connectionUser || 'User'}` 
                      : 'Save configuration and test connection to verify credentials'
                    }
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="connection" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Connection Panel */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Link2 className="h-5 w-5" />
                    Connection Settings
                  </CardTitle>
                  <CardDescription>JIRA instance connection status</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 mb-4">
                    {config.connected ? (
                      <>
                        <CheckCircle className="h-5 w-5 text-success" />
                        <span className="text-success font-medium">Connected</span>
                        {connectionUser && (
                          <span className="text-muted-foreground text-sm">as {connectionUser}</span>
                        )}
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-5 w-5 text-destructive" />
                        <span className="text-destructive font-medium">Disconnected</span>
                      </>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Project Keys</Label>
                    <Input
                      value={config.projectKeys}
                      onChange={(e) => setConfig({ ...config, projectKeys: e.target.value })}
                      placeholder="Varta, PROJECT2"
                    />
                    <p className="text-xs text-muted-foreground">Comma-separated project keys to sync</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Authentication Status</Label>
                    <div className={`p-3 rounded-lg ${config.connected ? 'bg-success/10 border border-success/30' : 'bg-destructive/10 border border-destructive/30'}`}>
                      <p className={`text-sm ${config.connected ? 'text-success' : 'text-destructive'}`}>
                        {config.connected ? 'API Token Connected' : 'Not Connected'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {config.connected ? 'Using configured API token' : 'Check JIRA secrets configuration'}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      className="flex-1"
                      onClick={saveJiraConfig}
                      disabled={isSavingConfig || !jiraCredentials.baseUrl || !jiraCredentials.email || !jiraCredentials.apiToken}
                    >
                      {isSavingConfig ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        "Save Changes"
                      )}
                    </Button>
                    <Button
                      className="flex-1"
                      variant="outline"
                      onClick={handleTestConnection}
                      disabled={isTesting}
                    >
                      <RefreshCw className={`h-4 w-4 mr-2 ${isTesting ? "animate-spin" : ""}`} />
                      {isTesting ? "Testing..." : "Test Connection"}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Controls Panel */}
              <Card>
                <CardHeader>
                  <CardTitle>Integration Controls</CardTitle>
                  <CardDescription>Manage task ingestion and triggers</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                    <div>
                      <Label>Auto-Trigger Pipelines</Label>
                      <p className="text-xs text-muted-foreground">
                        Automatically start pipelines when tasks are assigned
                      </p>
                    </div>
                    <Switch
                      checked={config.autoTrigger}
                      onCheckedChange={(checked) => setConfig({ ...config, autoTrigger: checked })}
                    />
                  </div>

                  <div
                    className={`flex items-center justify-between p-4 rounded-lg border ${
                      config.ingestionPaused ? "border-warning/50 bg-warning/5" : "border-border"
                    }`}
                  >
                    <div>
                      <Label>Ingestion Status</Label>
                      <p className="text-xs text-muted-foreground">
                        {config.ingestionPaused ? "Paused - no new tasks being processed" : "Active - processing new tasks"}
                      </p>
                    </div>
                    <Button
                      variant={config.ingestionPaused ? "default" : "outline"}
                      size="sm"
                      onClick={handleToggleIngestion}
                    >
                      {config.ingestionPaused ? (
                        <>
                          <Play className="h-4 w-4 mr-2" /> Resume
                        </>
                      ) : (
                        <>
                          <Pause className="h-4 w-4 mr-2" /> Pause
                        </>
                      )}
                    </Button>
                  </div>

                  <div className="p-4 rounded-lg bg-muted/50 border border-border">
                    <p className="text-sm font-medium mb-2">Statistics</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-2xl font-bold">{tasks.length}</p>
                        <p className="text-xs text-muted-foreground">Tasks Loaded</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold">
                          {tasks.filter(t => t.status === 'To Do' || t.status === 'Open').length}
                        </p>
                        <p className="text-xs text-muted-foreground">Pending Tasks</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tasks" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>JIRA Task Panel</CardTitle>
                  <CardDescription>Tasks from connected JIRA projects</CardDescription>
                </div>
                <Button 
                  onClick={() => fetchTasks()} 
                  disabled={isLoading || !config.connected}
                  variant="outline"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4 mr-2" />
                  )}
                  {isLoading ? 'Loading...' : 'Fetch Tasks'}
                </Button>
              </CardHeader>
              <CardContent>
                {!config.connected ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>JIRA is not connected. Please check connection settings.</p>
                  </div>
                ) : tasks.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No tasks loaded. Click "Fetch Tasks" to load from JIRA.</p>
                  </div>
                ) : (
                  <ScrollArea className="h-[500px]">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[100px]">Key</TableHead>
                          <TableHead>Summary</TableHead>
                          <TableHead className="w-[100px]">Type</TableHead>
                          <TableHead className="w-[120px]">Status</TableHead>
                          <TableHead className="w-[100px]">Priority</TableHead>
                          <TableHead className="w-[150px]">Assignee</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {tasks.map((task) => (
                          <TableRow key={task.key}>
                            <TableCell className="font-mono text-sm">
                              <a 
                                href={`https://fci-team.atlassian.net/browse/${task.key}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-primary hover:underline flex items-center gap-1"
                              >
                                {task.key}
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            </TableCell>
                            <TableCell className="max-w-[300px] truncate">{task.summary}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {task.type}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={getStatusBadge(task.status) as any}>
                                {task.status}
                              </Badge>
                            </TableCell>
                            <TableCell className={getPriorityColor(task.priority)}>
                              {task.priority}
                            </TableCell>
                            <TableCell className="text-sm">{task.assignee}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mapping">
            <Card>
              <CardHeader>
                <CardTitle>Task Type Mapping</CardTitle>
                <CardDescription>How different JIRA issue types are routed to pipelines</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {mappingRules.map((rule) => (
                    <div
                      key={rule.type}
                      className="flex items-center justify-between p-4 rounded-lg border border-border"
                    >
                      <div className="flex items-center gap-3">
                        <rule.icon className={`h-5 w-5 text-${rule.color}`} />
                        <div>
                          <p className="font-medium">{rule.type}</p>
                          <p className="text-xs text-muted-foreground">JIRA Issue Type</p>
                        </div>
                      </div>
                      <Badge variant={rule.color as any}>{rule.pipeline}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}
