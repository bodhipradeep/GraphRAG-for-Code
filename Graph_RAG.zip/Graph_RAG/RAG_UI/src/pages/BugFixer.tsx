import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { PipelineProgress } from "@/components/pipeline/PipelineProgress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Bug, Play, CheckCircle2, XCircle, Wrench, Copy, Download, Loader2, Terminal, FileCode, User, Tag, AlertCircle, Upload, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { queryCode, resumeAnalysis, refineQuery, QueryResponse, ResumeResponse } from "@/services/ragApi";
import { fetchJiraIssue, transformJiraIssue } from "@/services/jiraApi";
import { useAuth } from "@/contexts/AuthContext";

// Pipeline steps matching backend workflow
const pipelineSteps = [
  { id: "retrieve", label: "Document Retrieval", description: "Searching codebase" },
  { id: "grade", label: "Grading Documents", description: "Filtering relevant code" },
  { id: "generate", label: "Generating Fix", description: "AI analyzing and generating" },
  { id: "verify", label: "Verification", description: "Checking hallucinations" },
  { id: "review", label: "Developer Review", description: "Awaiting your approval" },
];

interface TaskDetails {
  key: string;
  summary: string;
  description: string | null;
  type: string;
  priority: string;
  status: string;
  assignee: string;
  labels?: string[];
}

const BugFixer = () => {
  const [searchParams] = useSearchParams();
  const jiraKey = searchParams.get("jira");
  const { user } = useAuth();
  
  // Task details (manual input or from URL param)
  const [taskDetails, setTaskDetails] = useState<TaskDetails | null>(null);
  const [isLoadingJira, setIsLoadingJira] = useState(false);
  const [manualQuery, setManualQuery] = useState("");
  const [errorContext, setErrorContext] = useState("");
  const [fileHint, setFileHint] = useState("");
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [logContent, setLogContent] = useState<string>("");
  
  // Pipeline state
  const [currentStep, setCurrentStep] = useState(-1);
  const [isRunning, setIsRunning] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const [pipelineStatus, setPipelineStatus] = useState<"idle" | "running" | "needs_review" | "approved" | "rejected" | "completed" | "error">("idle");

  // Function to extract errors from log content
  const extractErrorsFromLog = (logText: string): string[] => {
    const errors: string[] = [];
    const lines = logText.split('\n');
    let currentError: string[] = [];
    let isInError = false;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      
      // Check if line starts with timestamp and contains ERROR
      const errorMatch = line.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z\s+ERROR/);
      
      if (errorMatch) {
        // If we were already collecting an error, save it
        if (isInError && currentError.length > 0) {
          errors.push(currentError.join('\n').trim());
        }
        
        // Start new error collection
        currentError = [line];
        isInError = true;
      } else if (isInError) {
        // Continue collecting lines that are part of the error (stack trace, etc.)
        // Stop if we hit another log line with timestamp
        const nextLogLine = line.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z\s+(INFO|WARN|DEBUG|TRACE|ERROR)/);
        
        if (nextLogLine) {
          // Hit next log entry, save current error and reset
          errors.push(currentError.join('\n').trim());
          currentError = [];
          isInError = false;
          
          // Check if this new line is also an error
          if (nextLogLine[1] === 'ERROR') {
            currentError = [line];
            isInError = true;
          }
        } else if (line.trim()) {
          // Add line to current error (stack trace or continuation)
          currentError.push(line);
        }
      }
    }
    
    // Don't forget the last error if we were collecting one
    if (isInError && currentError.length > 0) {
      errors.push(currentError.join('\n').trim());
    }
    
    return errors;
  };
  
  // RAG API state - Use employee ID as thread_id
  const [threadId, setThreadId] = useState<string | null>(user?.employeeId || null);
  const [generatedAnswer, setGeneratedAnswer] = useState<string>("");
  const [queryTransforms, setQueryTransforms] = useState(0);
  const [workflowLogs, setWorkflowLogs] = useState<string[]>([]);
  
  // UI state
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [reviewedCode, setReviewedCode] = useState<string | null>(null);
  const [showRejectSection, setShowRejectSection] = useState(false);
  const [rejectFeedback, setRejectFeedback] = useState("");

  // If jiraKey is provided, fetch full JIRA details
  useEffect(() => {
    if (jiraKey) {
      const fetchDetails = async () => {
        setIsLoadingJira(true);
        try {
          const issue = await fetchJiraIssue(jiraKey);
          if (issue) {
            const transformed = transformJiraIssue(issue);
            setTaskDetails({
              key: transformed.key,
              summary: transformed.summary,
              description: transformed.description || null,
              type: transformed.type,
              priority: transformed.priority,
              status: transformed.status,
              assignee: transformed.assignee,
              labels: issue.fields.labels || [],
            });
            // Build a comprehensive query from JIRA details
            const queryParts: string[] = [];
            queryParts.push(`Bug ${jiraKey}: ${transformed.summary}`);
            if (transformed.description) {
              queryParts.push(`\n\nDescription:\n${transformed.description}`);
            }
            setManualQuery(queryParts.join(""));
          } else {
            // Fallback if fetch fails
            setTaskDetails({
              key: jiraKey,
              summary: `Bug from JIRA: ${jiraKey}`,
              description: null,
              type: "Bug",
              priority: "Medium",
              status: "To Do",
              assignee: "Unassigned",
            });
            setManualQuery(`Analyze and fix bug ${jiraKey}`);
          }
        } catch (error) {
          console.error("Failed to fetch JIRA issue:", error);
          setTaskDetails({
            key: jiraKey,
            summary: `Bug from JIRA: ${jiraKey}`,
            description: null,
            type: "Bug",
            priority: "Medium",
            status: "To Do",
            assignee: "Unassigned",
          });
          setManualQuery(`Analyze and fix bug ${jiraKey}`);
        } finally {
          setIsLoadingJira(false);
        }
      };
      fetchDetails();
    }
  }, [jiraKey]);

  // Refine the query using LLM
  const handleRefineQuery = async () => {
    const query = manualQuery.trim();
    if (!query) {
      toast({
        title: "Query required",
        description: "Please enter a bug description to refine",
        variant: "destructive",
      });
      return;
    }

    setIsRefining(true);

    try {
      const response = await refineQuery({ 
        query,
        error_message: errorContext || undefined,
        log_content: logContent || undefined
      });
      
      setManualQuery(response.refined_query);
      
      // Auto-fill error message if extracted from logs
      if (response.extracted_error && !errorContext) {
        setErrorContext(response.extracted_error);
        toast({
          title: "Query Refined",
          description: `Query optimized and error extracted from logs`,
        });
      } else {
        toast({
          title: "Query Refined",
          description: `Optimized query from ${response.original_query.length} to ${response.refined_query.length} characters`,
        });
      }

    } catch (error) {
      console.error("Query refinement error:", error);
      toast({
        title: "Refinement Failed",
        description: error instanceof Error ? error.message : "Failed to refine query",
        variant: "destructive",
      });
    } finally {
      setIsRefining(false);
    }
  };

  // Start the RAG pipeline
  const handleStartPipeline = async () => {
    const query = manualQuery.trim();
    if (!query) {
      toast({
        title: "Query required",
        description: "Please enter a bug description or query",
        variant: "destructive",
      });
      return;
    }
if (!user?.employeeId) {
      toast({
        title: "Authentication required",
        description: "Please login to use the system",
        variant: "destructive",
      });
      return;
    }

    setCurrentStep(0);
    setIsRunning(true);
    setPipelineStatus("running");
    setGeneratedAnswer("");
    setWorkflowLogs([]);
    setShowRejectSection(false);
    setRejectFeedback("");

    // Use employee ID as thread_id for session persistence
    const sessionThreadId = user.employeeId;
    setThreadId(sessionThreadId);

    try {
      // Step 1: Retrieval
      setCurrentStep(0);
      setWorkflowLogs(prev => [...prev, `📚 Querying: ${query}`]);
      setWorkflowLogs(prev => [...prev, `👤 Session: ${sessionThreadId}`]);
      
      const response: QueryResponse = await queryCode({
        query: query,
        user_id: user.employeeId,
        jira_key: taskDetails?.key,
        error_message: errorContext || undefined,
        log_content: logContent || undefined,
        file_hint: fileHint || undefined,
      });

      console.log('Query response:', response);
      console.log('Response status:', response.status);
      console.log('Response answer length:', response.answer?.length || 0);

      setThreadId(response.thread_id);
      setQueryTransforms(response.query_transforms);
      
      // Add logs from response
      if (response.logs) {
        setWorkflowLogs(prev => [...prev, ...response.logs!]);
      }

      // Handle cache hit immediately — no need to step through pipeline
      if (response.status === "cache_hit") {
        setCurrentStep(4);
        setPipelineStatus("completed");
        setGeneratedAnswer(response.answer || "Analysis complete");
        setWorkflowLogs(prev => [...prev, "⚡ Result served from memory cache"]);
        return;
      }

      // Progress through steps based on response
      setCurrentStep(1); // Grading
      await new Promise(r => setTimeout(r, 500));
      setCurrentStep(2); // Generating
      await new Promise(r => setTimeout(r, 500));
      setCurrentStep(3); // Verification
      await new Promise(r => setTimeout(r, 500));

      if (response.status === "needs_review") {
        setCurrentStep(4); // Human Review
        setPipelineStatus("needs_review");
        setGeneratedAnswer(response.answer || "No answer generated");
      } else if (response.status === "completed") {
        setCurrentStep(4);
        setPipelineStatus("completed");
        setGeneratedAnswer(response.answer || "Analysis complete");
        setWorkflowLogs(prev => [...prev, "✅ Workflow completed (no HITL needed)"]);
      }

    } catch (error) {
      console.error("Pipeline error:", error);
      setPipelineStatus("error");
      setWorkflowLogs(prev => [...prev, `❌ Error: ${error instanceof Error ? error.message : 'Unknown error'}`]);
      toast({
        title: "Pipeline Error",
        description: error instanceof Error ? error.message : "Failed to run pipeline",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  // Approve the fix
  const handleConfirmApproval = async () => {
    if (!threadId) return;

    setShowApprovalModal(false);
    setIsRunning(true);
    setWorkflowLogs(prev => [...prev, "✅ Approving fix..."]);

    try {
      const response: ResumeResponse = await resumeAnalysis({
        thread_id: threadId,
        human: "approved",
        user_id: user?.employeeId,
        jira_key: taskDetails?.key,
      });

      setPipelineStatus("approved");
      setCurrentStep(5); // Complete all steps including Developer Review
      setGeneratedAnswer(response.answer);
      
      if (response.logs) {
        setWorkflowLogs(prev => [...prev, ...response.logs!]);
      }
      setWorkflowLogs(prev => [...prev, "✅ Fix approved and saved!"]);

      toast({
        title: "Approved successfully!",
        description: "The fix has been approved and saved.",
      });

    } catch (error) {
      console.error("Approval error:", error);
      toast({
        title: "Approval Failed",
        description: error instanceof Error ? error.message : "Failed to approve",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  // Reject and provide feedback
  const handleSubmitFeedback = async () => {
    if (!threadId || !rejectFeedback.trim()) return;

    setShowRejectSection(false);
    setPipelineStatus("rejected");
    setIsRunning(true);
    setCurrentStep(0); // Start from beginning
    setGeneratedAnswer(""); // Clear old result to show loading
    setWorkflowLogs(prev => [...prev, `🔄 Re-analyzing with feedback: ${rejectFeedback}`]);

    try {
      const response: ResumeResponse = await resumeAnalysis({
        thread_id: threadId,
        human: "feedback",
        feedback: rejectFeedback,
        user_id: user?.employeeId,
        jira_key: taskDetails?.key,
      });

      if (response.logs) {
        setWorkflowLogs(prev => [...prev, ...response.logs!]);
      }

      // Progress through steps to show pipeline restarting
      setCurrentStep(1); // Grading
      await new Promise(r => setTimeout(r, 500));
      setCurrentStep(2); // Generating
      await new Promise(r => setTimeout(r, 500));
      setCurrentStep(3); // Verification
      await new Promise(r => setTimeout(r, 500));

      if (response.status === "reanalyzed") {
        setCurrentStep(4); // Developer Review
        setPipelineStatus("needs_review");
        setGeneratedAnswer(response.answer);
        setWorkflowLogs(prev => [...prev, `🔄 Retry attempt ${response.attempt}/3 complete`]);
        
        toast({
          title: "Re-analysis complete",
          description: `Attempt ${response.attempt}/3 - Please review the new fix`,
        });
      } else if (response.status === "max_attempts") {
        setCurrentStep(5); // Complete all steps
        setPipelineStatus("completed");
        setGeneratedAnswer(response.answer);
        setWorkflowLogs(prev => [...prev, "⚠️ Maximum retry attempts reached"]);
        
        toast({
          title: "Max attempts reached",
          description: "The pipeline has reached maximum feedback iterations",
          variant: "destructive",
        });
      }

      setRejectFeedback("");

    } catch (error) {
      console.error("Feedback error:", error);
      setPipelineStatus("error");
      toast({
        title: "Feedback Failed",
        description: error instanceof Error ? error.message : "Failed to submit feedback",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  const handleCopyAnswer = () => {
    navigator.clipboard.writeText(generatedAnswer);
    toast({
      title: "Copied!",
      description: "Answer copied to clipboard",
    });
  };

  const handleDownloadAnswer = () => {
    const blob = new Blob([generatedAnswer], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bug-fix-${threadId || 'analysis'}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({
      title: "Downloaded!",
      description: "Analysis saved as markdown",
    });
  };

  const showDecisionButtons = pipelineStatus === "needs_review" && !showRejectSection && !isRunning;

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* JIRA Task Details Card */}
        {jiraKey && (
          <Card className="border-primary/30 bg-primary/5">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Bug className="h-5 w-5 text-destructive" />
                  <CardTitle>JIRA Task Details</CardTitle>
                </div>
                {/* File upload temporarily disabled */}
                {/* <div className="flex flex-col items-center gap-1">
                  <label htmlFor="txt-upload" className="cursor-pointer">
                    <Upload className="h-5 w-5 text-primary hover:text-primary/80 transition-colors" />
                    <input
                      id="txt-upload"
                      type="file"
                      accept=".txt,.log"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            const content = event.target?.result as string;
                            setLogContent(content);
                            setUploadedFileName(file.name);
                            
                            // Extract errors from log file
                            const extractedErrors = extractErrorsFromLog(content);
                            
                            if (extractedErrors.length > 0) {
                              // Format errors for display
                              let errorSummary = '';
                              if (extractedErrors.length === 1) {
                                // Single error - use the first meaningful line
                                const firstLine = extractedErrors[0].split('\n')[0];
                                errorSummary = firstLine;
                              } else {
                                // Multiple errors - create a summary
                                errorSummary = `Multiple errors found (${extractedErrors.length}):\n` + 
                                  extractedErrors.map((err, idx) => {
                                    const firstLine = err.split('\n')[0];
                                    return `${idx + 1}. ${firstLine}`;
                                  }).join('\n');
                              }
                              
                              setErrorContext(errorSummary);
                              
                              toast({
                                title: "File uploaded & errors extracted",
                                description: `${file.name}: Found ${extractedErrors.length} error(s)`,
                              });
                            } else {
                              toast({
                                title: "File uploaded",
                                description: `${file.name} loaded (no errors detected)`,
                              });
                            }
                          };
                          reader.readAsText(file);
                        }
                      }}
                    />
                  </label>
                  {uploadedFileName ? (
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-muted-foreground">{uploadedFileName}</span>
                      <button
                        onClick={() => {
                          setUploadedFileName(null);
                          setLogContent("");
                          setErrorContext("");
                          const input = document.getElementById("txt-upload") as HTMLInputElement;
                          if (input) input.value = "";
                          toast({
                            title: "File removed",
                            description: "Uploaded file and extracted errors cleared",
                          });
                        }}
                        className="text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ) : (
                    <span className="text-[10px] text-muted-foreground">Logs (.txt, .log)</span>
                  )}
                </div> */}

              </div>
              {taskDetails && (
                <CardDescription className="mt-2">
                  <div className="inline-flex items-center gap-2 rounded-md bg-primary/10 px-3 py-1.5 text-sm">
                    <span className="font-mono font-semibold text-primary">{taskDetails.key}</span>
                    <span className="text-muted-foreground">-</span>
                    <span className="text-foreground">{taskDetails.summary}</span>
                  </div>
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              {isLoadingJira ? (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading JIRA details...
                </div>
              ) : taskDetails ? (
                <div className="space-y-3">
                  {/* Meta Info Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="space-y-0.5">
                      <p className="text-xs text-muted-foreground">Status</p>
                      <Badge variant="secondary" className="text-xs">{taskDetails.status}</Badge>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs text-muted-foreground">Priority</p>
                      <Badge variant={taskDetails.priority === "Critical" || taskDetails.priority === "High" ? "destructive" : "secondary"} className="text-xs">
                        {taskDetails.priority}
                      </Badge>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <User className="h-3 w-3" /> Assignee
                      </p>
                      <p className="text-xs">{taskDetails.assignee}</p>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Tag className="h-3 w-3" /> Labels
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {taskDetails.labels && taskDetails.labels.length > 0 
                          ? taskDetails.labels.join(", ") 
                          : "No labels"}
                      </p>
                    </div>
                  </div>

                  <Separator />

                  {/* Description */}
                  <div className="space-y-1.5">
                    <p className="text-xs font-medium">Description</p>
                    <div className="rounded-lg bg-muted/50 p-3 text-xs leading-snug">
                      {taskDetails.description ? (
                        <pre className="whitespace-pre-wrap font-sans leading-tight">{taskDetails.description}</pre>
                      ) : (
                        <p className="text-muted-foreground italic">No description provided</p>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <AlertCircle className="h-4 w-4" />
                  Failed to load JIRA details
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Query Input Section */}
        <Card>
          <CardContent className="space-y-4 pt-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="error">Error Message (optional)</Label>
                <Input
                  id="error"
                  placeholder="e.g., java.lang.NullPointerException at line 42"
                  value={errorContext}
                  onChange={(e) => setErrorContext(e.target.value)}
                  disabled={isRunning}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="file">File Hint (optional)</Label>
                <Input
                  id="file"
                  placeholder="e.g., UserService.java"
                  value={fileHint}
                  onChange={(e) => setFileHint(e.target.value)}
                  disabled={isRunning}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="query">Bug Description / Query *</Label>
              <Textarea
                id="query"
                placeholder={jiraKey ? "Loading JIRA details..." : "e.g., NullPointerException in UserService when processing login..."}
                value={manualQuery}
                onChange={(e) => setManualQuery(e.target.value)}
                rows={6}
                disabled={isRunning || isLoadingJira}
              />
            </div>
            <div className="flex gap-3">
              <Button 
                size="lg" 
                variant="glow" 
                onClick={handleRefineQuery}
                className="gap-2 bg-yellow-600 hover:bg-yellow-700 text-white"
                disabled={isRunning || isRefining || isLoadingJira || !manualQuery.trim()}
              >
                {isRefining ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Refining...
                  </>
                ) : (
                  <>
                    <Wrench className="h-5 w-5" />
                    Refine Query
                  </>
                )}
              </Button>
              <Button 
                size="lg" 
                variant="glow" 
                onClick={handleStartPipeline} 
                className="gap-2"
                disabled={isRunning || isRefining || isLoadingJira || !manualQuery.trim()}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5" />
                    Run Query
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-4">
          {/* Pipeline Progress Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Pipeline Progress</CardTitle>
                {queryTransforms > 0 && (
                  <CardDescription>
                    Query transforms: {queryTransforms}
                  </CardDescription>
                )}
              </CardHeader>
              <CardContent>
                <PipelineProgress steps={pipelineSteps} currentStep={currentStep} />
              </CardContent>
            </Card>

            {/* Workflow Logs */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Terminal className="h-4 w-4" />
                  Logs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[250px]">
                  {workflowLogs.length > 0 ? (
                    <div className="space-y-1 font-mono text-xs">
                      {workflowLogs.map((log, i) => (
                        <p key={i} className="text-muted-foreground">{log}</p>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-sm">No logs yet. Start the pipeline to see progress.</p>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Generated Answer Section */}
            <Card>
              <CardHeader>
                <CardTitle>
                  Generated Result
                </CardTitle>
              </CardHeader>
              <CardContent>
                {generatedAnswer ? (
                  <div className="space-y-4">
                    <div className="rounded-lg border border-border overflow-hidden">
                      <div className="flex items-center justify-between border-b border-border bg-muted/50 px-4 py-2">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">Generated Analysis</span>
                          <Badge variant={pipelineStatus === "approved" ? "success" : pipelineStatus === "needs_review" ? "secondary" : "default"}>
                            {pipelineStatus === "needs_review" ? "Needs Review" : 
                             pipelineStatus === "approved" ? "Approved" :
                             pipelineStatus === "completed" ? "Completed" : pipelineStatus}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm" onClick={handleCopyAnswer} className="gap-1.5 h-8">
                            <Copy className="h-4 w-4" />
                            Copy
                          </Button>
                          <Button variant="ghost" size="sm" onClick={handleDownloadAnswer} className="gap-1.5 h-8">
                            <Download className="h-4 w-4" />
                            Download
                          </Button>
                        </div>
                      </div>
                      <ScrollArea className="h-[800px] p-4">
                        <pre className="text-sm whitespace-pre-wrap font-mono">
                          {generatedAnswer}
                        </pre>
                      </ScrollArea>
                    </div>

                    {/* Decision Actions */}
                    {showDecisionButtons && (
                      <div className="flex gap-3 pt-2">
                        <Button variant="success" size="lg" className="gap-2" onClick={() => setShowApprovalModal(true)}>
                          <CheckCircle2 className="h-4 w-4" />
                          Approve Result
                        </Button>
                        <Button variant="destructive" size="lg" className="gap-2" onClick={() => setShowRejectSection(true)}>
                          <XCircle className="h-4 w-4" />
                          Re-Analyzed
                        </Button>
                      </div>
                    )}

                    {/* Inline Rejection Section */}
                    <div
                      className={cn(
                        "overflow-hidden transition-all duration-300 ease-in-out",
                        showRejectSection ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"
                      )}
                    >
                      <div className="rounded-lg border border-border bg-muted/30 p-4 mt-4 space-y-4">
                        <div>
                          <h4 className="font-semibold text-base">Provide Feedback</h4>
                          <p className="text-sm text-muted-foreground">
                            Explain what's wrong or what's missing. The AI will re-analyze with your feedback.
                          </p>
                        </div>
                        <Textarea
                          placeholder="e.g., The fix doesn't handle the edge case when user is null..."
                          value={rejectFeedback}
                          onChange={(e) => setRejectFeedback(e.target.value)}
                          rows={4}
                          className="resize-none"
                        />
                        <div className="flex gap-3">
                          <Button
                            variant="default"
                            onClick={handleSubmitFeedback}
                            disabled={!rejectFeedback.trim() || isRunning}
                          >
                            {isRunning ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                            Submit Feedback
                          </Button>
                          <Button variant="outline" onClick={() => setShowRejectSection(false)}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Status Badges */}
                    {pipelineStatus === "approved" && (
                      <div className="flex items-center gap-2 p-4 rounded-lg bg-success/10 border border-success/30">
                        <CheckCircle2 className="h-5 w-5 text-success" />
                        <span className="font-medium text-success">Fix Approved & Saved</span>
                      </div>
                    )}
                    {pipelineStatus === "error" && (
                      <div className="flex items-center gap-2 p-4 rounded-lg bg-destructive/10 border border-destructive/30">
                        <XCircle className="h-5 w-5 text-destructive" />
                        <span className="font-medium text-destructive">Pipeline Error</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[600px] text-muted-foreground">
                    {isRunning ? (
                      <>
                        <Loader2 className="h-8 w-8 animate-spin mb-2" />
                        <p>Analyzing your bug report...</p>
                      </>
                    ) : (
                      <p>Enter a bug query above and click "Analyze & Fix" to start</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Approval Confirmation Modal */}
      <Dialog open={showApprovalModal} onOpenChange={setShowApprovalModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Approval</DialogTitle>
            <DialogDescription>
              Have you reviewed the analysis and are you sure you want to approve this fix?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowApprovalModal(false)}>
              Cancel
            </Button>
            <Button
              variant="success"
              onClick={handleConfirmApproval}
              disabled={isRunning}
            >
              {isRunning ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Yes, Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default BugFixer;
