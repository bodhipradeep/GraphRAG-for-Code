import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";

export type UserRole = "admin" | "developer";

export interface AdminUser {
  id: string;
  employeeId: string;
  email: string;
  name: string;
  role: UserRole;
  enabled: boolean;
  createdAt: string;
}

interface AdminAuthContextType {
  user: AdminUser | null;
  users: AdminUser[];
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  addUser: (user: Omit<AdminUser, "id" | "createdAt"> & { password: string }) => Promise<{success: boolean; error?: string}>;
  updateUser: (id: string, updates: Partial<AdminUser>) => void;
  removeUser: (id: string) => Promise<{success: boolean; error?: string}>;
  loadUsers: () => Promise<void>;
  toggleUserStatus: (id: string, enabled: boolean) => Promise<{success: boolean; error?: string}>;
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

const API_URL = import.meta.env.VITE_RAG_API_URL || "http://localhost:8000";

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("admin_user");
    if (stored) {
      try {
        const userData = JSON.parse(stored);
        setUser(userData);
        // Load users if admin
        if (userData.role === "admin") {
          loadUsers();
        }
      } catch (e) {
        localStorage.removeItem("admin_user");
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        return { success: false, error: error.detail || "Login failed" };
      }

      const rawUserData = await response.json();
      
      // Map snake_case to camelCase
      const userData: AdminUser = {
        id: rawUserData.id,
        employeeId: rawUserData.employee_id,
        email: rawUserData.email,
        name: rawUserData.name,
        role: rawUserData.role,
        enabled: rawUserData.enabled,
        createdAt: rawUserData.created_at || new Date().toISOString(),
      };
      
      // Only allow admins to login through admin portal
      if (userData.role !== "admin") {
        return { success: false, error: "Access denied. Admin access required." };
      }

      if (!userData.enabled) {
        return { success: false, error: "Account disabled. Contact administrator." };
      }

      setUser(userData);
      localStorage.setItem("admin_user", JSON.stringify(userData));
      
      // Load all users
      await loadUsers();
      
      return { success: true };
    } catch (error) {
      console.error("Login error:", error);
      return { success: false, error: "Connection error. Please try again." };
    }
  };

  const logout = () => {
    setUser(null);
    setUsers([]);
    localStorage.removeItem("admin_user");
  };

  const loadUsers = useCallback(async () => {
    try {
      console.log("Loading users from:", `${API_URL}/auth/users`);
      const response = await fetch(`${API_URL}/auth/users`, {
        headers: {
          "Authorization": "Bearer admin",
        },
      });

      console.log("Response status:", response.status);
      if (response.ok) {
        const usersData = await response.json();
        console.log("Raw users data:", usersData);
        
        // Map snake_case API response to camelCase
        const mappedUsers: AdminUser[] = usersData.map((user: any) => ({
          id: user.id,
          employeeId: user.employee_id,
          email: user.email,
          name: user.name,
          role: user.role,
          enabled: user.enabled,
          createdAt: user.created_at,
        }));
        
        console.log("Mapped users:", mappedUsers);
        setUsers(mappedUsers);
      } else {
        console.error("Failed to load users. Status:", response.status);
      }
    } catch (error) {
      console.error("Load users error:", error);
    }
  }, []);

  const addUser = async (newUser: Omit<AdminUser, "id" | "createdAt"> & { password: string }): Promise<{success: boolean; error?: string}> => {
    try {
      const response = await fetch(`${API_URL}/auth/create-user`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer admin",
        },
        body: JSON.stringify({
          employee_id: newUser.employeeId,
          email: newUser.email,
          password: newUser.password,
          name: newUser.name,
          role: newUser.role,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        return { success: false, error: error.detail || "Failed to create user" };
      }

      const rawUser = await response.json();
      
      // Map snake_case to camelCase
      const createdUser: AdminUser = {
        id: rawUser.id,
        employeeId: rawUser.employee_id,
        email: rawUser.email,
        name: rawUser.name,
        role: rawUser.role,
        enabled: rawUser.enabled,
        createdAt: rawUser.created_at,
      };
      
      setUsers((prev) => [...prev, createdUser]);
      
      return { success: true };
    } catch (error) {
      console.error("Create user error:", error);
      return { success: false, error: "Connection error" };
    }
  };

  const updateUser = (id: string, updates: Partial<AdminUser>) => {
    setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...updates } : u)));
    if (user?.id === id) {
      setUser((prev) => (prev ? { ...prev, ...updates } : null));
      localStorage.setItem("admin_user", JSON.stringify({ ...user, ...updates }));
    }
  };

  const removeUser = async (id: string): Promise<{success: boolean; error?: string}> => {
    try {
      const response = await fetch(`${API_URL}/auth/delete-user/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": "Bearer admin",
        },
      });

      if (!response.ok) {
        const error = await response.json();
        return { success: false, error: error.detail || "Failed to delete user" };
      }

      setUsers((prev) => prev.filter((u) => u.id !== id));
      return { success: true };
    } catch (error) {
      console.error("Delete user error:", error);
      return { success: false, error: "Connection error" };
    }
  };

  const toggleUserStatus = async (id: string, enabled: boolean): Promise<{success: boolean; error?: string}> => {
    try {
      const response = await fetch(`${API_URL}/auth/toggle-user/${id}?enabled=${enabled}`, {
        method: "PUT",
        headers: {
          "Authorization": "Bearer admin",
        },
      });

      if (!response.ok) {
        const error = await response.json();
        return { success: false, error: error.detail || "Failed to update user status" };
      }

      const rawUser = await response.json();
      
      // Map snake_case to camelCase
      const updatedUser: AdminUser = {
        id: rawUser.id,
        employeeId: rawUser.employee_id,
        email: rawUser.email,
        name: rawUser.name,
        role: rawUser.role,
        enabled: rawUser.enabled,
        createdAt: rawUser.created_at,
      };
      
      setUsers((prev) => prev.map((u) => (u.id === id ? updatedUser : u)));
      return { success: true };
    } catch (error) {
      console.error("Toggle user error:", error);
      return { success: false, error: "Connection error" };
    }
  };

  return (
    <AdminAuthContext.Provider
      value={{
        user,
        users,
        isAuthenticated: !!user,
        isAdmin: user?.role === "admin",
        isLoading,
        login,
        logout,
        addUser,
        updateUser,
        removeUser,
        loadUsers,
        toggleUserStatus,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error("useAdminAuth must be used within AdminAuthProvider");
  }
  return context;
}
