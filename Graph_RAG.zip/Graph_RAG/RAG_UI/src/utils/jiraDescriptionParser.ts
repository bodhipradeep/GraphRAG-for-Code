/**
 * Extracts plain text from Atlassian Document Format (ADF)
 * ADF is the format Jira uses for rich text fields like descriptions
 */

interface ADFNode {
  type: string;
  text?: string;
  content?: ADFNode[];
}

interface ADFDocument {
  type: string;
  version: number;
  content: ADFNode[];
}

function extractTextFromNode(node: ADFNode): string {
  if (node.text) {
    return node.text;
  }
  
  if (node.content && Array.isArray(node.content)) {
    return node.content.map(extractTextFromNode).join('');
  }
  
  return '';
}

export function parseJiraDescription(description: unknown): string | null {
  if (!description) {
    return null;
  }
  
  // If it's already a string, return it
  if (typeof description === 'string') {
    return description;
  }
  
  // If it's an ADF object
  if (typeof description === 'object' && description !== null) {
    const adf = description as ADFDocument;
    
    if (adf.type === 'doc' && Array.isArray(adf.content)) {
      const textParts: string[] = [];
      
      for (const node of adf.content) {
        const text = extractTextFromNode(node);
        if (text) {
          textParts.push(text);
        }
      }
      
      return textParts.join('\n\n') || null;
    }
  }
  
  return null;
}
