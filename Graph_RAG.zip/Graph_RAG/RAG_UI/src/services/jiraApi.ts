/**
 * JIRA API Service
 * Uses FastAPI backend as proxy to avoid CORS issues
 */

import { parseJiraDescription } from "@/utils/jiraDescriptionParser";

// Backend API URL
const RAG_API_URL = import.meta.env.VITE_RAG_API_URL || 'http://localhost:8000';

export interface JiraIssue {
  id: string;
  key: string;
  fields: {
    summary: string;
    description: string | null;
    issuetype: {
      name: string;
      iconUrl?: string;
    };
    status: {
      name: string;
      statusCategory?: {
        key: string;
      };
    };
    priority?: {
      name: string;
      iconUrl?: string;
    };
    assignee?: {
      displayName: string;
      avatarUrls?: {
        '48x48'?: string;
      };
    } | null;
    labels?: string[];
    created: string;
    updated: string;
  };
}

export interface JiraProject {
  id: string;
  key: string;
  name: string;
  avatarUrls?: {
    '48x48'?: string;
  };
}

/**
 * Fetch saved Jira project keys from backend config
 */
export async function getJiraProjectKeys(): Promise<string> {
  try {
    const response = await fetch(`${RAG_API_URL}/config/jira`);
    if (!response.ok) return "";
    const data = await response.json();
    return data.project_keys || "";
  } catch {
    return "";
  }
}

/**
 * Check if JIRA is configured (backend handles the credentials)
 */
export function isJiraConfigured(): boolean {
  return true;
}

/**
 * Make a request to JIRA via FastAPI backend proxy
 */
async function jiraProxy(action: string, params: Record<string, string> = {}): Promise<any> {
  const response = await fetch(`${RAG_API_URL}/jira-proxy`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ action, ...params }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ detail: response.statusText }));
    throw new Error(errorData.detail || `JIRA API error: ${response.status}`);
  }

  return response.json();
}

/**
 * Test JIRA connection
 */
export async function testJiraConnection(): Promise<{ success: boolean; user?: { displayName?: string; emailAddress?: string }; error?: string }> {
  try {
    const data = await jiraProxy('test');
    return { 
      success: true, 
      user: { 
        displayName: data.displayName, 
        emailAddress: data.emailAddress 
      } 
    };
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return { success: false, error: errorMessage };
  }
}

/**
 * Fetch JIRA projects
 */
export async function fetchJiraProjects(): Promise<JiraProject[]> {
  try {
    const data = await jiraProxy('getProjects');
    return data || [];
  } catch (error) {
    console.error('Failed to fetch JIRA projects:', error);
    return [];
  }
}

/**
 * Fetch JIRA issues with pagination
 */
export async function fetchJiraIssues(projectKey?: string): Promise<{ issues: JiraIssue[]; total: number }> {
  try {
    const data = await jiraProxy('getIssues', projectKey ? { projectKey } : {});
    return { 
      issues: data.issues || [], 
      total: data.total || 0 
    };
  } catch (error) {
    console.error('Failed to fetch JIRA issues:', error);
    return { issues: [], total: 0 };
  }
}

/**
 * Fetch a single JIRA issue
 */
export async function fetchJiraIssue(issueKey: string): Promise<JiraIssue | null> {
  try {
    const data = await jiraProxy('getIssue', { issueKey });
    return data;
  } catch (error) {
    console.error('Failed to fetch JIRA issue:', error);
    return null;
  }
}

/**
 * Transform JIRA API response to our app's JiraTask format
 */
export function transformJiraIssue(issue: JiraIssue): {
  key: string;
  summary: string;
  type: 'Bug' | 'Task' | 'Story' | 'Epic';
  status: 'To Do' | 'In Progress' | 'Done';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  assignee: string;
  description?: string;
  aiProcessed?: boolean;
} {
  const typeMap: Record<string, 'Bug' | 'Task' | 'Story' | 'Epic'> = {
    'Bug': 'Bug',
    'Task': 'Task',
    'Story': 'Story',
    'Epic': 'Epic',
    'Sub-task': 'Task',
    'Subtask': 'Task',
  };

  const statusMap: Record<string, 'To Do' | 'In Progress' | 'Done'> = {
    'new': 'To Do',
    'undefined': 'To Do',
    'indeterminate': 'In Progress',
    'done': 'Done',
  };

  const priorityMap: Record<string, 'Low' | 'Medium' | 'High' | 'Critical'> = {
    'Lowest': 'Low',
    'Low': 'Low',
    'Medium': 'Medium',
    'High': 'High',
    'Highest': 'Critical',
    'Critical': 'Critical',
    'Blocker': 'Critical',
  };

  const issueTypeName = issue.fields.issuetype?.name || 'Task';
  const statusCategory = issue.fields.status?.statusCategory?.key || 'undefined';
  const priorityName = issue.fields.priority?.name || 'Medium';

  return {
    key: issue.key,
    summary: issue.fields.summary,
    type: typeMap[issueTypeName] || 'Task',
    status: statusMap[statusCategory] || 'To Do',
    priority: priorityMap[priorityName] || 'Medium',
    assignee: issue.fields.assignee?.displayName || 'Unassigned',
    description: parseJiraDescription(issue.fields.description) || undefined,
    aiProcessed: false,
  };
}
