import uuid
from IPython.display import display, Markdown
from langgraph.types import Command

from Vector_Store.store import CodeVectorStore
from Retriever.retriever import CodeRetriever
from Tools.search_tools import create_search_tools
from Graph.workflow import create_workflow
from Memory.agent_memory import AgentMemory
from Knowledge_Graph.graph_store import CodeGraphStore
from File_loader.loader import load_code_files
from Chunker.ast_chunker import chunk_documents
from Config.settings import CONFIG


# ==================== INITIALIZE COMPONENTS ====================

vector_store = CodeVectorStore().load_or_create()
retriever = CodeRetriever(vector_store)
tools = create_search_tools(retriever)
memory = AgentMemory()
graph_store = CodeGraphStore()
graph, checkpointer = create_workflow(vector_store, memory, graph_store)


# ==================== INGESTION FUNCTION ====================

def ingest_code(path: str, index_path: str = None):
    """
    Load, chunk, and add code files to vector store.
    Auto-detects Java and Angular files.
    
    Args:
        path: Path to code directory or file
        index_path: Optional custom index path
        
    Returns:
        CodeVectorStore instance
    """
    print(f"Ingesting code from: {path}")
    
    documents = load_code_files(path)
    if not documents:
        print("No files found")
        return None
    
    chunks = chunk_documents(documents)
    
    store = CodeVectorStore()
    store.load_or_create()
    store.add_documents(chunks, replace_files=True)
    store.save()
    
    print(f"Index stats: {store.get_stats()}")
    return store


# ==================== MAIN ANALYSIS FUNCTION ====================

def run_analysis(query: str, error: str = None, file_hint: str = None):
    thread_id = str(uuid.uuid4())[:8]
    config = {"configurable": {"thread_id": thread_id}}
    
    # Build full query
    full_query = query
    if error:
        full_query += f" | Error: {error}"
    if file_hint:
        full_query += f" | File: {file_hint}"

    print(f"🔍 Query: {query}")
    print(f"📋 Thread: {thread_id}")
    print("-" * 60)

    # Initial state for RAG (memory check is now in-graph)
    initial_state = {
        "original_query": full_query,
        "question": full_query,
        "user_id": "cli_user",
        "documents": [],
        "generation": "",
        "query_transform_count": 0,
        "human": None,
        "feedback": None,
        "feedback_count": 0,
        "feedback_history": [],
        "memory_hit": False,
        "cached_response": None,
        "graph_context": "",
        "guided_file_paths": [],
        "final_report": None
    }
    
    current_input = initial_state
    
    while True:
        print("\nRAG working...")
        
        # Stream through the graph
        for event in graph.stream(current_input, config=config, stream_mode="values"):
            # Show progress
            if "documents" in event and event["documents"]:
                doc_count = len(event["documents"])
                if doc_count > 0:
                    print(f"   📄 {doc_count} documents in state")
            if "generation" in event and event["generation"] and len(event["generation"]) > 50:
                print(f"   ✍️ Generation ready ({len(event['generation'])} chars)")
        
        state = graph.get_state(config)
        
        # Check if done
        if not state.next:
            print("\n✅ Workflow completed.")
            final_report = state.values.get("final_report", "")
            if final_report:
                display(Markdown(final_report))
            break
        
        # HITL checkpoint
        if "developer_review" in state.next:
            final_report = state.values.get("final_report", "")
            transform_count = state.values.get("query_transform_count", 0)
            original_query = state.values.get("original_query", "")
            current_question = state.values.get("question", "")
            
            print("\n" + "=" * 60)
            print("📊 ANALYSIS COMPLETE - REVIEW REQUIRED")
            print("=" * 60)
            
            # Show query info
            print(f"\n🔍 Original Query: {original_query}")
            if current_question != original_query:
                print(f"🔄 Transformed Query: {current_question}")
            print(f"📊 Query Transformations: {transform_count}")
            
            print("\n" + "-" * 60)
            print("📝 GENERATED ANALYSIS:")
            print("-" * 60)
            
            if final_report:
                display(Markdown(final_report))
            else:
                print("⚠️ No report generated")
            
            print("=" * 60)
            
            # Get user approval
            choice = input("\n✅ Approve this analysis? (Y/N): ").strip().upper()
            
            if choice == 'Y':
                # Resume with approved - using Command pattern
                for _ in graph.stream(Command(resume="approved"), config=config, stream_mode="values"):
                    pass
                
                break
            else:
                feedback = input("📝 What's wrong? Provide feedback: ").strip()
                current_count = state.values.get("feedback_count", 0) + 1

                if current_count >= CONFIG["max_feedback_attempts"]:
                    print("\n⚠️ Max feedback attempts reached. Ending.")
                    break

                existing_history = list(state.values.get("feedback_history", []) or [])
                existing_history.append(feedback)

                print(f"\n🔄 Re-analyzing with feedback... (attempt {current_count}/{CONFIG['max_feedback_attempts']})")

                for _ in graph.stream(
                    Command(resume="feedback", update={
                        "feedback": feedback,
                        "feedback_count": current_count,
                        "feedback_history": existing_history
                    }),
                    config=config,
                    stream_mode="values"
                ):
                    pass
                
                # Don't set current_input - let the loop continue checking state
                current_input = None
    
    final_state = graph.get_state(config)
    return final_state.values.get("final_report", "")


# ==================== CLI INTERFACE ====================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "ingest" and len(sys.argv) > 2:
            # Ingest code: python main.py ingest /path/to/code
            ingest_code(sys.argv[2])
        else:
            # Run analysis: python main.py "your query here"
            query = " ".join(sys.argv[1:])
            run_analysis(query)
    else:
        print("Usage:")
        print("  Ingest code:   python main.py ingest /path/to/code")
        print("  Run analysis:  python main.py 'your query here'")
        print()
        print("Example queries:")
        print("  python main.py 'NullPointerException in UserService'")
        print("  python main.py 'bug in AWSEmailServiceImpl sendEmail method'")
