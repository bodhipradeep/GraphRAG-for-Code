from langgraph.types import interrupt

from .state import AgentState
from .graders import (
    retrieval_grader,
    hallucination_grader,
    answer_grader,
    question_rewriter,
    feedback_aware_rewriter,
    parse_binary_score
)
from Prompt_lib.prompts import RAG_PROMPT, NOT_RELEVANT_REPORT
from Utils.model_loader import llm
from Config.settings import CONFIG


def memory_check_node(state: AgentState, memory):
    """Check agent memory for cached approved response before running the pipeline."""
    print("---🧠 MEMORY CHECK---")
    query = state.get("original_query", "")

    cached = memory.get_cached_response(query)
    if cached:
        print(f"   ✅ CACHE HIT (similarity={cached['similarity']:.3f})")
        print(f"   Originally answered for user: {cached['user_id']}")
        print(f"   Original query: {cached['query'][:80]}")
        return {
            "memory_hit": True,
            "cached_response": cached["response"]
        }

    print("   ❌ No cache hit — running full pipeline")
    return {
        "memory_hit": False,
        "cached_response": None
    }


def graph_context_node(state: AgentState, graph_store):
    """Query the Neo4j knowledge graph to understand code relationships.
    Extracts entities from query → traverses graph → builds context for LLM."""
    print("---🔗 GRAPH CONTEXT---")
    from Knowledge_Graph.graph_retriever import extract_entities, build_graph_context, get_guided_file_paths

    question = state.get("question") or state.get("original_query", "")

    # Step 1: Extract entities (class names, methods, errors) from the query
    entities = extract_entities(question)
    print(f"   Entities: classes={entities.get('class_names', [])}, "
          f"methods={entities.get('method_names', [])}, "
          f"errors={entities.get('error_types', [])}")

    # Step 2: Traverse Neo4j graph for context
    graph_context = build_graph_context(graph_store, entities)
    if graph_context:
        print(f"   ✅ Graph context built ({len(graph_context)} chars)")
        lines = graph_context.split("\n")
        for line in lines[:10]:
            if line.strip():
                print(f"      {line.strip()}")
        if len(lines) > 10:
            print(f"      ... ({len(lines) - 10} more lines)")
    else:
        print("   ⚠️ No graph context found for this query")

    # Step 3: Get guided file paths for vector search
    guided_paths = list(get_guided_file_paths(graph_store, entities))
    if guided_paths:
        print(f"   📁 Guided paths ({len(guided_paths)} files):")
        for p in guided_paths[:5]:
            print(f"      {p}")
        if len(guided_paths) > 5:
            print(f"      ... and {len(guided_paths) - 5} more")

    return {
        "graph_context": graph_context,
        "guided_file_paths": guided_paths
    }


def retrieve_node(state: AgentState, vector_store):
    """Retrieve documents from vector store — now graph-guided.
    Combines: guided retrieval (from graph paths) + semantic retrieval (current approach)."""
    print("---📚 GRAPH-GUIDED RETRIEVE---")
    original_query = state.get("original_query", "")
    question = state.get("question") or original_query
    guided_paths = state.get("guided_file_paths", []) or []

    print(f"   🔍 Query: {question[:100]}")

    all_docs = []
    seen_ids = set()
    k = CONFIG["retrieval_top_k"]

    # Strategy 1: Guided retrieval — fetch chunks from graph-identified files
    if guided_paths:
        print(f"   📊 Strategy 1: Guided retrieval from {len(guided_paths)} graph-identified files")
        guided_docs = vector_store.search_by_paths(question, guided_paths, k=k)
        for doc in guided_docs:
            doc_id = f"{doc.metadata.get('relative_path', '')}::{doc.metadata.get('method', '')}"
            if doc_id not in seen_ids:
                seen_ids.add(doc_id)
                all_docs.append(doc)
        print(f"      Found {len(guided_docs)} guided docs")

    # Strategy 2: Semantic retrieval — standard vector similarity search
    print(f"   📊 Strategy 2: Semantic similarity search (k={k})")
    semantic_docs = vector_store.search(question, k=k)
    new_semantic = 0
    for doc in semantic_docs:
        doc_id = f"{doc.metadata.get('relative_path', '')}::{doc.metadata.get('method', '')}"
        if doc_id not in seen_ids:
            seen_ids.add(doc_id)
            all_docs.append(doc)
            new_semantic += 1
    print(f"      Found {len(semantic_docs)} semantic docs ({new_semantic} new after dedup)")

    print(f"   📄 Total unique docs: {len(all_docs)}")
    for i, doc in enumerate(all_docs):
        file_name = doc.metadata.get('file_name', 'unknown')
        class_name = doc.metadata.get('class_name', '')
        method_name = doc.metadata.get('method', '')
        location = f"{file_name}"
        if class_name:
            location += f" > {class_name}"
        if method_name:
            location += f" > {method_name}"
        source = "graph" if i < len(all_docs) - new_semantic else "semantic"
        print(f"      Doc {i+1} [{source}]: {location}")

    return {"documents": all_docs, "question": question}


def grade_documents_node(state: AgentState):
    """Grade retrieved documents for relevance."""
    print("---📋 GRADING DOCS---")
    question = state["question"]
    documents = state["documents"]

    filtered_docs = []
    for i, doc in enumerate(documents):
        file_name = doc.metadata.get('file_name', 'unknown')
        class_name = doc.metadata.get('class_name', '')
        method_name = doc.metadata.get('method_name', '')

        location = f"{file_name}"
        if class_name:
            location += f" > {class_name}"
        if method_name:
            location += f" > {method_name}"

        response = retrieval_grader.invoke({
            "question": question,
            "document": doc.page_content
        })
        grade = parse_binary_score(response)

        if grade == "yes":
            print(f"   ✓ [{location}]: RELEVANT")
            filtered_docs.append(doc)
        else:
            print(f"   ✗ [{location}]: NOT RELEVANT")

    print(f"   → {len(filtered_docs)}/{len(documents)} docs passed grading")
    return {"documents": filtered_docs}


def transform_query_node(state: AgentState):
    """Transform query to better version - handles both auto-improvement and feedback-based improvement."""
    print("---TRANSFORM QUERY---")
    original_query = state.get("original_query", "")
    question = state["question"]
    feedback = state.get("feedback")
    previous_generation = state.get("generation") or state.get("final_report", "")
    current_count = state.get("query_transform_count", 0)

    print(f"Original Query: {original_query}")
    print(f"Previous Query: {question}")

    if feedback and previous_generation:
        print(f"Human Feedback: {feedback}")
        print(f"Using feedback-aware rewriter")
        answer_summary = previous_generation[:500] + "..." if len(previous_generation) > 500 else previous_generation

        better_question = feedback_aware_rewriter.invoke({
            "question": question,
            "previous_answer": answer_summary,
            "feedback": feedback
        })
    else:
        print(f"Using standard query improvement")
        better_question = question_rewriter.invoke({"question": question})

    print(f"New Query: {better_question}")
    print(f"Transform Count: {current_count + 1}/{CONFIG['max_query_transforms']}")

    return {
        "question": better_question,
        "query_transform_count": current_count + 1,
        "feedback": None,
        "generation": "",
        "final_report": None
    }


def generate_node(state: AgentState):
    """Generate answer using GraphRAG — code chunks + graph relationship context."""
    print("---GENERATING (GraphRAG)---")
    original_query = state.get("original_query", "")
    question = state["question"]
    documents = state["documents"]
    graph_context = state.get("graph_context", "")
    generation_attempts = state.get("generation_attempts", 0)

    print(f"Original Query: {original_query}")
    if question != original_query:
        print(f"Current Query: {question}")
    print(f"Generation attempt: {generation_attempts + 1}/{CONFIG['max_iterations']}")
    print(f"Using {len(documents)} documents + graph context ({len(graph_context)} chars)")

    # Build code context from retrieved chunks
    context_parts = []
    for doc in documents:
        rp = doc.metadata.get('relative_path', doc.metadata.get('file_name', 'unknown'))
        method = doc.metadata.get('method', '')
        tag = f"[{rp}" + (f"::{method}" if method else "") + "]"
        context_parts.append(f"{tag}\n{doc.page_content}")
    code_context = "\n---\n".join(context_parts)

    prompt = RAG_PROMPT.format(
        context=code_context,
        graph_context=graph_context if graph_context else "No graph context available for this query.",
        question=question,
        mistakes="None"
    )

    response = llm.invoke([{"role": "user", "content": prompt}])
    generation = response.content

    print(f"Generated response ({len(generation)} chars)")
    return {
        "generation": generation,
        "generation_attempts": generation_attempts + 1
    }


def human_review_node(state: AgentState):
    """HITL checkpoint using interrupt() - pauses workflow for human review."""
    print("---👤 AWAITING REVIEW---")
    final_report = state.get("generation", "")

    options = ("approved", "feedback")
    response = interrupt(options)

    return {
        "final_report": final_report,
        "human": response
    }


def finalize_node(state: AgentState, memory):
    """Save approved response to memory and finalize.
    Includes all rejection feedback from the session as reference."""
    result = state.get("final_report", "")
    user_id = state.get("user_id", "anonymous")

    if not state.get("memory_hit", False):
        feedback_list = state.get("feedback_history", [])
        feedback_text = " | ".join(feedback_list) if feedback_list else None

        memory.add_success(
            user_id=user_id,
            query=state["original_query"],
            result=result if result else "",
            feedback_history=feedback_text
        )
        print("\n✅ Approved & saved to memory!")
        if feedback_text:
            print(f"   📝 Feedback history saved: {len(feedback_list)} rejection(s)")
    else:
        print("\n✅ Served from memory cache!")
    return {}


def end_not_relevant_node(state: AgentState):
    """End when query not relevant after max transforms."""
    print("---❌ NOT RELEVANT - END---")
    return {
        "final_report": NOT_RELEVANT_REPORT.format(
            transform_count=state.get('query_transform_count', 0),
            original_query=state['original_query'],
            final_query=state['question']
        )
    }
