"""
Graders for Adaptive RAG - Document relevance and hallucination checking.
"""

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from Utils.model_loader import llm


def parse_binary_score(response: str) -> str:
    """Parse yes/no from LLM response - LENIENT (defaults to yes)"""
    text = response.lower().strip()
    if "no" in text and "yes" not in text:
        return "no"
    return "yes"


def parse_binary_score_strict(response: str) -> str:
    """Parse yes/no from LLM response - STRICT (defaults to no)"""
    text = response.lower().strip()
    if "yes" in text and "no" not in text:
        return "yes"
    return "no"


doc_grader_prompt = ChatPromptTemplate.from_messages([
    ("system", """Role: Code Relevance Grader for Bug Fixing
Task: Determine if this code document is DIRECTLY relevant to debugging the query.
Accept if:
1. The document contains the CLASS, METHOD, or ERROR mentioned in the query
2. The code is from the same module or directly related class
3. The code contains the specific bug pattern, API endpoint, or operation mentioned
Reject if:
- Only shares common imports or generic utilities
- Completely different module/domain with no connection to the query
Output: ONLY 'yes' or 'no'"""),
    ("human", "Bug Query: {question}\n\nCode Document:\n{document}\n\nRelevant? (yes/no):"),
])
retrieval_grader = doc_grader_prompt | llm | StrOutputParser()

hallucination_prompt = ChatPromptTemplate.from_messages([
    ("system", """Role: Strict Code Fact Checker
Task: Check if the FIXED_CODE section ONLY uses methods, APIs, and services that exist in the provided code.

Step-by-step:
1. Find every method call, API endpoint, and service used in the FIXED_CODE
2. Check if EACH ONE appears in the Code Documents or Available Methods list
3. If ANY method/API/service is used in the fix but NOT found in the documents → answer 'no'

Common fabrications to watch for:
- deleteApi(), removeApi(), deleteJob(), removeJob() — check if these ACTUALLY exist
- Any new HTTP endpoint not seen in the documents
- Any service method not defined in the documents

Output: ONLY 'yes' or 'no'"""),
    ("human", "Code Documents:\n{documents}\n\nAvailable Methods:\n{available_methods}\n\nBug Fix Answer:\n{generation}\n\nDoes the fix ONLY use methods/APIs that exist in the documents? (yes/no):"),
])
hallucination_grader = hallucination_prompt | llm | StrOutputParser()

rewrite_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a code search query optimizer for a Java/Angular codebase.
Your task: rewrite the query to better match code stored in a vector database.

Do:
- Extract class names, method names, service names, API endpoints
- Use technical terms: delete, remove, save, update, validate, persist
- Include the module/component name (e.g. PoolConfiguration, UserService)
- Keep the operation and failure description

Don't:
- Include navigation steps or UI instructions
- Add generic words like "bug", "issue", "problem"
- Repeat the same query with minor wording changes

Return ONLY the improved question."""),
    ("human", "Initial question: {question}\n\nImproved question:"),
])
question_rewriter = rewrite_prompt | llm | StrOutputParser()

feedback_rewrite_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an expert question re-writer. Your job is to analyze human feedback and improve the query.

Analyze:
1. What was the original question asking?
2. What did the previous answer provide?
3. What is the human feedback asking for that was missing?
4. What specific information needs to be retrieved?

Create a NEW, SPECIFIC question that:
- Addresses exactly what the human feedback is asking for
- Uses specific terms that will match relevant code in a vector store
- Focuses on the missing piece (e.g., "complete code", "full implementation", "all methods")

Return ONLY the improved question, nothing else."""),
    ("human", """Original question: {question}

Previous answer summary: {previous_answer}

Human feedback: {feedback}

Improved question (focus on what the human is asking for):"""),
])
feedback_aware_rewriter = feedback_rewrite_prompt | llm | StrOutputParser()

answer_grader_prompt = ChatPromptTemplate.from_messages([
    ("system", """Role: Bug Fix Answer Checker
Task: Check if the answer provides a useful fix or analysis for the bug.
Accept if:
1. Identifies the specific bug location (file, class, method)
2. Provides code fix or clear explanation of the problem
3. References actual code from the codebase
Reject if:
- Only provides generic advice with no specific code references
- Does not address the specific bug/error mentioned in the query
Output: ONLY 'yes' or 'no'"""),
    ("human", "Bug Query:\n{question}\n\nProposed Fix:\n{generation}\n\nValid fix? (yes/no):"),
])
answer_grader = answer_grader_prompt | llm | StrOutputParser()
