from typing import TypedDict, List, Optional, Set
from langchain_core.documents import Document


class AgentState(TypedDict):
    """State for Adaptive Self-Corrective GraphRAG workflow."""

    # Query info
    original_query: str
    question: str  # Current question (may be transformed)
    user_id: str

    # Retrieved documents
    documents: List[Document]

    # Generation
    generation: str

    # Adaptive RAG counters
    query_transform_count: int  # Track query rewrites
    generation_attempts: int  # Track generation attempts

    # HITL state
    human: Optional[str]  # "Approved" or "Reject"
    feedback: Optional[str]  # Current rejection reason
    feedback_count: int
    feedback_history: List[str]  # All rejection feedback collected during session

    # Memory state
    memory_hit: bool
    cached_response: Optional[str]

    # Graph context (NEW — from Neo4j knowledge graph)
    graph_context: str  # Human-readable class/method/call-chain context from Neo4j
    guided_file_paths: List[str]  # File paths to prioritize in vector search

    # Final output
    final_report: Optional[str]
