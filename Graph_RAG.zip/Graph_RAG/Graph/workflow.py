from functools import partial
import sqlite3
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver
from Config.settings import CONFIG

from .state import AgentState
from .nodes import (
    memory_check_node,
    graph_context_node,
    retrieve_node,
    grade_documents_node,
    transform_query_node,
    generate_node,
    human_review_node,
    finalize_node,
    end_not_relevant_node
)
from .routing import (
    after_memory_check,
    decide_to_generate,
    grade_generation_vs_documents_and_question,
    decide_to_generate_after_transformation,
    after_human_review
)


def cache_hit_node(state: AgentState):
    """Set final_report from cached response when memory cache hits."""
    return {
        "final_report": state.get("cached_response", ""),
        "generation": state.get("cached_response", "")
    }


def create_workflow(vector_store, memory, graph_store):
    """Create the Adaptive Self-Corrective GraphRAG workflow.

    Flow:
        START → memory_check → (cache_hit → finalize → END)
                             → graph_context → retrieve → grade → generate →
                               hallucination/answer check → HITL → finalize → END
    """
    memory_check_with_memory = partial(memory_check_node, memory=memory)
    graph_context_with_store = partial(graph_context_node, graph_store=graph_store)
    retrieve_with_store = partial(retrieve_node, vector_store=vector_store)
    finalize_with_memory = partial(finalize_node, memory=memory)

    workflow = StateGraph(AgentState)

    # Nodes
    workflow.add_node("memory_check", memory_check_with_memory)
    workflow.add_node("cache_hit", cache_hit_node)
    workflow.add_node("graph_context", graph_context_with_store)
    workflow.add_node("Docs_Vector_Retrieve", retrieve_with_store)
    workflow.add_node("Grading_Generated_Documents", grade_documents_node)
    workflow.add_node("Content_Generator", generate_node)
    workflow.add_node("Transform_User_Query", transform_query_node)
    workflow.add_node("developer_review", human_review_node)
    workflow.add_node("finalize", finalize_with_memory)
    workflow.add_node("end_not_relevant", end_not_relevant_node)

    # START → memory_check
    workflow.add_edge(START, "memory_check")

    # memory_check → cache hit or graph context
    workflow.add_conditional_edges(
        "memory_check",
        after_memory_check,
        {
            "cache_hit": "cache_hit",
            "cache_miss": "graph_context"
        }
    )

    # cache_hit → finalize (skip entire pipeline)
    workflow.add_edge("cache_hit", "finalize")

    # graph_context → retrieve (graph context feeds into guided retrieval)
    workflow.add_edge("graph_context", "Docs_Vector_Retrieve")

    # Normal RAG pipeline
    workflow.add_edge("Docs_Vector_Retrieve", "Grading_Generated_Documents")

    workflow.add_conditional_edges(
        "Grading_Generated_Documents",
        decide_to_generate,
        {
            "generate": "Content_Generator",
            "transform_query": "Transform_User_Query"
        }
    )

    workflow.add_conditional_edges(
        "Content_Generator",
        grade_generation_vs_documents_and_question,
        {
            "useful": "developer_review",
            "not useful": "Transform_User_Query"
        }
    )

    workflow.add_conditional_edges(
        "Transform_User_Query",
        decide_to_generate_after_transformation,
        {
            "Retriever": "Docs_Vector_Retrieve",
            "query_not_at_all_relevant": "end_not_relevant"
        }
    )

    workflow.add_conditional_edges(
        "developer_review",
        after_human_review,
        {
            "finalize": "finalize",
            "transform_query": "Transform_User_Query"
        }
    )

    workflow.add_edge("finalize", END)
    workflow.add_edge("end_not_relevant", END)

    # SQLite Checkpointer
    conn = sqlite3.connect(CONFIG['checkpoint_db'], check_same_thread=False)
    checkpointer = SqliteSaver(conn)

    graph = workflow.compile(checkpointer=checkpointer)

    return graph, checkpointer
