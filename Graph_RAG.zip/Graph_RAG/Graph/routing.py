from .state import AgentState
from .graders import (
    hallucination_grader,
    answer_grader,
    parse_binary_score,
    parse_binary_score_strict
)
from Config.settings import CONFIG


def after_memory_check(state: AgentState):
    """Route after memory check: cache hit → skip to finalize, miss → retrieve."""
    memory_hit = state.get("memory_hit", False)
    if memory_hit:
        print("   → Memory cache HIT → SKIP pipeline, use cached response")
        return "cache_hit"
    else:
        print("   → Memory cache MISS → Run full RAG pipeline")
        return "cache_miss"


def decide_to_generate(state: AgentState):
    """Decide: generate or transform based on filtered documents."""
    print("---🔀 DECIDE: GEN OR TRANSFORM?---")
    filtered_documents = state["documents"]
    
    if not filtered_documents:
        print("   → No relevant docs → TRANSFORM")
        return "transform_query"
    else:
        print(f"   → {len(filtered_documents)} docs → GENERATE")
        return "generate"


def grade_generation_vs_documents_and_question(state: AgentState):
    """Check generation quality - hallucination and answer relevance."""
    print("---🔍 CHECK GENERATION---")
    question = state["question"]
    documents = state["documents"]
    generation = state["generation"]
    generation_attempts = state.get("generation_attempts", 0)
    max_iterations = CONFIG["max_iterations"]
    
    if generation_attempts >= max_iterations:
        print(f"   ⚠️ Max generation attempts ({max_iterations}) reached → FORCE EXIT")
        return "useful"
    
    docs_text = "\n\n".join([doc.page_content for doc in documents])
    
    # Build available methods list from metadata for hallucination check
    available_methods = []
    for doc in documents:
        meta = doc.metadata
        cls = meta.get('class_name', '')
        method = meta.get('method', '')
        fname = meta.get('file_name', '')
        if cls and method:
            available_methods.append(f"{cls}.{method}")
        elif method:
            available_methods.append(method)
        if fname:
            available_methods.append(fname)
    methods_text = ", ".join(set(available_methods)) if available_methods else "(none extracted)"
    
    print("   Checking hallucinations...")
    hallucination_response = hallucination_grader.invoke({
        "documents": docs_text,
        "available_methods": methods_text,
        "generation": generation
    })
    hallucination_grade = parse_binary_score_strict(hallucination_response)
    
    if hallucination_grade == "yes":
        print("   ✓ GROUNDED")
        
        print("   Checking answer relevance...")
        answer_response = answer_grader.invoke({
            "question": question,
            "generation": generation
        })
        answer_grade = parse_binary_score(answer_response)
        
        if answer_grade == "yes":
            print("   ✓ ADDRESSES question → USEFUL")
            return "useful"
        else:
            print("   ✗ NOT addressing → NOT USEFUL")
            return "not useful"
    else:
        print("   ✗ HALLUCINATION → NOT USEFUL")
        return "not useful"


def decide_to_generate_after_transformation(state: AgentState):
    """After transform: retry retrieval or end if max transforms reached."""
    print("---🔀 DECIDE: RETRY OR END?---")
    transform_count = state.get("query_transform_count", 0)
    max_transforms = CONFIG["max_query_transforms"]
    
    if transform_count >= max_transforms:
        print(f"   → Max transforms ({transform_count}) → END")
        return "query_not_at_all_relevant"
    else:
        print(f"   → Count {transform_count}/{max_transforms} → RETRY")
        return "Retriever"


def after_human_review(state: AgentState):
    """After review: finalize if approved, else transform query."""
    human_value = state.get("human", "")
    
    if human_value == "approved":
        return "finalize"
    else:  # feedback
        return "transform_query"
