# Final_RAG - Production Code Analysis System

## Overview
AI-powered code analysis and bug fixing system for Java and Angular/TypeScript applications, designed for on-premise deployment with 40-50 concurrent users. Features employee ID-based authentication for session isolation and multi-developer support.

## Architecture
- **LLM**: Ollama (gemma3:4b for generation, llama3.1:8b for query refinement)
- **Embeddings**: Ollama (nomic-embed-text:latest)
- **Vector Store**: PGVector (PostgreSQL)
- **Cache**: Redis
- **Checkpointer**: SQLite with persistent connections
- **Framework**: LangGraph with HITL workflow
- **Frontend**: React + TypeScript with Radix UI
- **Authentication**: Employee ID-based session management

## Key Features
✅ **Query Refinement**: Few-shot learning with error extraction from logs  
✅ **Multi-User Support**: Employee ID isolation (F5987, A1234, etc.)  
✅ **Session Persistence**: localStorage + Redis for cross-refresh continuity  
✅ **Human-in-the-Loop**: Approve/reject/feedback workflow  
✅ **JIRA Integration**: Auto-import bug descriptions  
✅ **Audit Trail**: Track which developer analyzed which bugs  

## Prerequisites
- Python 3.11+
- PostgreSQL 13+ with pgvector extension
- Redis 6+
- Node.js 18+ (for React UI)
- Ollama with models:
  - gemma3:4b (code generation)
  - llama3.1:8b (query refinement)
  - nomic-embed-text:latest (embeddings)

## Installation

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Setup PostgreSQL with PGVector
```sql
CREATE DATABASE vectordb;
\c vectordb
CREATE EXTENSION vector;
CREATE USER postgres WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE vectordb TO postgres;
```

**Note:** LangChain will automatically create 2 tables:
- `langchain_pg_collection` - Collection metadata
- `langchain_pg_embedding` - Vectors and documents

You can configure the collection name in `.env`:
```bash
PGVECTOR_COLLECTION_NAME=code_chunks
PGVECTOR_TABLE_NAME=langchain_pg_embedding
```

### 3. Start Redis
```bash
redis-server
```

### 4. Install Ollama Models
```bash
ollama pull gemma3:4b
ollama pull llama3.1:8b
ollama pull nomic-embed-text:latest
```

### 5. Install Frontend Dependencies
```bash
cd RAG_UI
npm install
# or
bun install
```

### 6. Configure Environment
```bBackend (FastAPI)
```bash
uvicorn app:app --host 0.0.0.0 --port 8000 --workers 4
```

### Frontend (React UI)
```bash
cd RAG_UI
npm run dev
# or
bun run dev
```
Access UI at: http://localhost:5173

### Legacy Streamlit UI (Optional)
```bash
streamlit run streamlit_app.py
```

## Authentication

### Employee Login
The system uses employee ID-based authentication for session management:

1. **Login Page**: http://localhost:5173/login
   - **Employee ID**: Format `A1234` (Letter + 4-6 digits)
   - **Email**: `name@fci-ccm.com`
   - **Password**: Any password (validation TODO in backend)

2. **Session Management**:
   - Each employee gets unique thread IDs: `F5987-abc12345`
   - Sessions persist across page refresh via localStorage
   - Multiple developers work without conflicts

3. **User Interface**:
   - Avatar shows employee initials (F5987 → F5)
   - Dropdown displays: name, employee ID, email
   - Logout clears session

**Example Login**:
```
Employee ID: F5987
Email: pradeep@fci-ccm.com
Password: test123
```

See [AUTHENTIC (with Employee ID)
```bash
curl -X POST http://localhost:8000/query \
  -H "X-API-Key: your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Find NullPointerException in UserService",
    "user_id": "F5987",
    "error_message": "ja (with User ID)
```bash
curl -X POST http://localhost:8000/resume \
  -H "X-API-Key: your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "thread_id": "F5987-abc12345",
    "human": "feedback",
    "feedback": "Need complete code",
    "user_id": "F5987"
  
  "thread_id": "F5987-abc12345",
  "answer": "...",
  "status": "pending_review"
}
```

### Refine Query (with Error Extraction)
```bash
curl -X POST http://localhost:8000/refine-query \
  -H "X-API-Key: your_key" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Settings > User Management > add user > email validation missing",
    "log_content": "ERROR: NullPointerException at UserValidator.java:45"
  }'

# Response includes extracted error
{
  "original_query": "Settings > User Management...",
  "refined_query": "Email validation missing in user creation causing NullPointerException",
  "extracted_error": "NullPointerException at UserValidator.java:45"
}
Edit `RAG_UI/.env`:
```bash
VITE_RAG_API_URL=http://localhost:8000
VITE_API_KEY=your_api_key_here
```

## Running the Application

### Start API Server
```bash
uvicorn app:app --host 0.0.0.0 --port 8000 --workers 4
```

### Start Streamlit UI
```bash
streamlit run streamlit_app.py
```Backend Settings (.env)
```bash
# PostgreSQL
PGVECTOR_HOST=localhost
PGVECTOR_PORT=5432
PGVECTOR_DATABASE=vectordb
PGVECTOR_USER=postgres
PGVECTOR_PASSWORD=your_password
PGVECTOR_COLLECTION_NAME=code_chunks
PGVECTOR_POOL_SIZE=20
PGVECTOR_MAX_OVERFLOW=10

# Redis
REDIS_URL=redis://localhost:6379
REDIS_TTL=7200

# API
API_KEYS=key1,key2,key3

# Models
OLLAMA_BASE_URL=http://localhost:11434
LLM_MODEL=gemma3:4b
REFINER_MODEL=llama3.1:8b
EMBEDDINGS_MODEL=nomic-embed-text:latest
```

### Frontend Settings (RAG_UI/.env)
```bash
VITE_RAG_API_URL=http://localhost:8000
VITE_API_KEY=your_api_key_here
VITE_JIRA_API_URL=http://your-jira-server
```

### Connection Pool Settings
For 40-50 concurrent users:
- `PGVECTOR_POOL_SIZE=20`
- `PGVECTOR_MAX_OVERFLOW=10`
- `REDIS_TTL=7200` (2 hours)

### Security
- Set `API_KEYS` in `.env` to enable authentication
- Never commit `.env` to version control
- Use strong passwords for PostgreSQL
- **TODO**: Add backend employee ID validation
```bash
curl -X POST http://localhost:8000/index \
  -H "X-API-Key: your_key" \
  -H "Content-Type: application/json" \
  -d '{"path": "/path/to/code"}'
```

### Query Code
```bash
curl -X POST http://localhost:8000/query \
  -H "X-API-Key: your_key" \
  -H "Content-Type: application/json" \
  -d '{"query": "Find NullPointerException in UserService"}'
```

### Resume with Feedback
```bAuthentication Issues
- **Avatar not showing**: Clear localStorage and re-login
- **Redirect loop**: Clear browser cache and localStorage
- **Session lost on refresh**: Check browser allows localStorage

### PGVector Connection Issues
- Verify PostgreSQL is running: `sudo systemctl status postgresql`
- Check credentials in `.env`
- Test connection: `psql -U postgres -d vectordb`

### Ollama Model Not Found
- List models: `ollama list`
- Pull missing model: `ollama pull llama3.1:8b`
- Pull missing model: `ollama pull nomic-embed-text:latest`

### Redis Connection Failed
- Check Redis: `redis-cli ping`
- System falls back to in-memory sessions

### High Memory Usage
- Reduce `RETRIEVAL_TOP_K` (default: 10)
- Lower `PGVECTOR_POOL_SIZE`
- Enable Redis for session caching

### Frontend Build Issues
```bash
cd RAG_UI
rm -rf node_modules bun.lockb
bun install
bun run dev
```le authentication
- Never commit `.env` to version control
- Use strong passwords for PostgreSQL

## Monitoring

### Logs
Application logs are written to:
- `app.log` (all application logs)
- Console output (INFO level and above)

### Health Endpoint
```bash
curl http://localhost:8000/health
```
Returns:
- Vector store stats
- Redis connection status
- Active sessions count
- Model information

## Production Deployment

### Using systemd
```ini
[Unit]
6. Enable employee ID thread isolation

### Query Refinement
- Uses llama3.1:8b for better understanding
- Few-shot prompting with 7 examples
- Extracts errors from logs automatically
- Filters navigation steps from JIRA descriptions

## Documentation

- [AUTHENTICATION_IMPLEMENTATION.md](AUTHENTICATION_IMPLEMENTATION.md) - Complete auth system details
- [ARCHITECTURE_DIAGRAM.md](ARCHITECTURE_DIAGRAM.md) - Visual architecture and data flow
- [TESTING_GUIDE.md](TESTING_GUIDE.md) - Authentication and system testing

## Contributing

### Code Structure
```
Final_RAG/
├── app.py                          # FastAPI backend
├── Prompt_lib/query_refiner.py     # Query refinement with few-shot learning
├── Graph/workflow.py               # LangGraph HITL workflow
├── RAG_UI/
│   ├── src/
│   │   ├── contexts/AuthContext.tsx     # Authentication state
│   │   ├── pages/Login.tsx              # Employee login page
│   │   ├── pages/BugFixer.tsx           # Main analysis interface
│   │   └── components/layout/Navbar.tsx # User avatar & menu
│   └── ...
└── ...
```

### Key Components
- **Query Refinement**: [Prompt_lib/query_refiner.py](Prompt_lib/query_refiner.py)
- **Authentication**: [RAG_UI/src/contexts/AuthContext.tsx](RAG_UI/src/contexts/AuthContext.tsx)
- **Bug Fixer**: [RAG_UI/src/pages/BugFixer.tsx](RAG_UI/src/pages/BugFixer.tsx)
- **RAG Workflow**: [Graph/workflow.py](Graph/workflow.py)
Description=Final_RAG API
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/path/to/Final_RAG
Environment="PATH=/path/to/venv/bin"
ExecStart=/path/to/venv/bin/uvicorn app:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always

[Install]
WantedBy=multi-user.target
```

### Using Docker
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "4"]
```

## Troubleshooting

### PGVector Connection Issues
- Verify PostgreSQL is running: `sudo systemctl status postgresql`
- Check credentials in `.env`
- Test connection: `psql -U postgres -d vectordb`

### Ollama Model Not Found
- List models: `ollama list`
- Pull missing model: `ollama pull nomic-embed-text:latest`

### Redis Connection Failed
- Check Redis: `redis-cli ping`
- System falls back to in-memory sessions

### High Memory Usage
- Reduce `RETRIEVAL_TOP_K` (default: 10)
- Lower `PGVECTOR_POOL_SIZE`
- Enable Redis for session caching

## Performance Tuning

### For 40-50 Users
1. Use 4+ uvicorn workers
2. Enable Redis caching
3. Set connection pool: 20 base + 10 overflow
4. Monitor with `/health` endpoint
5. Use PostgreSQL for checkpointer in production

## License
See LICENSE file for details.
