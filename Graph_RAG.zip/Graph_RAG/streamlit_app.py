import streamlit as st
import requests
from typing import Dict, Any
import os
import tempfile

BASE_URL = "http://localhost:8000"


st.set_page_config(page_title="Neo Codex 1.0", layout="wide")

# ============== Sidebar for File Loading ==============
with st.sidebar:
    
    st.subheader("Load Code")
    code_path = st.text_input(
        "Enter File or Directory Path:",
        placeholder="/path/to/your/code/file.java or /path/to/directory",
        help="Enter the absolute path to a Java/TypeScript file or a directory containing them"
    )
    
    if st.button("📥 Load Code", type="primary", use_container_width=True):
        if code_path and code_path.strip():
            # Strip whitespace and quotes that might be pasted with the path
            path = code_path.strip().strip('"').strip("'")
            if os.path.isdir(path) or os.path.isfile(path):
                with st.spinner("Loading and indexing code..."):
                    try:
                        response = requests.post(
                            f"{BASE_URL}/index",
                            json={"path": path}
                        )
                        if response.status_code == 200:
                            result = response.json()
                            st.success(result.get('message', 'Code loaded successfully!'))
                            if 'stats' in result:
                                stats = result['stats']
                                st.info(f"📊 Total Chunks: {stats.get('total', 0)} | ☕ Java Chunks: {stats.get('java', 0)} | 🅰️ Angular Chunks: {stats.get('angular', 0)}")
                        else:
                            st.error(f"Failed to load: {response.text}")
                    except Exception as e:
                        st.error(f"Error: {str(e)}")
            else:
                st.warning("⚠️ Path does not exist!")
        else:
            st.warning("⚠️ Please enter a file or directory path")
    
    st.divider()
    
    # Workflow Logs Section (for debugging)
    st.subheader("🔍 Workflow Logs")
    st.caption("Real-time workflow execution logs")
    
    if "workflow_logs" not in st.session_state:
        st.session_state.workflow_logs = []
    
    # Display logs in a scrollable container with fixed height
    if st.session_state.workflow_logs:
        logs_text = "\n".join(st.session_state.workflow_logs[-50:])  # Last 50 logs
        st.text_area(
            "Logs",
            value=logs_text,
            height=220,
            disabled=True,
            label_visibility="collapsed"
        )
    else:
        st.info("No logs yet. Start a query to see workflow execution.")
    
    if st.button("🗑️ Clear Logs", use_container_width=True):
        st.session_state.workflow_logs = []
        st.rerun()
    
    st.divider()
    
    # Index Stats Section
    st.subheader("Index Statistics")
    if st.button("Refresh Stats", use_container_width=True):
        try:
            response = requests.get(f"{BASE_URL}/health")
            if response.status_code == 200:
                result = response.json()
                stats = result.get('index_stats', {})
                col1, col2, col3 = st.columns(3)
                col1.metric("Total Chunks", stats.get('total', 0))
                col2.metric("Java Chunks", stats.get('java', 0))
                col3.metric("Angular Chunks", stats.get('angular', 0))
            else:
                st.error("Failed to fetch stats")
        except Exception as e:
            st.error(f"Error: {str(e)}")
    
    # Delete Vector Store Section
    st.divider()
    st.subheader("⚠️ Clear Vector Store")
    st.caption("Delete all indexed documents from the database")
    
    # if st.button("🗑️ Clear All Data", type="secondary", use_container_width=True):
        # if st.session_state.get("confirm_delete", False):
            # with st.spinner("Clearing vector store..."):
                # try:
                #     response = requests.delete(f"{BASE_URL}/clear")
                #     if response.status_code == 200:
                #         result = response.json()
                #         st.success("✅ " + result.get('message', 'Vector store cleared!'))
                #         stats = result.get('stats', {})
                #         st.info(f"📊 Remaining: {stats.get('total', 0)} documents")
                #         st.session_state.confirm_delete = False
                #     else:
                #         st.error(f"Failed to clear: {response.text}")
                # except Exception as e:
                #     st.error(f"Error: {str(e)}")
        # else:
        #     st.session_state.confirm_delete = True
        #     st.warning("⚠️ Click again to confirm deletion of ALL data!")
        #     st.rerun()

# ============== Main Content ==============
st.subheader("Neo Codex 1.0")
st.caption("Ask about Java/Angular issues and get targeted fixes from your codebase.")

# Initialize session state for chat history
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "thread_id" not in st.session_state:
    st.session_state.thread_id = None
if "needs_review" not in st.session_state:
    st.session_state.needs_review = False
if "current_query" not in st.session_state:
    st.session_state.current_query = None
if "current_answer" not in st.session_state:
    st.session_state.current_answer = None

# Display chat history
for message in st.session_state.chat_history:
    with st.chat_message(message["role"]):
        st.write(message["content"])
        if message.get("status"):
            st.caption(f"Status: {message['status']}")

# Query input
query = st.chat_input("Enter your bug/issue here...")

if query is not None:
    if not query.strip():
        st.warning("Please enter a question before submitting.")
    else:
        # Add user query to chat history
        st.session_state.chat_history.append({"role": "user", "content": query})
        st.session_state.current_query = query
        
        with st.spinner("Analyzing..."):
            try:
                response = requests.post(
                    f"{BASE_URL}/query",
                    json={"query": query}
                )
                result: Dict[str, Any] = response.json()
                
                st.session_state.thread_id = result.get("thread_id")
                st.session_state.current_answer = result.get("answer", "")
                
                # Store workflow logs
                logs = result.get("logs", [])
                if logs:
                    st.session_state.workflow_logs.extend(logs)
                
                # Check status from API response
                api_status = result.get("status", "needs_review")
                st.session_state.needs_review = (api_status == "needs_review")
                
                # Determine display status
                if api_status == "completed":
                    display_status = "✅ Completed (No HITL needed)"
                else:
                    display_status = "⏳ Needs Review"
                
                # Add assistant response to chat history
                st.session_state.chat_history.append({
                    "role": "assistant",
                    "content": st.session_state.current_answer or "No response returned.",
                    "status": display_status
                })
                
            except Exception as exc:
                error_msg = f"Failed to fetch answer: {exc}"
                st.error(error_msg)
                st.session_state.chat_history.append({
                    "role": "assistant",
                    "content": error_msg,
                    "status": "❌ Error"
                })
            
            st.rerun()

# Review section (using /resume endpoint with Command pattern)
if st.session_state.needs_review and st.session_state.thread_id:
    st.divider()
    st.subheader("Review Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("✅ Approve", type="primary", use_container_width=True):
            with st.spinner("Finalizing..."):
                response = requests.post(
                    f"{BASE_URL}/resume",
                    json={
                        "thread_id": st.session_state.thread_id,
                        "human": "approved"
                    }
                )
                if response.status_code == 200:
                    # Update last message status
                    if st.session_state.chat_history:
                        st.session_state.chat_history[-1]["status"] = "✅ Approved"
                    
                    st.success("✅ Analysis approved and saved!")
                    st.session_state.needs_review = False
                    st.session_state.thread_id = None
                    st.rerun()
                else:
                    st.error("Failed to approve")
    
    with col2:
        feedback = st.text_input("Feedback (if rejecting):", key="feedback_input")
        if st.button("🔄 Reject & Retry", use_container_width=True):
            if feedback:
                with st.spinner("Re-analyzing with feedback..."):
                    response = requests.post(
                        f"{BASE_URL}/resume",
                        json={
                            "thread_id": st.session_state.thread_id,
                            "human": "feedback",
                            "feedback": feedback
                        }
                    )
                    if response.status_code == 200:
                        result = response.json()
                        
                        # Capture workflow logs from resume
                        logs = result.get("logs", [])
                        if logs:
                            st.session_state.workflow_logs.extend(logs)
                        
                        if result.get("status") == "reanalyzed":
                            # Update last message status
                            if st.session_state.chat_history:
                                st.session_state.chat_history[-1]["status"] = f"🔄 Retry {result.get('attempt', 0)}/3"
                            
                            # Add feedback and new answer to chat
                            st.session_state.chat_history.append({
                                "role": "user",
                                "content": f"Feedback: {feedback}"
                            })
                            st.session_state.chat_history.append({
                                "role": "assistant",
                                "content": result.get("answer", ""),
                                "status": "⏳ Needs Review"
                            })
                            
                            st.session_state.current_answer = result.get("answer", "")
                            st.info(f"🔄 Retry attempt {result.get('attempt', 0)}/3")
                            
                        elif result.get("status") == "max_attempts":
                            if st.session_state.chat_history:
                                st.session_state.chat_history[-1]["status"] = "⚠️ Max Attempts Reached"
                            st.warning("⚠️ Maximum retry attempts reached")
                            st.session_state.needs_review = False
                            st.session_state.thread_id = None
                        
                        st.rerun()
                    else:
                        st.error("Failed to reanalyze")
            else:
                st.warning("⚠️ Please provide feedback before rejecting")

# Clear chat history button
if st.session_state.chat_history:
    st.divider()
    if st.button("🗑️ Clear Chat History", use_container_width=True):
        st.session_state.chat_history = []
        st.session_state.thread_id = None
        st.session_state.needs_review = False
        st.session_state.current_query = None
        st.session_state.current_answer = None
        st.rerun()
