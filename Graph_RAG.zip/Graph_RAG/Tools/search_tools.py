from langchain_core.tools import tool


def create_search_tools(vector_store):
    """Create search tools bound to a vector store instance."""
    
    @tool
    def search_code(query: str) -> str:
        """Search the codebase for relevant code snippets in both Java and Angular files.
        
        Args:
            query: Search query (e.g., 'UserService NullPointerException', 'login validation', 'AuthController')
        
        Returns:
            Code snippets from both Java and Angular files matching the query.
        """
        # Retrieve documents with reduced k
        docs = vector_store.search(query, k=2, language=None)  # Reduced to 2 docs
        if not docs:
            return "No relevant code found."
        
        # Truncate each document to 400 chars
        output = []
        for i, doc in enumerate(docs, 1):
            m = doc.metadata
            lang = m.get('language', 'java')
            content = doc.page_content[:400]  # Limit to 400 chars
            output.append(f"[{i}] {m.get('file_name', 'unknown')} - {m.get('class_name', '')} ({lang})\n{content}...")
        return "\n\n".join(output)

    @tool
    def search_java(query: str) -> str:
        """Search ONLY Java files for code snippets.
        
        Args:
            query: Search query for Java code
        """
        docs = vector_store.search(query, k=2, language="java")  # Reduced to 2 docs
        if not docs:
            return "No relevant Java code found."
        
        output = []
        for i, doc in enumerate(docs, 1):
            m = doc.metadata
            content = doc.page_content[:400]
            output.append(f"[{i}] {m.get('file_name', 'unknown')} - {m.get('class_name', '')}\n{content}...")
        return "\n\n".join(output)

    @tool
    def search_angular(query: str) -> str:
        """Search ONLY Angular/TypeScript files for code snippets.
        
        Args:
            query: Search query for Angular code
        """
        docs = vector_store.search(query, k=2, language="angular")  # Reduced to 2 docs
        if not docs:
            return "No relevant Angular code found."
        
        output = []
        for i, doc in enumerate(docs, 1):
            m = doc.metadata
            content = doc.page_content[:400]
            output.append(f"[{i}] {m.get('file_name', 'unknown')} - {m.get('class_name', '')}\n{content}...")
        return "\n\n".join(output)

    return [search_code, search_java, search_angular]
