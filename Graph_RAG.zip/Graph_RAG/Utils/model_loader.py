import os
from langchain_ollama import ChatOllama, OllamaEmbeddings
from Config.settings import CONFIG


# Initialize LLM (Ollama - On-Prem)
llm = ChatOllama(
    model=CONFIG["llm_model"],
    base_url=CONFIG["ollama_base_url"],
    temperature=CONFIG["temperature"]
)

# Initialize Embeddings (Ollama - On-Prem)
embed_model = OllamaEmbeddings(
    model=CONFIG["embed_model"],
    base_url=CONFIG["ollama_base_url"]
)