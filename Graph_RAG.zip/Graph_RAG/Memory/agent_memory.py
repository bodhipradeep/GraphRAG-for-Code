import logging
import threading
from typing import List, Dict, Optional
from datetime import datetime, timedelta

import psycopg2
from psycopg2.extras import RealDictCursor

from Config.settings import CONFIG
from Utils.model_loader import embed_model

logger = logging.getLogger(__name__)


class AgentMemory:
    """PostgreSQL + pgvector backed agent memory.

    Design for scale:
    - 2-table split: lean vector table (agent_memory) + heavy text table (agent_memory_responses)
    - Deduplication: UPDATE existing entry if same query already approved (similarity > 0.95)
    - Scalar quantization: HNSW index on halfvec for 2x smaller index
    - Only stores approved responses
    - Central memory for all developers — matches on input query only
    """

    _lock = threading.Lock()
    _hnsw_created = False

    DEDUP_THRESHOLD = 0.95

    def __init__(self):
        self.connection_string = (
            f"host={CONFIG['pgvector_host']} port={CONFIG['pgvector_port']} "
            f"dbname={CONFIG['pgvector_db']} user={CONFIG['pgvector_user']} "
            f"password={CONFIG['pgvector_password']}"
        )
        self.similarity_threshold = CONFIG.get("memory_similarity_threshold", 0.90)
        self.ttl_days = CONFIG.get("memory_ttl_days", 1095)
        self._init_tables()

    def _get_conn(self):
        return psycopg2.connect(self.connection_string)

    def _init_tables(self):
        """Create agent_memory (lean vector table) + agent_memory_responses (heavy text)."""
        try:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector")

            # Lean vector table — kept small for fast HNSW search
            cur.execute("""
                CREATE TABLE IF NOT EXISTS agent_memory (
                    id SERIAL PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    query TEXT NOT NULL,
                    response_summary TEXT NOT NULL,
                    feedback_history TEXT,
                    embedding vector,
                    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                    expires_at TIMESTAMP WITH TIME ZONE
                )
            """)

            # Heavy response table — full text stored separately, fetched only on cache hit
            cur.execute("""
                CREATE TABLE IF NOT EXISTS agent_memory_responses (
                    memory_id INTEGER PRIMARY KEY REFERENCES agent_memory(id) ON DELETE CASCADE,
                    response TEXT NOT NULL
                )
            """)

            cur.execute("CREATE INDEX IF NOT EXISTS idx_agent_memory_user_id ON agent_memory (user_id)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_agent_memory_created_at ON agent_memory (created_at DESC)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_agent_memory_expires_at ON agent_memory (expires_at)")

            conn.commit()
            cur.close()
            conn.close()
            logger.info("Agent memory tables initialized (2-table split)")
        except Exception as e:
            logger.error(f"Failed to initialize agent memory tables: {e}")

    def _ensure_hnsw_index(self, dimension: int):
        """Create HNSW index with scalar quantization (halfvec) for 2x smaller index."""
        if AgentMemory._hnsw_created:
            return
        try:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("""
                SELECT 1 FROM pg_indexes
                WHERE indexname = 'idx_agent_memory_embedding'
            """)
            if not cur.fetchone():
                cur.execute(f"""
                    CREATE INDEX idx_agent_memory_embedding
                    ON agent_memory
                    USING hnsw ((embedding::halfvec({dimension})) halfvec_cosine_ops)
                    WITH (m = 16, ef_construction = 128)
                """)
                conn.commit()
                logger.info(f"Created HNSW halfvec index (dim={dimension}, m=16, ef_construction=128)")
            AgentMemory._hnsw_created = True
            cur.close()
            conn.close()
        except Exception as e:
            logger.warning(f"HNSW index creation skipped: {e}")
            AgentMemory._hnsw_created = True

    def _embed(self, text: str) -> List[float]:
        return embed_model.embed_query(text)

    def _get_ttl_expiry(self) -> datetime:
        try:
            conn = self._get_conn()
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute("SELECT config_value FROM system_config WHERE config_key = 'memory_ttl_days'")
            row = cur.fetchone()
            cur.close()
            conn.close()
            if row and row["config_value"]:
                return datetime.now() + timedelta(days=int(row["config_value"]))
        except Exception:
            pass
        return datetime.now() + timedelta(days=self.ttl_days)

    # ==================== WRITE (only approved, with dedup) ====================

    def add_success(self, user_id: str, query: str, result: str, feedback_history: str = None):
        """Store an approved response. Deduplicates: if a very similar query already exists
        (similarity > 0.95), UPDATE it instead of creating a duplicate row."""
        with self._lock:
            try:
                summary = result[:500] if result else ""
                embed_text = f"Query: {query} | Response: {summary}"
                embedding = self._embed(embed_text)
                self._ensure_hnsw_index(len(embedding))
                expires_at = self._get_ttl_expiry()

                conn = self._get_conn()
                cur = conn.cursor(cursor_factory=RealDictCursor)

                # Dedup check: find existing entry with very high similarity
                dim = len(embedding)
                cur.execute(f"""
                    SELECT id, 1 - (embedding::halfvec({dim}) <=> %s::halfvec({dim})) AS similarity
                    FROM agent_memory
                    WHERE (expires_at IS NULL OR expires_at > NOW())
                    ORDER BY embedding::halfvec({dim}) <=> %s::halfvec({dim})
                    LIMIT 1
                """, (str(embedding), str(embedding)))
                existing = cur.fetchone()

                if existing and existing["similarity"] >= self.DEDUP_THRESHOLD:
                    # UPDATE existing entry with newer response
                    memory_id = existing["id"]
                    cur.execute("""
                        UPDATE agent_memory
                        SET user_id = %s, query = %s, response_summary = %s,
                            feedback_history = %s, embedding = %s, expires_at = %s,
                            created_at = NOW()
                        WHERE id = %s
                    """, (user_id, query, summary, feedback_history,
                          str(embedding), expires_at, memory_id))
                    cur.execute("""
                        UPDATE agent_memory_responses SET response = %s WHERE memory_id = %s
                    """, (result, memory_id))
                    conn.commit()
                    cur.close()
                    conn.close()
                    logger.info(f"Dedup UPDATE id={memory_id} (sim={existing['similarity']:.3f}), user={user_id}")
                    return

                # No duplicate — INSERT new entry
                cur.execute("""
                    INSERT INTO agent_memory
                    (user_id, query, response_summary, feedback_history, embedding, expires_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    RETURNING id
                """, (user_id, query, summary, feedback_history, str(embedding), expires_at))
                memory_id = cur.fetchone()["id"]

                cur.execute("""
                    INSERT INTO agent_memory_responses (memory_id, response) VALUES (%s, %s)
                """, (memory_id, result))

                conn.commit()
                cur.close()
                conn.close()
                logger.info(f"Saved new approved memory id={memory_id}, user={user_id}, query={query[:50]}")
            except Exception as e:
                logger.error(f"Failed to save success: {e}")

    # ==================== READ ====================

    def get_cached_response(self, query: str, threshold: float = None) -> Optional[Dict]:
        """Global search — find an approved answer from ANY user with high similarity.
        Uses halfvec quantized index for fast search, then fetches full response from detail table."""
        threshold = threshold or self.similarity_threshold
        try:
            query_embedding = self._embed(f"Query: {query}")
            dim = len(query_embedding)
            conn = self._get_conn()
            cur = conn.cursor(cursor_factory=RealDictCursor)

            # Search using halfvec quantized index, JOIN to get full response
            cur.execute(f"""
                SELECT m.id, m.user_id, m.query, m.response_summary, m.created_at,
                       r.response,
                       1 - (m.embedding::halfvec({dim}) <=> %s::halfvec({dim})) AS similarity
                FROM agent_memory m
                LEFT JOIN agent_memory_responses r ON r.memory_id = m.id
                WHERE (m.expires_at IS NULL OR m.expires_at > NOW())
                ORDER BY m.embedding::halfvec({dim}) <=> %s::halfvec({dim})
                LIMIT 1
            """, (str(query_embedding), str(query_embedding)))
            row = cur.fetchone()
            cur.close()
            conn.close()

            if row and row["similarity"] >= threshold:
                logger.info(
                    f"Cache HIT: similarity={row['similarity']:.3f}, "
                    f"original_user={row['user_id']}, query={row['query'][:50]}"
                )
                return {
                    "id": row["id"],
                    "user_id": row["user_id"],
                    "query": row["query"],
                    "response": row["response"] or row["response_summary"],
                    "similarity": row["similarity"],
                    "created_at": str(row["created_at"])
                }
            return None
        except Exception as e:
            logger.error(f"Cache lookup failed: {e}")
            return None

    # ==================== ADMIN OPERATIONS ====================

    def cleanup_expired(self) -> int:
        """Delete expired records. CASCADE deletes response detail rows too."""
        try:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("DELETE FROM agent_memory WHERE expires_at IS NOT NULL AND expires_at < NOW()")
            deleted = cur.rowcount
            conn.commit()
            cur.close()
            conn.close()
            if deleted:
                logger.info(f"Cleaned up {deleted} expired memory records")
            return deleted
        except Exception as e:
            logger.error(f"Cleanup failed: {e}")
            return 0

    def delete_before_date(self, cutoff_date: str) -> int:
        try:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("DELETE FROM agent_memory WHERE created_at < %s", (cutoff_date,))
            deleted = cur.rowcount
            conn.commit()
            cur.close()
            conn.close()
            logger.info(f"Deleted {deleted} records before {cutoff_date}")
            return deleted
        except Exception as e:
            logger.error(f"Delete before date failed: {e}")
            return 0

    def set_ttl_days(self, days: int):
        try:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO system_config (config_key, config_value)
                VALUES ('memory_ttl_days', %s)
                ON CONFLICT (config_key) DO UPDATE SET config_value = %s
            """, (str(days), str(days)))
            cur.execute("""
                UPDATE agent_memory SET expires_at = created_at + INTERVAL '1 day' * %s
            """, (days,))
            updated = cur.rowcount
            conn.commit()
            cur.close()
            conn.close()
            self.ttl_days = days
            logger.info(f"TTL set to {days} days, updated {updated} existing records")
            return updated
        except Exception as e:
            logger.error(f"Failed to set TTL: {e}")
            return 0

    def get_stats(self) -> Dict:
        try:
            conn = self._get_conn()
            cur = conn.cursor(cursor_factory=RealDictCursor)

            cur.execute("SELECT COUNT(*) as total FROM agent_memory")
            total = cur.fetchone()["total"]

            cur.execute("SELECT COUNT(DISTINCT user_id) as users FROM agent_memory")
            users = cur.fetchone()["users"]

            cur.execute("SELECT MIN(created_at) as oldest, MAX(created_at) as newest FROM agent_memory")
            dates = cur.fetchone()

            cur.execute("""
                SELECT user_id, COUNT(*) as count FROM agent_memory
                GROUP BY user_id ORDER BY count DESC LIMIT 10
            """)
            per_user = cur.fetchall()

            cur.execute("SELECT COUNT(*) as expired FROM agent_memory WHERE expires_at IS NOT NULL AND expires_at < NOW()")
            expired = cur.fetchone()["expired"]

            # Table sizes for monitoring
            cur.execute("""
                SELECT pg_size_pretty(pg_total_relation_size('agent_memory')) as vector_table_size
            """)
            vector_size = cur.fetchone()["vector_table_size"]

            response_size = "N/A"
            try:
                cur.execute("""
                    SELECT pg_size_pretty(pg_total_relation_size('agent_memory_responses')) as response_table_size
                """)
                response_size = cur.fetchone()["response_table_size"]
            except Exception:
                pass

            ttl_days = self.ttl_days
            try:
                cur.execute("SELECT config_value FROM system_config WHERE config_key = 'memory_ttl_days'")
                row = cur.fetchone()
                if row:
                    ttl_days = int(row["config_value"])
            except Exception:
                pass

            cur.close()
            conn.close()

            return {
                "total_records": total,
                "approved": total,
                "unique_users": users,
                "oldest_record": str(dates["oldest"]) if dates["oldest"] else None,
                "newest_record": str(dates["newest"]) if dates["newest"] else None,
                "expired_pending_cleanup": expired,
                "ttl_days": ttl_days,
                "vector_table_size": vector_size,
                "response_table_size": response_size,
                "per_user": [{"user_id": r["user_id"], "count": r["count"]} for r in per_user]
            }
        except Exception as e:
            logger.error(f"Failed to get stats: {e}")
            return {"error": str(e)}

    def clear(self):
        """Clear all memory records. CASCADE handles response table."""
        try:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("DELETE FROM agent_memory")
            deleted = cur.rowcount
            conn.commit()
            cur.close()
            conn.close()
            logger.info(f"Cleared all {deleted} memory records")
        except Exception as e:
            logger.error(f"Failed to clear memory: {e}")
