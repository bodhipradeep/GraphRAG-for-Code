-- Agent Memory Schema for VM RAG (Optimized for Scale)
-- 2-table split: lean vector table + heavy response detail table
-- Stores ONLY approved responses (rejections handled in-session via HITL feedback loop)
-- feedback_history column stores all rejection reasons for reference (written only on approval)

CREATE EXTENSION IF NOT EXISTS vector;

-- Lean vector table — kept compact for fast HNSW search
-- No large TEXT columns here (response moved to agent_memory_responses)
CREATE TABLE IF NOT EXISTS agent_memory (
    id SERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    query TEXT NOT NULL,
    response_summary TEXT NOT NULL,       -- first 500 chars, inline (small enough)
    feedback_history TEXT,                -- rejection reasons joined by " | ", only on approval
    embedding vector,                     -- full-precision vector stored, halfvec used in index
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE
);

-- Heavy response detail table — full RAG output (5-50KB each)
-- Stored separately so vector search pages stay lean
-- ON DELETE CASCADE: when parent row deleted (TTL/cleanup), response auto-deleted
CREATE TABLE IF NOT EXISTS agent_memory_responses (
    memory_id INTEGER PRIMARY KEY REFERENCES agent_memory(id) ON DELETE CASCADE,
    response TEXT NOT NULL
);

-- Lookup indexes
CREATE INDEX IF NOT EXISTS idx_agent_memory_user_id ON agent_memory (user_id);
CREATE INDEX IF NOT EXISTS idx_agent_memory_created_at ON agent_memory (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_memory_expires_at ON agent_memory (expires_at);

-- HNSW index with scalar quantization (halfvec) — 2x smaller index, nearly identical recall
-- Created automatically after first insert (needs to know dimension from embedding model)
-- Manual example for 4096-dim:
--   CREATE INDEX idx_agent_memory_embedding
--   ON agent_memory
--   USING hnsw ((embedding::halfvec(4096)) halfvec_cosine_ops)
--   WITH (m = 16, ef_construction = 128);

-- System config table for TTL management
CREATE TABLE IF NOT EXISTS system_config (
    config_key TEXT PRIMARY KEY,
    config_value TEXT
);
